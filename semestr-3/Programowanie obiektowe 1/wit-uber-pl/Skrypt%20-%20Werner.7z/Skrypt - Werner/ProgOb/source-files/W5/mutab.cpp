#include <iostream>
#include <string>
using namespace std;

struct FullInfo {
    string address;

    FullInfo(string name) {
        cout << "Szukam adresu w bazie danych" << endl;
        address = "Adres pana " + name;
    }
};

class Klient {
    string  name;
    mutable FullInfo *fullInfo;
public:
    Klient(string n) {
        name     = n;
        fullInfo = NULL;
    }

    string getInfo() const {
        return name;
    }

    string getFullInfo() const {
        if (fullInfo == NULL)
            fullInfo = new FullInfo(name);
        return name + ", " + fullInfo->address;
        return name + ", " + fullInfo->address;
    }

    ~Klient() {
        delete fullInfo;
        cout << "usuwam " + name << endl;
    }
};

int main(void) {
    Klient klient("Szapiro");
    cout << klient.getInfo()     << endl;
    cout << klient.getFullInfo() << endl;
    cout << klient.getFullInfo() << endl;
    cout << "Koniec \'main\'\n";
}
