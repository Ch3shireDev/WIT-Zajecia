#include <iostream>
using namespace std;

class Punkt {
    double x, y;
public:
    Punkt(double x, double y) {
        this->x = x;
        this->y = y;
    }
    void przesun1(Punkt& p) const;
    void przesun2(Punkt& p);
    void przesun3(Punkt  p);
};

void Punkt::przesun1(Punkt& p) const {
    p.x += x;
    p.y += y;
}

void Punkt::przesun2(Punkt& p) {
    p.x += x;
    p.y += y;
}

void Punkt::przesun3(Punkt p) {
    p.x += x;
    p.y += y;
}

int main(void) {
    const Punkt p1(1,1);
    Punkt p2(2,2);
    Punkt p3(3,3);

    p1.przesun1(p3);
    p2.przesun1(p3);

    //p1.przesun2(p3); // NIE !

    p2.przesun2(p3);   // OK

    //p2.przesun2(p1); // NIE !

    p2.przesun3(p1);
}
