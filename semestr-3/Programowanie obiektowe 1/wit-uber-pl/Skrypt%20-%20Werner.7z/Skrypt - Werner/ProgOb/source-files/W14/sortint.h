#ifndef _SORTINT_H
#define _SORTINT_H

// komentarze...

void sort(int[],int);
void pisztab(const int[],int);
#endif
