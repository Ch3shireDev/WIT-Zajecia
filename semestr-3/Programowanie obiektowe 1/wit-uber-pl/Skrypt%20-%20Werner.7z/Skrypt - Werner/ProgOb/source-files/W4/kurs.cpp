#include <iostream>
#include <iomanip>  // formatowanie wydruku
using namespace std;

struct Klient {
    static double kurs;

    int    konto;
    double saldo;

    Klient(int k, double s): konto(k), saldo(s)
    { }

    static void zmienKurs(double nowyKurs) {
        kurs=nowyKurs;
    }

    void show() {
        ios::fmtflags flag = cout.flags();
        cout.setf(ios::fixed, ios::floatfield);
        int prec = cout.precision(2);

        cout << "Konto" << setw(5) << konto << ", Stan:"
             << setw(9) << saldo   << " PLN ("
             << setw(8) << saldo*kurs  << " EUR)" << endl;

        cout.flags(flag);
        cout.precision(prec);
    }
};
double Klient::kurs;

int main(void) {
    Klient::zmienKurs(0.2451);

    Klient klienci[] = { Klient(  27,15678.28),
                         Klient( 276,   79.23),
                         Klient(2227,  353.77),
                         Klient(2755,99871.23),
                         Klient(2799, 8484.19)
                       };
    int size = sizeof(klienci)/sizeof(klienci[0]);

    cout << "\nKurs: "<< Klient::kurs << endl;
    for (int i = 0; i < size; i++)
        klienci[i].show();

    Klient::zmienKurs(0.2467);

    cout << "\nKurs: "<< Klient::kurs << endl;
    for (int i = 0; i < size; i++)
        klienci[i].show();
}
