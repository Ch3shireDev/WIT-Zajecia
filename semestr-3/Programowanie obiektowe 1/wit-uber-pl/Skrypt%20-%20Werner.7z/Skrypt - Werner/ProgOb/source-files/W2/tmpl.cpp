#include <iostream>
#include <typeinfo>
using namespace std;

class Klient {
    int        oszcz;
    static int licznik;
    int        numer_klienta;
public:
    Klient(int oszcz = 0)
        : oszcz(oszcz)
    {
        numer_klienta = ++licznik;
    }

    bool operator<(const Klient& k) const {
        return oszcz < k.oszcz;
    }

    friend ostream& operator<<(ostream&, const Klient&);
};
int Klient::licznik = 0;

ostream& operator<<(ostream& os, const Klient& k) {
    os << "Klient numer: "  << k.numer_klienta
       << ", stan oszcz.: " << k.oszcz;
    return os;
}

template <typename T>
T wiekszy(const T& k1, const T& k2) {
    cout << "T=" << typeid(T).name() << endl;
    return k1 < k2 ? k2 : k1;
}

double wiekszy(const double& k1, const double& k2) {
    cout << "Funkcja specyficzna dla double\n";
    return k1 < k2 ? k2 : k1;
}

int main(void) {
    double x1 =  1,  x2 =  2;
    int    n1 = 22,  n2 = 11;
    Klient k1(2200), k2(1100);

    double maxd = wiekszy(x1,x2);
    int    maxi = wiekszy(n1,n2);
    Klient maxk = wiekszy<Klient>(k1,k2);

    cout << "Wiekszy double: " << maxd << endl;
    cout << "Wiekszy int   : " << maxi << endl;
    cout << "Wiekszy Klient: " << maxk << endl;
}
