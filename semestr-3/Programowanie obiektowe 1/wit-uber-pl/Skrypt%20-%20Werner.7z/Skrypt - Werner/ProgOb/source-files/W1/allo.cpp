#include <iostream>
#include <new>      // bad_alloc
#include <iomanip>  // setw
using namespace std;

int main()
{
    const int mega = 1024*1024, step = 100*mega;

    for (int size = step; ;size += step) {
        try {
            char* buf = new char[size];
            delete [] buf;
        }
        catch(bad_alloc) {
            cout << "NIE UDALO SIE: "  << setw(4)
                 << size/mega << " MB" << endl;
            return 1;
        }
        cout << "    udalo sie: "  << setw(4)
             << size/mega << " MB" << endl;
    }
}
