#include <iostream>
using namespace std;

void   pisztab(ostream&,const int[],int);
void   inssort(int[],int);
double minmaxmed(const int[],int,int&,int&);

int main() {
    int min, max, tab[] = {9,7,2,6,4,2,7,9,2,9,5,2},
        siz = sizeof(tab)/sizeof(tab[0]);

    double mediana = minmaxmed(tab,siz,min,max);

    cout << "min = " << min << ", max = " << max
         << ", mediana = "  <<  mediana   << endl;

    cout << "Tablica  oryginalna: ";
    pisztab(cout, tab, siz);

    inssort(tab, siz);

    cout << "Tablica posortowana: ";
    pisztab(cout, tab, siz);
}

void pisztab(ostream& str, const int t[], int siz) {
    str << "[ ";
    for (int i = 0; i < siz; ++i) str << t[i] << " ";
    str << "]" << endl;
}

void inssort(int a[], int siz) {
    int indmin = 0;
    for (int i = 1; i < siz; ++i)
        if (a[i] < a[indmin]) indmin = i;
    if (indmin != 0) {
        int p = a[0];
        a[0] = a[indmin];
        a[indmin] = p;
    }
    for (int i = 2; i < siz; ++i) {
        int j = i, v = a[i];
        while (v < a[j-1]) {
            a[j] = a[j-1];
            j--;
        }
        if (i != j ) a[j] = v;
    }
}

double minmaxmed(const int t[],int siz,int& min,int& max) {
    int* tab = new int[siz];

    // byloby lepiej za pomoca memcpy...
    for (int i = 0; i < siz; ++i)
        tab[i] = t[i];

    inssort(tab, siz);

    min = tab[0];
    max = tab[siz-1];

    double mediana = siz%2 == 0 ?
                0.5*(tab[siz/2] + tab[siz/2-1])
              : tab[siz/2];
    delete [] tab;
    return mediana;
}
