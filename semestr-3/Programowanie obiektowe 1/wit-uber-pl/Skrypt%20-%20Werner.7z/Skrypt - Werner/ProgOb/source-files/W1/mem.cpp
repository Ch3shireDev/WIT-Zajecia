#include <iostream>
#include <cstring>
using namespace std;

void show(const char*,const char*,size_t);

int main(void) {
    char ttt[10], sss[5], *p;

    memset(ttt,'t',10);
    memset(sss,'s',5);
    show("ttt (a)",ttt,10);
    show("sss (a)",sss,5);

    memcpy(ttt+5, sss, 5);
    show("ttt (b)",ttt,10);

    ttt[4]='a';
    ttt[5]='b';
    show("ttt (c)",ttt,10);

    memcpy(ttt+8,memmove(ttt+1,ttt+4,6),2);
    show("ttt (d)",ttt,10);

    p = (char*)memchr(ttt,'s',10);
    cout << '\'' << *p   << '\''
         << " ma index " << p-ttt << endl;

      // porownanie 'ab' z 'ab'
    cout << "memcmp(ttt+1,ttt+8,2) = "
         <<  memcmp(ttt+1,ttt+8,2) << endl;
      // porownanie 'tab' z 'sab'
    cout << "memcmp(ttt,ttt+7,3) = "
         <<  memcmp(ttt,ttt+7,3)   << endl;
      // porownanie 'ab' z 'sa'
    cout << "memcmp(ttt+1,ttt+7,2) = "
         <<  memcmp(ttt+1,ttt+7,2) << endl;
}

void show(const char* tit, const char* str, size_t dim) {
    cout << tit << ": ";
    for (size_t i = 0; i < dim; i++ ) cout << str[i];
    cout << endl;
}
