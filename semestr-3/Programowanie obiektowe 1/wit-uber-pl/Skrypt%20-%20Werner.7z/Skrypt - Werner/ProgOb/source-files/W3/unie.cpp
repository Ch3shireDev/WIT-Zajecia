#include <iostream>
#include <cassert>
using namespace std;

struct Worek;
enum Rodzaj {LICZBA, WSKAZNIK, ZNAK};

void wstaw(Worek*,double);
void wstaw(Worek*,int*);
void wstaw(Worek*,char);

void daj(const Worek*,double&);
void daj(const Worek*,int*&);
void daj(const Worek*,char&);

void info(const Worek&);

struct Worek {
    Rodzaj rodzaj;
    union {
        double dbl;
        int   *wsk;
        char   znk;
    } dane ;
};

int main(void) {
    Worek wor;
    double x = 3.14, y;
    int    i = 10, *pi = &i;
    char   c ='a', b;
    cout << "sizeof(wor) = " << sizeof(wor)
         << ", sizeof(wor.dane) = " << sizeof(wor.dane)
         << " bajtow\nAdresy skladowych:\n dbl: "
         << &wor.dane.dbl << "\n wsk: " <<  &wor.dane.wsk
         << "\n znk: " << (void*)&wor.dane.znk << endl;

    wstaw(&wor,x);
    info(wor);
    daj(&wor,y);
    cout << "Z funkcji main - y  = " <<    y << endl;

    // daj(&wor,b); // 'padloby' na 'assert' z linii 82

    wstaw(&wor,&i);
    info(wor);
    daj(&wor,pi);
    cout << "Z funkcji main - *pi = " << *pi << endl;

    wstaw(&wor,c);
    info(wor);
    daj(&wor,b);
    cout << "Z funkcji main - b   = " <<   b << endl;
}

void wstaw(Worek *w, double x) {
    w->rodzaj   = LICZBA;
    w->dane.dbl = x;
}

void wstaw(Worek *w, int *pi) {
    w->rodzaj   = WSKAZNIK;
    w->dane.wsk = pi;
}

void wstaw(Worek *w, char c) {
    w->rodzaj   = ZNAK;
    w->dane.znk = c;
}

void daj(const Worek *w, double& x) {
    assert(w->rodzaj == LICZBA);
    x  = w->dane.dbl;
}

void daj(const Worek *w, int*& pi) {
    assert(w->rodzaj == WSKAZNIK);
    pi = w->dane.wsk;
}

void daj(const Worek *w, char& c) {
    assert(w->rodzaj == ZNAK);
    c  = w->dane.znk;
}

void info(const Worek &w) {
    cout << "\nZ funkcji info - ";

    switch (w.rodzaj) {
        case LICZBA:
            cout << "Liczba: "   << w.dane.dbl    << endl;
            break;
        case WSKAZNIK:
            cout << "Wskaznik: " << *(w.dane.wsk) << endl;
            break;
        case ZNAK:
            cout << "Znak: "     << w.dane.znk    << endl;
            break;
    }
}
