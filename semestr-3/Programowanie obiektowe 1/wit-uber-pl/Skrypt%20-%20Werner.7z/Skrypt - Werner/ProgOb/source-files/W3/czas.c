#include <stdio.h>       /* printf */
#include <sys/timeb.h>   /* ftime  */

int main(void) {
    struct timeb start, teraz;
    int i, sec, msec;

    ftime(&start);

    for (i = 0; i <= 100000000; ++i) {
        if ( i%10000000 == 0) {
            ftime(&teraz);
            sec  = teraz.time    - start.time;
            msec = teraz.millitm - start.millitm;
            if (msec < 0) {
                --sec;
                msec += 1000;
            }
            printf("Po %9d iteracjach: %d sec %3d ms\n",
                                            i,sec,msec);
        }
    }
    return 0;
}
