#include <iostream>
using namespace std;

union Worek;

void wstaw(Worek*,float);
void wstaw(Worek*,long double);
void infor(const Worek*);

union Worek {
    float       liczbaF;
    long double liczbaLD;
} wor ;

int main(void) {
    cout << "\nsizeof(Worek) = " << sizeof(Worek) << endl;

    wstaw(&wor, 3.14F);
    infor(&wor);

    wstaw(&wor, 3.14L);
    infor(&wor);
}

void wstaw(Worek *w, float f) {
    w->liczbaF = f;
}

void wstaw(Worek *w, long double ld) {
    w->liczbaLD = ld;
}

void infor(const Worek *w) {
    cout << "\nliczbaF : " << w->liczbaF  << endl;
    cout <<   "liczbaLD: " << w->liczbaLD << endl;
}
