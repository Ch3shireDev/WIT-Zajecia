#include <stdio.h>
#include <stdlib.h>

struct Wezel {
    double szer;
    double wyso;
    struct Wezel *next;
};

void wstaw_dane(struct Wezel* n, double s, double w,
                                 struct Wezel* next);
void drukuj_liste(const struct Wezel* n);
void drukuj_liste_odwrotnie(const struct Wezel* n);

int main(void) {
    struct Wezel A = {4, 44, NULL};
    struct Wezel B, *pC, D, *head;

    pC = (struct Wezel*) malloc(sizeof(struct Wezel));

    wstaw_dane(&B,3,33,&A);
    wstaw_dane(pC,2,22,&B);
    wstaw_dane(&D,1,11,pC);

    head = &D;

    drukuj_liste(head);
    drukuj_liste_odwrotnie(head);
    printf("\nU gory lista, na dole odwrocona\n");

    free(pC);
    return 0;
}

void wstaw_dane(struct Wezel* n, double s, double w,
                                 struct Wezel* next) {
    n->szer = s;
    n->wyso = w;
    n->next = next;
}

void drukuj_liste(const struct Wezel* n) {
    for ( ; n; n = n->next )
        printf("(%2.0f, %2.0f) ",n->szer,n->wyso);
    printf("\n");
}

void drukuj_liste_odwrotnie(const struct Wezel* n) {
    if (n == NULL) return; /* pusta lista */

    if (n->next) drukuj_liste_odwrotnie(n->next);

    printf("(%2.0f, %2.0f) ",n->szer,n->wyso);
}
