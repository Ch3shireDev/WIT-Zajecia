from tkinter import * # GUI library

import matplotlib.pyplot as plt # plotting library
import numpy as np # numerical operations library
import tensorflow as tf # tensorflow for machine learning
from PIL import Image, ImageDraw # image manipulation library
from skimage.transform import resize # for image downscaling
from tensorflow import * # additional tensorflow dependencies


class Interface(Frame):
    """ Interface class extends tkinter.Frame. user generated events are handled
        here.
    """    

    def __init__(self, parent):
        """ Setup basic UI elements - embedds the Interface object in the main
            window.

        Args:
            parent (tk.Tk): Handle to the top window.
        """        
        Frame.__init__(self, parent) # initialize mother class
        self.parent = parent # save the reference to parent object
        # grid configuration of Interface in parent object
        self.grid(row=0, column=0, sticky='nsew') 
        Grid.rowconfigure(self.parent, 0, weight=1)
        Grid.columnconfigure(self.parent, 0, weight=1) 
        # initialize x, y coodirnates for drawing
        self.lastx = 0
        self.lasty = 0
        self.init_ui() # initialize GUI elements inside the Interface

    def init_ui(self):
        # load and store the trained keras model
        self.model = tf.keras.models.load_model('kb_minst_lenet5_model.h5')

        # main drawing component - starts with a black bacground
        self.canvas = Canvas(self, width=140, height=140, background='black')
        # canvas is presented to the user
        self.canvas.grid(sticky='n', column=0, row=0, columnspan=2)
        self.image = Image.new("L", (140, 140), 'black')
        # image stores the pixel color data which is used for conversion to 
        # np.array
        self.draw = ImageDraw.Draw(self.image)


        # two action buttons - when the canvas is ready predict_btn feeds the 
        # model with the pixel from the screen
        self.predict_btn = Button(self, text="Predict", 
                                                   command=self.make_prediction)
        self.predict_btn.grid(sticky='w', column=0, row=1)
        # When the user wants to clean the canvas and try again this redraws
        # the black background
        self.clear_btn = Button(self, text="Clear canvas",
                                                      command=self.clear_canvas)
        self.clear_btn.grid(sticky='e', column=1, row=1)

        # Variables for storing the results from prediction.
        self.prediction_var = StringVar()
        # Displays the classification result
        self.prediction = Entry(self, textvariable=self.prediction_var)
        self.prediction.grid(sticky='we', column=0, row=2)
        # Displays the max probability from prediction
        self.prediction_prob = StringVar()
        self.proability = Entry(self, textvariable=self.prediction_prob)
        self.proability.grid(sticky='we', column=1, row=2)
        Grid.rowconfigure(self, 0, weight=1)
        Grid.rowconfigure(self, 1, weight=1)
        Grid.rowconfigure(self, 2, weight=1)
        Grid.columnconfigure(self, 0, weight=1)
        Grid.columnconfigure(self, 1, weight=1)

        # Bind UI mouse events to drawing methods
        self.canvas.bind("<Button-1>", self.get_xy)
        self.canvas.bind("<B1-Motion>", self.add_line)

    def make_prediction(self):
        """ Loads the image from canvas, downscales it from 140x140 px to 
            28x28 px, adds (2,2,2,2) px padding with 0 values.
        """
        # get pixels from canvas...        
        img = resize(np.array(self.image), (28, 28))
        to_fit = img.reshape(1, 28,28, 1)
        # ... add padding ...
        to_fit = tf.keras.layers.ZeroPadding2D(padding=2)(to_fit)
        # ... and feed it to the trained model
        prediction = self.model.predict(to_fit)
        
        print(prediction) # display results on console for evaluation
        # update the text fields for user readout
        self.prediction_var.set(
                        "Predicted digit is: " + str(np.argmax(prediction)))
        self.prediction_prob.set(
                    "Probability is: {0:.2f}  %".format(np.max(prediction)*100))
        # Additionaly display the pixels for evaluation if the resising went ok
        # mapltotlib's imshow is used
        plt.imshow(to_fit[0], cmap='gray')
        plt.show()

    def clear_canvas(self):
        """ GUI method - canvas reset
        """        
        self.canvas.delete("all")
        self.draw.rectangle((0, 0, 140, 140), fill="black")


    def get_xy(self, event):
        """ Mouse event method - stores the starting coordinates afer click
        """        
        self.lastx, self.lasty = event.x, event.y
        
 
    def add_line(self, event):
        """ Mouse event method - draws a line between two points during mouse
            movement. The lines have to be drawn on the canvas and on the draw
            object - one is presented for user and the other is stored for pixel
            exctration.
        """        
        self.canvas.create_line((self.lastx, self.lasty, event.x, event.y), 
                                                        fill='white', width=13)
        self.draw.line([self.lastx, self.lasty, event.x, event.y],
                                                             'white', width=13)
        self.lastx, self.lasty = event.x, event.y # save coordinates

def main():
    """ Main GUI driver - launches the main window and creates an Interface
        intance.

    """
    root = Tk()
    root.wm_title("Digit detection")
    Interface(root)

    def on_quit():
        '''Destroy the window'''
        root.quit()
        root.destroy()

    root.protocol('WM_DELETE_WINDOW', on_quit)

    mainloop()

if __name__ == '__main__':
    main()
