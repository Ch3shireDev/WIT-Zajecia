import tensorflow as tf
from tensorflow import keras

print("Tensorflow version: ", tf.__version__)
print("Keras version: ", keras.__version__)

# Load strandard MINST digit dataset
minst = keras.datasets.mnist

(X_train_full, y_train_full), (X_test, y_test) = minst.load_data()

X_train_full = X_train_full.reshape(*list(X_train_full.shape), 1)
y_train_full = y_train_full.reshape(*list(y_train_full.shape), 1)
X_test = X_test.reshape(*list(X_test.shape), 1)
y_test = y_test.reshape(*list(y_test.shape), 1)

# Split and normalize data 55 000 training instances, 5 000 validation instances
X_valid, X_train = X_train_full[:5000] / 255.0, X_train_full[5000:] / 255.0 
# X-sets are normalized to 0.0-1.0 range

# similar set for labels
y_valid, y_train = y_train_full[:5000], y_train_full[5000:]

# Add 0-padding to expand size to 32x32 pixels, LeNet-5 requirement
# This is used to assure that the features from image are not sticking to the 
# borders of the image
X_valid = tf.keras.layers.ZeroPadding2D(padding=2, dtype='float64')(X_valid)
X_train = tf.keras.layers.ZeroPadding2D(padding=2, dtype='float64')(X_train)


class_names = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9] # correspond to digit labels

# Implementation of LeNet-5 model in kseras based on:
# Y. Lecun, Gradient-Based Learning Applied to Document Recognition, 
# PROCEEDINGS OF THE IEEE. 86 (1998) 47.

lenet5 = keras.models.Sequential()

lenet5.add(keras.layers.Conv2D(filters=6, kernel_size=(5, 5), 
                               activation='relu', input_shape=(32,32,1)))
lenet5.add(keras.layers.AveragePooling2D())
lenet5.add(keras.layers.Conv2D(filters=16, kernel_size=(5, 5), 
                               activation='relu'))
lenet5.add(keras.layers.AveragePooling2D())
lenet5.add(keras.layers.Flatten())

lenet5.add(keras.layers.Dense(units=120, activation='relu'))
lenet5.add(keras.layers.Dense(units=84, activation='relu'))
lenet5.add(keras.layers.Dense(units=10, activation = 'softmax')) # output

lenet5.summary()

lenet5.compile(loss="sparse_categorical_crossentropy",
              optimizer="sgd", metrics=["accuracy"])

history = lenet5.fit(X_train, y_train, epochs=50, validation_data=(X_valid, y_valid))
lenet5.save('kb_minst_lenet5_model.h5')
