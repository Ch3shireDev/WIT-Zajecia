# Projekt WIT

Projekt zaliczeniowy WIT.

# TODOs

1. Dodać tor wyścigowy.

	- Dodać podstawowy background po którym będzie poruszała się wyścigówka.
	- Maksymalna prędkość wyścigówki musi zależeć od położenia na torze.

2. Dodać AI w postaci drugiego samochodu.

	- AI musi być najprostsze na świecie - samochód porusza się po ustalonej trasie.
	- samochód gracza musi wykrywać kolizję z samochodem AI.

3. Dodać warunki wygranej.

	- Wygrana musi następować jeśli gracz przekroczy linię mety jako pierwszy.
	- Przegrana musi następować jeśli samochód AI przekroczy linię mety jako pierwszy.