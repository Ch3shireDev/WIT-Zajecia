#pragma once
class Camera;

/// <summary>
/// Funkcja wyświetlająca stan gry na ekranie.
/// </summary>
/// <param name="camera">Wskaźnik na obiekt kamery.</param>
void show(Camera* camera);
