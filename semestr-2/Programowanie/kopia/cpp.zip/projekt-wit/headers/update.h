#pragma once

/// <summary>
/// Aktualizuje stan gry.
/// </summary>
void update();
