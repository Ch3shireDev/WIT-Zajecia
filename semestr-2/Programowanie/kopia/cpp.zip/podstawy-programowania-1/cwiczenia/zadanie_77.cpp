//Igor Nowicki
//IZ02P03
//18608
#include <iostream>
using namespace std;
int main()
{
    int lbDzieci(0);
    if (lbDzieci > 0)
    {
        cout << "Masz dzieci. Brawo!" << endl;
    }
    else
    {
        cout << "Ojej, nie masz dzieci?" << endl;
    }
    cout << "Koniec programu" << endl;
    return 0;
}