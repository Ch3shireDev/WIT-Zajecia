//Igor Nowicki
//IZ02P03
//18608
#include <iostream>
#include <string>

using namespace std;

int main()

{
    string imieUzytkownika("Albert Einstein");
    return 0;
}