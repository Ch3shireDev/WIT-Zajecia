//Igor Nowicki
//IZ02P03
//18608
#include <iostream>
using namespace std;

// Napisz program w c++ który wyświetli Twoje dane z
// legitymacji studenckiej na ekranie możliwie wiernie
// oddając ich układ (położenie).

int main()
{
cout<<"------------------------------------------------------------------------------------------------------"<<endl;
cout<<"|                                                   Wyzsza Szkola      "<<"          LEGITYMACJA         |"<<endl;
cout<<"|        RZECZYPOSPOLITA                        Informatyki Stosowanej "<<"           STUDENCKA          |"<<endl;
cout<<"|            POLSKA                                 i Zarzadzania      "<<"          ------------        |"<<endl;
cout<<"|                                                                      "<<"          STUDENT CARD        |"<<endl;
cout<<"|                                                                      "<<"                              |"<<endl;
cout<<"|                                                Igor                  "<<"          ::::::::            |"<<endl;
cout<<"|                                               Nowicki                "<<"        ::::::::::::          |"<<endl;
cout<<"|                                                                      "<<"       ::::::::::::::         |"<<endl;
cout<<"|                                                                      "<<"      ::::::::::::::::        |"<<endl;
cout<<"|                                                                      "<<"      ::::::::::::::::        |"<<endl;
cout<<"|                                                                      "<<"      ::::::::::::::::        |"<<endl;
cout<<"|                                                                      "<<"       ::::::::::::::         |"<<endl;
cout<<"|                                                                      "<<"       ::::::::::::::         |"<<endl;
cout<<"|                                                                      "<<"        ::::::::::::          |"<<endl;
cout<<"|      Wydana: 20.08.2019                                              "<<"         ::::::::::           |"<<endl;
cout<<"|   Nr albumu: 18608                                                   "<<"         ::::::::::           |"<<endl;
cout<<"|       PESEL: 12344512412                                             "<<"    ///////////////////       |"<<endl;
cout<<"|       Adres: ----                                                    "<<"   ///////////////////////    |"<<endl;
cout<<"|                                                                      "<<"  /////////////////////////   |"<<endl;
cout<<"|                                                                      "<<" ///////////////////////////  |"<<endl;
cout<<"------------------------------------------------------------------------------------------------------"<<endl;
}