//Igor Nowicki
//IZ02P03
//18608
#include <iostream>
using namespace std;
int main()
{
    int wynik(6), a(5), b(8);
    wynik = a + b;
    cout << "5 + 8 = " << wynik << endl;
    return 0;
}