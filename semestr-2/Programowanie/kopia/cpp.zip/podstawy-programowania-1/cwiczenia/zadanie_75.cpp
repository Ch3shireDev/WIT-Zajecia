//Igor Nowicki
//IZ02P03
//18608
#include <iostream>
using namespace std;
int main()
{
    int lbDzieci(2);
    if (lbDzieci > 6)
    {
        cout << "Masz dzieci. Brawo!" << endl;
    }
    cout << "Koniec programu" << endl;
    return 0;
}