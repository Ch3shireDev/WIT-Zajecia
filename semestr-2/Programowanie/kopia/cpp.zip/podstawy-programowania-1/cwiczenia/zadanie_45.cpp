//Igor Nowicki
//IZ02P03
//18608
#include <iostream>
using namespace std;
int main()
{
    int wiekUzytkownika(16);
    int liczbaZnajomych(432); // Liczba znajomych uiytkownika
    double pi(3.14159);
    bool jestMoimZnajomym(true); // Czy ten użytkownik jest moim znajomym?
    char litera('a');
    return 0;
}