//Igor Nowicki
//IZ02P03
//18608
#include <iostream>

using namespace std;

int main()

{
    int wiekUzytkownika(16);
    cout << "Twéj wiek: ";
    cout << wiekUzytkownika;
    return 0;
}