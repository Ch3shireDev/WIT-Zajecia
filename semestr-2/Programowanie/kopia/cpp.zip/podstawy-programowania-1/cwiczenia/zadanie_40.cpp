//Igor Nowicki
//IZ02P03
//18608
#include <iostream>  // Doiaczenie biblioteki iostream (do wyswietlania tekstu)
using namespace std; // Informujemy, jakiej przestrzeni nazw bedziemy używać

/*
Funkcja główna main
Wykonywanie każdego programu zaczyna sie od tej funkcji
*/

int main()

{

    cout << "Hello world!" << endl; // wyswietlenie napisu
    return 0; // Zakończenie funkcji głównej i działania programu
}