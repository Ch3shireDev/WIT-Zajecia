//Igor Nowicki
//IZ02P03
//18608
#include <iostream>

using namespace std;

int main()

{
    cout << "Ile masz lat?" << endl;
    int wiekUzytkownika(6); // Przygotowujemy komórkę pamieci na liczbe calkowita.
    cin >> wiekUzytkownika; // W komórce tej chcemy zapisać liczbe.
    cout << "Masz " << wiekUzytkownika << " lat!" << endl;
    // I wyświetlamy wynik na ekranie.
    return 0;
}