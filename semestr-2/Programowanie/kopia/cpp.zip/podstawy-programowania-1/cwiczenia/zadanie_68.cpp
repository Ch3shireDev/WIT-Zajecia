//Igor Nowicki
//IZ02P03
//18608
#include <iostream>

using namespace std;

int main()

{
    double liczba(5.3);
    liczba += 4.2; // Teraz zmienna liczba bedzie miala wartość 9.5
    liczba *= 2.;  // Teraz zmienna liczba bedzie miala wartość 16.6
    liczba -= 1.;  // Teraz zmienna liczba bedzie miaia wartość 4.3
    liczba /= 3.;  // Teraz zmienna liczba bedzie miaia wartość 1.76667
    return 0;
}