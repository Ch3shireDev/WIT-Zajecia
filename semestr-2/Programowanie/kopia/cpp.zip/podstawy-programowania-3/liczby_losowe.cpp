//Igor Nowicki
//IZ02P03
//18608
#include <iostream>
#include <vector>

using namespace std;

int main()
{
    int x, y;
    cout << "Podaj zakres: ";
    cin >> x;
    cout << "Podaj liczbę użytkowników: ";
    cin >> y;

    
}