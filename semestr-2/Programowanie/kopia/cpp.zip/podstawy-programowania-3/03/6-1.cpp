//Igor Nowicki
//IZ02P03
//18608
#include <iostream>
using namespace std;
int main(){
// - stwórz program który pobiera dwie liczby i pozwala na wybranie operacji dodawania, odejmowania, mnożenia, dzielenia. Wyświetla wynik. Napisać wersję if oraz switch.

}