//Igor Nowicki
//IZ02P03
//18608
#include <iostream>
using namespace std;
int main()
{
    cout << "Podaj słowo: ";
    string str;
    cin >> str;
    cout << "Słowo ma " << str.length() << " liter" << endl;
}