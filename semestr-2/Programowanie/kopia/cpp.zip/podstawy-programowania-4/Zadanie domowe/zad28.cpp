// Igor Nowicki
// IZ02P03
// 18608

#include <iostream>
using namespace std;

int main()
{
    int a, b, c;
    cout << "Podaj boki trójkąta: ";
    cin >> a >> b >> c;
    cout << "Obwód: " << a + b + c << endl;
}