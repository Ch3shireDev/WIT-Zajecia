// Igor Nowicki
// IZ02P03
// 18608

#include <iostream>
#include <cmath>
using namespace std;

int main()
{
    double x;
    int y;

    cout << "Podaj dwie wartości (rzeczywista, całkowita): ";
    cin >> x >> y;

    cout << "Potęga x^y: " << pow(x, y)<<endl;
}