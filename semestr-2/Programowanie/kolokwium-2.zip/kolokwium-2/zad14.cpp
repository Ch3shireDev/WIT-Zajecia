
double &choose(double &a, double &b, bool flag)
{
    if (flag)
    {
        return a;
    }
    else
    {
        return b;
    }
}