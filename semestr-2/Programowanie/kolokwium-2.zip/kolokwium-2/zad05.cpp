int sign(int n)
{
    return n > 0 ? 1 : (n < 0 ? -1 : 0);
}

int main()
{
}