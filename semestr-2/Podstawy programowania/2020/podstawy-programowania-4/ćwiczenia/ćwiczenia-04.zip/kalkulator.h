//Igor Nowicki
//IZ02P03
//18608

float op(int a, int b, int n);