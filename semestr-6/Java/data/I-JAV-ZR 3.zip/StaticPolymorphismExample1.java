package pl.wit.lab3.p3;

/**
 * Klasa przykładowa bazowa dla polimorfizmu statycznego
 * @author Łukasz
 *
 */
public class StaticPolymorphismExample1 {
	public void print(String msg) {
		System.out.println(msg);
	}
}
