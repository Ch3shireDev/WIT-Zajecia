package pl.wit.lab3.p3;

/**
 * Klasa przykładowa pochodna dla polimorfizmu statycznego
 * @author Łukasz
 *
 */
public class StaticPolymorphismExample5 extends StaticPolymorphismExample4{
	public void print(Double d) {
		System.out.println("d="+d.toString());
	}
}
