package pl.wit.lab3.p3;

/**
 * Klasa przykładowa pochodna dla polimorfizmu statycznego
 * @author Łukasz
 *
 */
public class StaticPolymorphismExample3 extends StaticPolymorphismExample2 {
	public void print(Integer i) {
		System.out.println("Integer i="+i.toString());
	}
	
}
