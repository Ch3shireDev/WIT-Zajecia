package pl.wit.lab3.p3;

/**
 * Klasa przykładowa pochodna dla polimorfizmu statycznego
 * @author Łukasz
 *
 */
public class StaticPolymorphismExample4 extends StaticPolymorphismExample3{
	public void print(double d) {
		System.out.println("double d="+d);
	}
}
