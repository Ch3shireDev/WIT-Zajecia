package pl.wit.lab3.p3;
/**
 * Klasa przykładowa pochodna dla polimorfizmu statycznego
 * @author Łukasz
 *
 */
public class StaticPolymorphismExample2 extends StaticPolymorphismExample1{
	public void print(int i) {
		System.out.println("int i="+i);
	}
}
