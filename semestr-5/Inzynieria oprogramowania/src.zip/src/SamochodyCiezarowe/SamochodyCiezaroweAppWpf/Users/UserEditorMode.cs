﻿namespace SamochodyCiezaroweAppWpf.Users
{
    public enum UserEditorMode
    {
        CreateOperator,
        CreateAdministrator,
        Edit
    }
}