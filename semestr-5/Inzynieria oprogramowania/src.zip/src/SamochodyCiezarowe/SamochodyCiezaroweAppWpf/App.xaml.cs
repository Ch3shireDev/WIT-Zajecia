﻿using System.Windows;

namespace SamochodyCiezaroweAppWpf
{
    /// <summary>
    ///     Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }
}