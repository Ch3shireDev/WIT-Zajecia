﻿namespace SamochodyCiezaroweLibrary.Users
{
    public class Administrator : User
    {
        public override string Description => "Administrator";
    }
}