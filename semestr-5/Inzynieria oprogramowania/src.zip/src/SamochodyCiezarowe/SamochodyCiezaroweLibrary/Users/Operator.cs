﻿namespace SamochodyCiezaroweLibrary.Users
{
    public class Operator : User
    {
        public override string Description => "Operator systemu";
    }
}