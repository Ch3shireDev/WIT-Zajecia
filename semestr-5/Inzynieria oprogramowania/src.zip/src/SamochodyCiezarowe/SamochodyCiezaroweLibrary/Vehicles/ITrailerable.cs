﻿namespace SamochodyCiezaroweLibrary.Vehicles
{
    public interface ITrailerable
    {
        int TrailerId { get; set; }
        int Id { get; set; }
    }
}