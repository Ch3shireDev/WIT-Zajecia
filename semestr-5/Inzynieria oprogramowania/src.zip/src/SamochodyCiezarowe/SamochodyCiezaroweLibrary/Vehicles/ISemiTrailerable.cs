﻿namespace SamochodyCiezaroweLibrary.Vehicles
{
    public interface ISemiTrailerable
    {
        int SemiTrailerId { get; set; }
    }
}