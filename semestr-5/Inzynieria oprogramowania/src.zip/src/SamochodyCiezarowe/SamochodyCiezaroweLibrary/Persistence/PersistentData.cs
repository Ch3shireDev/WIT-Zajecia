﻿using System.Collections.Generic;
using SamochodyCiezaroweLibrary.Vehicles;

namespace SamochodyCiezaroweLibrary.Persistence
{
    public class PersistentData
    {
        public List<Vehicle> Vehicles { get; set; }
    }
}