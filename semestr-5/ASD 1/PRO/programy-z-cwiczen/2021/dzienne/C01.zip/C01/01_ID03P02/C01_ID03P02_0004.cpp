#include <cstdio>

///void MySwap(int* x, int* y);

int main(){
    int x, y =5;

    printf("x? = ");

    ///MySwap(&x, &y);
            
    printf("x = %d\n", x);

    return 0;
    }
