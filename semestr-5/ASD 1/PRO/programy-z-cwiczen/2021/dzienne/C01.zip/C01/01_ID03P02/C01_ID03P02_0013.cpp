#include <cstdio>

int main(){
    int x, y=2;
    int * wx;

    wx = &x;

    printf("x? = ");
    scanf("%d", &x);

    y=2**wx;

    printf("x = %d, y =%d \n",x, y);

  

    return 0;
    }
