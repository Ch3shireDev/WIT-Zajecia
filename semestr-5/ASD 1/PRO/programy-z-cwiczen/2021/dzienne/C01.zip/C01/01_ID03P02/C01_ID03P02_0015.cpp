#include <cstdio>

int main(){
    double x;
    int * wx;

    wx = (int*)&x;

    printf("x? = ");
    scanf("%d", wx);
    ++wx;
    printf("y? = ");
    scanf("%d", wx);   
    --wx;

    printf("x = %d, ",*wx);
    ++wx;
    printf("y =%d \n",*wx);

  

    return 0;
    }
