#include <cstdio>


int main(){
    int x;

    printf("adres x = %p\n", (void*)&x);

    return 0;
    }
