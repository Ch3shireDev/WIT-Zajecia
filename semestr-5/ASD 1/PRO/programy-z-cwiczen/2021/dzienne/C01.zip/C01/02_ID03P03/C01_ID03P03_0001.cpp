#include <cstdio>

int main(){
    printf("Konstantynopolitanczykowianeczka\n");
    fprintf(stdout, "Konstantynopolitanczykowianeczka\n");
      
    return 0;
    }
