#include <cstdio>


int main(){
    int x=65;

    printf("adres x = %p\n", (void*)&x);
    
    printf("x = %d\n",*(&x));
    printf("x = %c\n",*(&x));
    
/*    printf("x? = ");

            
    printf("x = %d\n", x);
*/
    return 0;
    }
