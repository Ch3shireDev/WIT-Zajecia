#include <cstdio>

int main(){
    int x, y;
    
    x = y;
    
    x = 65;
    y = 50;
    
    printf("x = %d\n", x);
    printf("x = %d, y = %d\n", x, y);
    printf("x = %c, y = %c\n", x, y);
    
    printf("x = %d, y = %d\n", x);

    printf("x = %d, y = %d\n", y, x);

          
    return 0;
    }
