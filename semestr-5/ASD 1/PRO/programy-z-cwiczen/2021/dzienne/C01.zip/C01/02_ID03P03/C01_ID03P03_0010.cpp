#include <cstdio>

int main(){
    int x, y;
    int * wx, *wy, *wt;

    wx = &x;
    wy = &y;

    printf("x? = ");
    scanf("%d", &x);

    printf("y? = ");
    scanf("%d", &y);

/**

*/

    printf("x = %d, y =%d \n",x, y);
    printf("*wx = %d, *wy =%d \n",*wx, *wy);


    /**
    x? = 7
    y? = 5
    x = 7, y = 5
    *wx = 5, *wy = 7
    */

    /**
    x? = 5
    y? = 7
    x = 5, y = 7
    *wx = 5, *wy = 7
    */
    return 0;
    }
///30 , 25, 25, 20, 20, 20, 20, 12, 12, 12, 12, 12, 10 ...
