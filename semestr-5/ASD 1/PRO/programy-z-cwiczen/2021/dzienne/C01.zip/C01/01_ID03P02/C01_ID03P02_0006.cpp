#include <cstdio>


int main(){
    int x=65;

    
    printf("x? = ");

    scanf("%d", &x);
            
    printf("x = %d\n", x);

    return 0;
    }
