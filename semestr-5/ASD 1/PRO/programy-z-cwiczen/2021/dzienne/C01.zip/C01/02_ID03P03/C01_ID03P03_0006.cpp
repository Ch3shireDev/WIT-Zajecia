#include <cstdio>


int main(){
    int x;
    int* px;

    px = &x;
    
    printf("adres x = %p\n",(void*)&x);
    printf("px = %p\n", (void*)px);
    
    return 0;
    }
