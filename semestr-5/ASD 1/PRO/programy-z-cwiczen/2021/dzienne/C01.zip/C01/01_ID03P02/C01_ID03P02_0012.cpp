#include <cstdio>


int main(){
    int x, y;
    int * wx, *wy, *wt;

    wx = &x;
    wy = &y;

    printf("x? = ");
    scanf("%d", &x);

    printf("y? = ");
    scanf("%d", &y);
    

    if(*wx<*wy){
        wt = wx;
        wx = wy;
        wy = wt;
        }


    printf("x = %d, y =%d \n",x, y);
    printf("*wx = %d, *wy =%d \n",*wx, *wy);

  

    return 0;
    }

    
 /**
    x? = 5
    y? = 7
    x = 5, y = 7
    *wx = 7, *wy = 5
*/

/**
    x? = 7
    y? = 5
    x = 7, y = 5
    *wx = 7, *wy = 5
*/
///30, 25, 25, 20, 20, 20, 12, 12, 12, 12, 10 ...
