#include <cstdio>

int main(){
    int x, y;
        
    x = 65;
    y = 48;
    
    printf("x = %c\n", x);

    printf("x = %c, y = %c\n", x, y);

    return 0;
    }
