#include <cstdio>


int main(){
    int x;
    int* px;
    int ** ppx;
    
    ppx = &px;
    
    px = &x;
    
    printf("x? = ");

    scanf("%d", *ppx);
            
    printf("x = %d\n", *px);

    return 0;
    }
