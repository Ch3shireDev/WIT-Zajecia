///***********************************************
MyClass01::MyClass01(){
    cout<<"\n\t\tKONSTRUKTOR BEZARGUMENTOWY MyClass01\n\n";
    x2 = 11;
    x1 = 12;
    x0 = 13;
    }
///***********************************************
MyClass01::MyClass01(int x2, int x1, int x0){
    cout<<"\n\t\tKONSTRUKTOR TRZYARGUMENTOWY MyClass01\n\n";
    (*this).x2 = x2;
    this->x1 = x1;
    this->x0 = x0;
    }
///***********************************************
MyClass01::MyClass01(const MyClass01& mC){
    cout<<"\n\t\tKONSTRUKTOR KOPIUJACY MyClass01\n\n";
    this->x2 = mC.x2;
    this->x1 = mC.x1;
    this->x0 = mC.x0;
    }
///***********************************************
MyClass01::~MyClass01(){
    cout<<"\n\t\tDESTRUKTOR MyClass01\n\n";
    }
///***********************************************
string MyClass01::ToString(){
    string myStr = "(" + MyUtility::ToString(x2) +
               ", " + MyUtility::ToString(x1) +
               ", " + MyUtility::ToString(x0) + ")->"
               + MyUtility::ToString(CRC());
    return myStr;
    }
///***********************************************
int MyClass01::CrC(){
    return 4 * (x2%2)+ 2 * (x1%2) + x0%2;
    }
///***********************************************
void MyClass01::SetCrC(){cRc = CrC();}
///***********************************************
int MyClass01::CRC(){
    SetCrC();
    return cRc;
    }
///***********************************************
MyClass01 MyClass01::operator+(const MyClass01& mC)const{
    MyClass01 mCC(mC);
    mCC.x2 += x2;
    mCC.x1 += x1;
    mCC.x0 += x0;
    return mCC;
    }
///***********************************************
