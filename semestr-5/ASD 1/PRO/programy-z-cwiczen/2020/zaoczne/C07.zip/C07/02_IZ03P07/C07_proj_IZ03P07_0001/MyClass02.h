#ifndef MyClass02_H
#define MyClass02_H
#include "MyClass01.h"

class MyClass02{
    public:
        MyClass02();
        MyClass02(MyClass01, MyClass01, MyClass01);
        ~MyClass02();

        string ToString();
        int CrC();
        void SetCrC();
        int CRC();
        MyClass02 operator+(const MyClass02&)const;

        MyClass01 x2;
        MyClass01 x1;
        MyClass01 x0;
    private:
        int cRc;
    };
#include "MyClass02.cpp"
#endif //MyClass02_H
///45, 35, 35, 20, 20, 20, 15, 15, 15
