///********************************************************************
void Application::Run(){
    Main02();
    }
///********************************************************************
void Application::Main01(){
    cout<<"\n\n\t\tHappy new  year 2021 !!!\n\n";
    }
///********************************************************************
void Application::Main02(){
    MyClass02 mC(MyClass01(31, 32, 33),
                           MyClass01(21, 22, 23),
                           MyClass01(11, 12, 13));
    MyClass02 mD(MyClass01(13, 12, 11),
                           MyClass01(31, 32, 33),
                           MyClass01(45, 47, 48));
    cout<<"mC: "<<mC.ToString()<<endl;
    MyClass02 mE = mC + mD;
    cout<<"mE: "<<mE.ToString()<<endl;


    }
///********************************************************************
