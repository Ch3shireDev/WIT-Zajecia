#ifndef TabInt01_H
#define TabInt01_H
#include "MyUtility.h"

class TabInt01{
    public:
        TabInt01(int  = 0);
 //   private:
        int * pT;
        int   sT;
    };
#include "TabInt01.cpp"
#endif // TabInt01_H
