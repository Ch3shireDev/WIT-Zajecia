#include "Application.h"
#include "MyUtility.h"


int main(){
    Application application;
    application.Run();

    return 0;
    }
