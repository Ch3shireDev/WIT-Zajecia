///***********************************************
MyClass02::MyClass02():x2(2, 2, 2), x1(1, 1, 1), x0(0, 0, 0)
    {
    //cout<<"\n\tKONSTRUKTOR BEZARGUMENTOWY  ---------------------- MyClass02\n\n";
    }
///***********************************************
MyClass02::MyClass02(MyClass01 x2, MyClass01 x1, MyClass01 x0 ):x2(x2), x1(x1), x0(x0)
    {
    //cout<<"\n\tKONSTRUKTOR TRZYARGUMENTOWY  ---------------------- MyClass02\n\n";
    }
///***********************************************
MyClass02::~MyClass02(){
    //cout<<"\n\tDESTRUKTOR ---------------------- MyClass01\n\n";
    }
///***********************************************
string MyClass02::ToString(){
    string myStr = "[" + x2.ToString() +
               ", " + x1.ToString() +
               ", " + x0.ToString() + "]->"
               + MyUtility::ToString(CRC());
    return myStr;
    }
///***********************************************
int MyClass02::CrC(){
    return  64*x2.CRC() + 8*x1.CRC() + x0.CRC();
    }
///***********************************************
void MyClass02::SetCrC(){cRc = CrC();}
///***********************************************
int MyClass02::CRC(){
    SetCrC();
    return cRc;
    }
///***********************************************
MyClass02 MyClass02::operator+(const MyClass02& mC)const{
    MyClass02 mCC(mC);
    mCC.x2 = mCC.x2 + x2;
    mCC.x1 = mCC.x1 + x1;
    mCC.x0 = mCC.x0 + x0;
    return mCC;
    }
///***********************************************

