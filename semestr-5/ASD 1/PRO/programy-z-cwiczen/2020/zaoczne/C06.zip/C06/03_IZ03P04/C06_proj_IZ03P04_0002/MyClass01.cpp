///***********************************************
MyClass01::MyClass01(){
    cout<<"\n\n\t\tKonstruktor bezargumentowy MyClass01\n\n";
    }
///***********************************************
MyClass01::MyClass01(int x2, int x1, int x0){
    cout<<"\n\n\t\tKonstruktor trzyargumentowy MyClass01\n\n";
    this->x2 = x2;
    this->x1 = x1;
    this->x0 = x0;
    }
///***********************************************
MyClass01::MyClass01(const MyClass01& myClass01){
    cout<<"\n\n\t\tKonstruktor kopiujacy MyClass01\n\n";
    this->x2 = myClass01.x2;
    this->x1 = myClass01.x1;
    this->x0 = myClass01.x0;
    }
///***********************************************
MyClass01::~MyClass01(){
    cout<<"\n\n\t\tDestruktor MyClass01\n\n";
    this->x2 = 0;
    this->x1 = 0;
    this->x0 = 0;
    }
///***********************************************
int MyClass01::CrC(){
    return 4*(x2%2) + 2*(x1%2) + x0%2;}
///***********************************************
void MyClass01::SetCrC(){cRc = CrC();}
///***********************************************
int MyClass01::CRC(){
    SetCrC();
    return cRc;
    }
///***********************************************
string MyClass01::ToString(){
    string myStr = "(" + MyUtility::ToString(x2) +
               ", " + MyUtility::ToString(x1) +
               ", " + MyUtility::ToString(x0) +
               ") -> " + MyUtility::ToString(CRC());
    return myStr;
    }
///***********************************************
MyClass01 MyClass01::operator+(const MyClass01& mC)const{
    return MyClass01(x2+mC.x2, x1+mC.x1, x0+mC.x0);
    }
///***********************************************

