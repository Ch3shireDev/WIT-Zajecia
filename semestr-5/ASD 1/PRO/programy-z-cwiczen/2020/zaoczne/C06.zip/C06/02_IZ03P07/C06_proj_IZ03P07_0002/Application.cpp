///********************************************************************
void Application::Run(){
    Main01();
    }
///********************************************************************
void Application::Main01(){
    MyClass01 mC_1(1,2,3);
    cout<<"mC_1: "<<mC_1.ToString()<<endl;
    cout<<"mC_1.cRc = "<<mC_1.CRC()<<endl;

    mC_1.x2 = 25;
    cout<<"mC_1: "<<mC_1.ToString()<<endl;
    cout<<"mC_1.cRc = "<<mC_1.CRC()<<endl;
    MyClass01 mC_2(4,5,6);
    ///MyClass01 mC_3 = mC_2.operator+(mC_1);
    MyClass01 mC_3 = mC_2 + mC_1;
    cout<<"mC_3: "<<mC_3.ToString()<<endl;

    }
///********************************************************************
/**
mC_1 = (1, 2, 3)
mC_2 = (4, 5, 6)

mC_3 = (5, 7, 9)

operacjaAdd
//30, 25, 25, 20, 20, 20, 15, 15, 15, 15
*/
