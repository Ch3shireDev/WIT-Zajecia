///***********************************************
MyClass01::MyClass01(){
    cout<<"\n\t\tKONSTRUKTOR BEZARGUMENTOWY MyClass01\n\n";
    x2 = 11;
    x1 = 12;
    x0 = 13;
    }
///***********************************************
MyClass01::MyClass01(int x2, int x1, int x0){
    cout<<"\n\t\tKONSTRUKTOR TRZYARGUMENTOWY MyClass01\n\n";
    (*this).x2 = x2;
    this->x1 = x1;
    this->x0 = x0;
    }
///***********************************************
MyClass01::~MyClass01(){
    cout<<"\n\t\tDESTRUKTOR MyClass01\n\n";
    x2 = 999;
    x1 = 999;
    x0 = 999;
    }
///***********************************************
void MyClass01::Ini(int x2, int x1, int x0){
    (*this).x2 = x2;
    this->x1 = x1;
    this->x0 = x0;
    }
///***********************************************
string MyClass01::ToString(){
    string myStr = "(" + MyUtility::ToString(x2) +
               ", " + MyUtility::ToString(x1) +
               ", " + MyUtility::ToString(x0) + ")";
    return myStr;
    }
///***********************************************

