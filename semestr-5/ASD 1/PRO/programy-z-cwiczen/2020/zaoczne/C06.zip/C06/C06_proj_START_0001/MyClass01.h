#ifndef MyClass01_H
#define MyClass01_H
#include "MyUtility.h"
#include <iostream>
using std::cout;
using std::cin;
using std::endl;
using std::string;

class MyClass01{
    public:
        void Ini(int, int, int);
        string ToString();
        int x2;
        int x1;
        int x0;

        int cRc;

    };
#include "MyClass01.cpp"
#endif // MyClass01_H
