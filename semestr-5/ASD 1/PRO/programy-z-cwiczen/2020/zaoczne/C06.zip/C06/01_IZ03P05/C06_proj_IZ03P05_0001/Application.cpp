///********************************************************************
void Application::Run(){
    Main03();
    }
///********************************************************************
void Application::Main01(){
    cout<<"\n\t\tMerry C H R I S T M A S\n";
    }
///********************************************************************
void Application::Main02(){
//    MyClass01 mC01_1;
//    mC01_1.Ini(1, 2, 3);
//    cout<<mC01_1.ToString()<<endl;
//    mC01_1.Adr();
//    cout<<"&mC01: "<<&mC01_1<<endl;
    }
///********************************************************************
void Application::Main03(){
    MyClass01 mC01_1(1, 2, 3);
    MyClass01 mC01_0;
    cout<<mC01_1.ToString()<<endl;

    {
    MyClass01 mC01_00;
    }

    cout<<mC01_0.ToString()<<endl;
    mC01_0.~MyClass01();
    cout<<mC01_0.ToString()<<endl;
    }
///********************************************************************
