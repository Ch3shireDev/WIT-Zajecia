///********************************************************************
void Application::Run(){
    Main02();
    }
///********************************************************************
void Application::Main01(){
    MyClass01 mC1(1, 2, 3);
    cout<<"mC1: "<<mC1.ToString()<<endl;
    mC1.SetCrC();
    //cout<<"mC1.cRc = "<<mC1.cRc<<endl;
    mC1.x1 = 9;

    cout<<"mC1.cRc = "<<mC1.CRC()<<endl;
    //mC1.cRc = 123;
    //cout<<"mC1.cRc = "<<mC1.cRc<<endl;

    }
///********************************************************************
void Application::Main02(){
    MyClass01 mC1(1, 2, 3);
    MyClass01 mC2(4, 5, 6);
    MyClass01 mC3;
    ///mC3 = mC1.operator+(mC2);

    mC3 = mC1 + mC2;

    cout<<"mC1: "<<mC1.ToString()<<endl;
    cout<<"mC2: "<<mC2.ToString()<<endl;
    cout<<"mC3: "<<mC3.ToString()<<endl;
    }
///********************************************************************
/**
mC1: (1, 2, 3) -> 5
mC2: (4, 5, 6) -> 2
mC3: (5, 7, 9) -> 7

25, 22, 22, 20, 20, 20, 18, 18, 18, 18
*/
