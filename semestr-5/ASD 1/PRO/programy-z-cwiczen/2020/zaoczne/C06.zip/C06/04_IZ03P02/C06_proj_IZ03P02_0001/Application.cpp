///********************************************************************
void Application::Run(){
    Main09();
    }
///********************************************************************
void Application::Main01(){
    cout<<"\n\t\tMerry C H R I S T M A S\n";
    }
///********************************************************************
void Application::Main02(){
    MyClass01 mC1;
    mC1.Ini(1,2,3);
    cout<<"mC1: "<<mC1.ToString()<<endl;
    }
///********************************************************************
void Application::Main03(){
    MyClass01 mC1(1,2,3);
    cout<<"mC1: "<<mC1.ToString()<<endl;
    }
///********************************************************************
void Application::Main04(){
    MyClass01 mC1(1,2,3);
    {
    MyClass01 mC2(11,12,13);
    cout<<"mC2: "<<mC2.ToString()<<endl;
    }

    cout<<"mC1: "<<mC1.ToString()<<endl;
    }
///********************************************************************
void Application::Main05(){
    MyClass01 mC1(1,2,3);
    MyClass01 mC2(4,5,6);

    cout<<"mC1: "<<mC1.ToString()<<endl;
    cout<<"mC2: "<<mC2.ToString()<<endl;
    mC2.~MyClass01();
    cout<<"mC2: "<<mC2.ToString()<<endl;
    }
///********************************************************************
void Application::Main06(){
    MyClass01 mC1(1,2,3);
    MyClass01 mC2(mC1);

    cout<<"mC1: "<<mC1.ToString()<<endl;
    cout<<"mC2: "<<mC2.ToString()<<endl;
    }
///********************************************************************
void Application::Main07(){
    MyClass01 mC1(1,2,3);

    cout<<"mC1: "<<mC1.ToString()<<endl;
    mC1.SetCrC();
    cout<<"mC1.cRc = "<<mC1.cRc<<endl;
    }
///********************************************************************
void Application::Main08(){
    MyClass01 mC1(1,2,3);

    cout<<"mC1: "<<mC1.ToString()<<endl;
    cout<<"mC1.cRc = "<<mC1.CRC()<<endl;
    }
///********************************************************************
void Application::Main09(){
    MyClass01 mC1(1,2,3);

    cout<<"mC1: "<<mC1.ToString()<<endl;
    cout<<"mC1.cRc = "<<mC1.CRC()<<endl;
    mC1.x2 = 4;
    mC1.cRc = 123;
    cout<<"mC1: "<<mC1.ToString()<<endl;
    cout<<"mC1.cRc = "<<mC1.cRc<<endl;
    }
///********************************************************************
