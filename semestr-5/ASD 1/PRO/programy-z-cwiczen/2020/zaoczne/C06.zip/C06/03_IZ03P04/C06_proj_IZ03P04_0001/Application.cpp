///********************************************************************
void Application::Run(){
    Main05();
    }
///********************************************************************
void Application::Main01(){
    cout<<"\n\t\tMerry C H R I S T M A S\n";
    }
///********************************************************************
void Application::Main02(){
    MyClass01 mC1(1, 2, 3);
    {
    MyClass01 mC0(7, 5, 2);
    cout<<"mC0: "<<mC0.ToString()<<endl;
    }
    cout<<"mC1: "<<mC1.ToString()<<endl;
    mC1.~MyClass01();
    cout<<"mC1: "<<mC1.ToString()<<endl;
    }
///********************************************************************
void Application::Main03(){
    MyClass01 mC1(1, 2, 3);
    MyClass01 mC2(mC1);
    cout<<"mC1: "<<mC1.ToString()<<endl;
    cout<<"mC2: "<<mC2.ToString()<<endl;
    }
///********************************************************************
void Application::Main04(){
    MyClass01 mC1(1, 2, 3);
    MyClass01 mC2 = mC1;
    cout<<"mC1: "<<mC1.ToString()<<endl;
    cout<<"mC2: "<<mC2.ToString()<<endl;
    }
///********************************************************************
void Application::Main05(){
    MyClass01 mC1(1, 2, 3);
    MyClass01 mC2;
    mC2 = mC1;
    cout<<"mC1: "<<mC1.ToString()<<endl;
    cout<<"mC2: "<<mC2.ToString()<<endl;
    }
///********************************************************************
