///********************************************************************
void Application::Run(){
    Main03();
    }
///********************************************************************
void Application::Main01(){
    cout<<"\n\t\tMerry C H R I S T M A S\n";
    }
///********************************************************************
void Application::Main02(){
    MyClass01 mC_1;
    MyClass01 mC_2(12,11,10);
    //mC_1.Ini(1,2,3);
    cout<<"mC_1: "<<mC_1.ToString()<<endl;
    cout<<"mC_2: "<<mC_2.ToString()<<endl;
    mC_1.~MyClass01();
    {
    MyClass01 mC_3(1,3,5);
    cout<<"mC_3: "<<mC_3.ToString()<<endl;
    }
    cout<<"mC_1: "<<mC_1.ToString()<<endl;

    }
///********************************************************************
void Application::Main03(){
    MyClass01 mC_1(12,11,10);
    MyClass01 mC_2(mC_1);
    MyClass01 mC_3 = mC_2;
    MyClass01 mC_4;
    mC_4 = mC_3;
    MyClass01 mC_5= 5;
    mC_5 = 7;
    cout<<"mC_1: "<<mC_1.ToString()<<endl;
    cout<<"mC_2: "<<mC_2.ToString()<<endl;
    cout<<"mC_5: "<<mC_5.ToString()<<endl;
    }
///********************************************************************
