///***********************************************
MyClass01::MyClass01(){
    cout<<"\n\n\t\tKonstruktor bezargumentowy MyClass01\n\n";
    }
///***********************************************
MyClass01::MyClass01(int x2, int x1, int x0){
    cout<<"\n\n\t\tKonstruktor trzyargumentowy MyClass01\n\n";
    this->x2 = x2;
    this->x1 = x1;
    this->x0 = x0;
    }
///***********************************************
MyClass01::MyClass01(const MyClass01& myClass01){
    cout<<"\n\n\t\tKonstruktor kopiujacy MyClass01\n\n";
    this->x2 = myClass01.x2;
    this->x1 = myClass01.x1;
    this->x0 = myClass01.x0;
    }
///***********************************************
MyClass01::~MyClass01(){
    cout<<"\n\n\t\tDestruktor MyClass01\n\n";
    this->x2 = 0;
    this->x1 = 0;
    this->x0 = 0;
    }
///***********************************************
void MyClass01::Ini(int x2, int x1, int x0){
    (*this).x2 = x2;
    this->x1 = x1;
    this->x0 = x0;
    }
///***********************************************
string MyClass01::ToString(){
    string myStr = "(" + MyUtility::ToString(x2) +
               ", " + MyUtility::ToString(x1) +
               ", " + MyUtility::ToString(x0) + ")";
    return myStr;
    }
///***********************************************

