///***********************************************
MyClass01::MyClass01(){
    cout<<"\n\n\t\tKONSTRUKTOR BEZARGUMENTOWY klasy MyClass01\n\n";
    x2 = 2;
    x1 = 1;
    x0 = 0;
    }
///***********************************************
//MyClass01::MyClass01(int x){
//    cout<<"\n\n\t\tKONSTRUKTOR JEDNOARGUMENTOWY klasy MyClass01\n\n";
//    x2 = 2 * x;
//    x1 = 1 * x;
//    x0 = 0;
//    }
///***********************************************
MyClass01::MyClass01(int x2, int x1, int x0){
    cout<<"\n\n\t\tKONSTRUKTOR TRZYARGUMENTOWY klasy MyClass01\n\n";
    this->x2 = x2;
    this->x1 = x1;
    this->x0 = x0;
    }
///***********************************************
MyClass01::MyClass01(const MyClass01& mC){
    cout<<"\n\n\t\tKONSTRUKTOR KOPIUJACY klasy MyClass01\n\n";
    this->x2 = mC.x2;
    this->x1 = mC.x1;
    this->x0 = mC.x0;
    }
///***********************************************
MyClass01::~MyClass01(){
    cout<<"\n\n\t\tDESTRUKTOR klasy MyClass01\n\n";
    x2 = 0;
    x1 = 0;
    x0 = 0;
    }
///***********************************************
void MyClass01::Ini(int x2, int x1, int x0){
    (*this).x2 = x2;
    this->x1 = x1;
    this->x0 = x0;
    }
///***********************************************
string MyClass01::ToString(){
    string myStr = "(" + MyUtility::ToString(x2) +
               ", " + MyUtility::ToString(x1) +
               ", " + MyUtility::ToString(x0) + ")";
    return myStr;
    }
///***********************************************

