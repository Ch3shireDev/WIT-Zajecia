///********************************************************************
void Application::Run(){
    Main01();
    }
///********************************************************************
void Application::Main01(){

    MyClass01 mC01_1(1, 2, 3);
    MyClass01 mC01_2(mC01_1);
    cout<<mC01_1.ToString()<<endl;
    mC01_1.SetCrC();
    cout<<mC01_1.ToString()<<endl;
    cout<<"cRc = "<<mC01_1.CRC()<<endl;
    mC01_2.x2 = 12;
    cout<<mC01_2.ToString()<<endl;
    MyClass01 mC01_3(1,1,1);
    mC01_3 = mC01_1.operator+(mC01_2);
    cout<<mC01_3.ToString()<<endl;

    MyClass01 mC01_4(1,2,1);
    mC01_4 = mC01_3 + mC01_1;
    cout<<mC01_4.ToString()<<endl;

    }
///********************************************************************
