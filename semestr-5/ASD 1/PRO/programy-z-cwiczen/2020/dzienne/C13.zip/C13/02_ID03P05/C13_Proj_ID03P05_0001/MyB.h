#ifndef MyB_H
#define MyB_H
#include "MyUtility.h"
#include "MyA.h"
class MyB: public MyA{
    public:
        MyB(int, int, int);
        string ToString(string myStr="");
        int X2();
        virtual MyA* Clone();
    protected:
        int x2;
    };
#include "MyB.cpp"
#endif // MyB_H
