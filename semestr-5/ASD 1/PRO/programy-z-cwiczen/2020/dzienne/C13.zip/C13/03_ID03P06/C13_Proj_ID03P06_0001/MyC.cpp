///***************************************
MyC::MyC(int x3, int x2, int x1, int x0):
    MyA(x1, x0), x3(x3), x2(x2) {}
///***************************************
string MyC::ToString(string myStr){
    return myStr +MyUtility::ToString(x3)+
                    ", " + MyUtility::ToString(x2) +
                    ", " + MyUtility::ToString(x1)+
                    ", " + MyUtility::ToString(x0);
    }
///*********************************************************
int MyC::X3(){return x3;}
int MyC::X2(){return x2;}
///*********************************************************
MyA* MyC::Clone(){
        return new MyC(x3, x2, x1, x0);}
///*********************************************************

