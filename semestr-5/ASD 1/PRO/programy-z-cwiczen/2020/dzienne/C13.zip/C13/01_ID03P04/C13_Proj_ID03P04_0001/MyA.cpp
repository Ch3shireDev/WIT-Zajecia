///*********************************************************
MyA::MyA(int x1, int x0):x1(x1), x0(x0){}
///*********************************************************
string MyA::ToString (string myStr){
    return myStr + MyUtility::ToString(x1) +
                 ", " + MyUtility::ToString(x0);
    }
///*********************************************************
int MyA::X3(){return 0;}
int MyA::X2(){return 0;}
int MyA::X1(){return x1;}
int MyA::X0(){return x0;}
///*********************************************************
MyA* MyA::Clone(){return new MyA(x1, x0) ;}
///*********************************************************
