///***************************************************
void Application::Run(){
    srand(time(0));
    Main05();
    }
///***************************************************
void Application::Main01(){
    cout<<"\n\n\tHappy new day ... !!!\n\n";
    }
///***************************************************
void Application::Main02(){
    MyA mA01(1,2);
    cout<<mA01.ToString("mA01: ")<<endl;
    }
///***************************************************
void Application::Main03(){
    MyB mA01(1, 2, 3);
    cout<<mA01.ToString("mA01: ")<<endl;
    }
///***************************************************
void Application::Main04(){
    MyA* mA01 =  new MyB(1, 2, 3);
    MyA* mA02 =  new MyC(1, 2, 3, 4);
    cout<<mA01->ToString("mA01: ")<<endl;
    cout<<"x2 = "<<mA01->X2()<<endl;
    cout<<"x1 = "<<mA01->X1()<<endl;
    cout<<"x0 = "<<mA01->X0()<<endl;
    cout<<mA02->ToString("mA02: ")<<endl;
    cout<<"x3 = "<<mA02->X3()<<endl;
    cout<<"x2 = "<<mA02->X2()<<endl;
    cout<<"x1 = "<<mA02->X1()<<endl;
    cout<<"x0 = "<<mA02->X0()<<endl;
    }
///***************************************************
void Application::Main05(){
    MyA** mT1, **mT2;
    int sT=15;
    mT1 =new MyA*[sT];
    mT2 =new MyA*[sT];

    for(int i =0; i< sT;++i)
        if(rand()%3>1) mT1[i] = new MyB(rand()%10,
                                                             rand()%10,
                                                             rand()%10);
        else  mT1[i] = new MyC(rand()%10,
                                                             rand()%10,
                                                             rand()%10,
                                                             rand()%10);
    for(int i =0; i< sT;++i)
        cout<<mT1[i]->ToString()<<endl;
    for(int i =0; i< sT;++i)
        mT2[i] = mT1[i]->Clone();
    cout<<"\n\n************************\n\n";

    for(int i =0; i< sT;++i)
        cout<<mT2[i]->ToString()<<endl;

    }
///***************************************************
