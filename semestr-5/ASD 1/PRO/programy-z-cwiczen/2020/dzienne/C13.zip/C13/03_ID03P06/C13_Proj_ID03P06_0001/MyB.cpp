///***************************************
MyB::MyB(int x2, int x1, int x0):
    MyA(x1, x0),x2(x2) {}
///***************************************
string MyB::ToString(string myStr){
    return myStr +MyUtility::ToString(x2)+
                    ", " + MyUtility::ToString(x1)+
                    ", " + MyUtility::ToString(x0);
    }
///*********************************************************
int MyB::X2(){return x2;}
///*********************************************************
MyA* MyB::Clone(){
        return new MyB(x2, x1, x0);}
///*********************************************************
