///***************************************************
void Application::Run(){
    srand(time(0));
    Main06();
    }
///***************************************************
void Application::Main01(){
    cout<<"\n\n\tHappy new day ... !!!\n\n";
    }
///***************************************************
void Application::Main02(){
    MyB mB(1,2,3);
    }
///***************************************************
void Application::Main03(){
    MyA * mA01;
    mA01 = new MyA(1, 2);
    cout<<mA01->ToString("mA01: ")<<endl;
    }
///***************************************************
void Application::Main04(){
    MyA * mA01;
    mA01 = new MyB(1, 2, 3);
    cout<<mA01->ToString("mA01: ")<<endl;
    cout<<"x1 = "<<mA01->X1()<<", x0 = "<<mA01->X0()<<endl;
    cout<<"x2 = "<<mA01->X2()<<endl;
    }
///***************************************************

void Application::Main05(){
    MyA * mA01;
    mA01 = new MyC(1, 2, 3, 4);
    cout<<mA01->ToString("mA01: ")<<endl;
    cout<<"x1 = "<<mA01->X1()<<", x0 = "<<mA01->X0()<<endl;
    cout<<"x2 = "<<mA01->X2()<<endl;
    cout<<"x3 = "<<mA01->X3()<<endl;
    }
///***************************************************
void Application::Main06(){
    MyA ** mT, **mT2;
    int sT = 15;

    mT = new MyA*[sT];
    mT2 = new MyA*[sT];

    for(int i = 0; i< sT;++i){
        if(rand()%3 <2) mT[i] = new  MyB(rand()%10,
                                                                 rand()%10,
                                                                 rand()%10);
        else  mT[i] = new  MyC(rand()%10,
                                                rand()%10,
                                                rand()%10,
                                                rand()%10);
        }
    for(int i = 0; i< sT; ++i)
        mT2[i] = mT[i]->Clone();

    for(int i = 0; i< sT; ++i)
        cout<<mT[i]->ToString()<<"\t\t\t"<<mT2[i]->ToString()<<endl;



    }
///***************************************************
