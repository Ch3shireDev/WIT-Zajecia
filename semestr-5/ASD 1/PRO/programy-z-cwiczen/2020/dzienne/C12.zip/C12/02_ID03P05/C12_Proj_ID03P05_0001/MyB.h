#ifndef MyB_H
#define MyB_H
#include "MyUtility.h"
#include "MyA.h"

class MyB:public MyA{
    public:
        MyB(int, int, int, int);
        void X2(int);
        int CrC();

        void SetCrC();
        int CRC();
        string ToString();



    private:
        int x3;

        int cRc;
    };

#include "MyB.cpp"
#endif //MyB_H
