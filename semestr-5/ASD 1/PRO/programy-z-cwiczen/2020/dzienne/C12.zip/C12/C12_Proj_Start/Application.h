#ifndef Application_H
#define Application_H
#include <iostream>
#include "MyUtility.h"


using std::cout;
using std::cin;
using std::string;
using std::endl;

class Application{
    public:
        void Run();
        void Main01();
        void Main02();
        void Main03();
        void Main04();
        void Main05();
        void Main06();
        void Main07();
        void Main08();
        void Main09();
        void Main10();
        void Main11();
        void Main12();
        void Main13();
        void Main14();
        void Main15();
    };



#include "Application.cpp"
#endif // Application_H
