#ifndef MyA_H
#define MyA_H
#include "MyUtility.h"
class MyA{
    public:
        ///MyA();
        MyA(int, int, int);
        string ToString();
        int CrC();
        void SetCrC();
        int CRC();

    protected:
        int x2;
    private:
        int x1;
        int x0;

        int cRc;
    };

#include "MyA.cpp"
#endif // MyA_H
