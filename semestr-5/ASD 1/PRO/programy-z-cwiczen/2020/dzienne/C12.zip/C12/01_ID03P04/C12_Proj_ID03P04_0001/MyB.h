#ifndef MyB_H
#define MyB_H
#include "MyA.h"
class MyB: public MyA{
    public:
        MyB(int, int, int, int);
        void X2(int);
        string ToString();
        int CrC();
        void SetCrC();
        int CRC();
    private:
        int x3;

        int cRc;
    };
#include "MyB.cpp"
#endif // MyB_H
