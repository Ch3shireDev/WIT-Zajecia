#ifndef MyB_H
#define MyB_H
#include "MyA.h"

class MyB:public MyA{
    public:
        MyB(int, int, int, int);
        void X2(int);

        int CrC();

        void SetCrC();
        int CRC();
        int X3();
        string ToString();

    private:
        int x3;

        int cRc;
    };
#include "MyB.cpp"
#endif // MyB_H
