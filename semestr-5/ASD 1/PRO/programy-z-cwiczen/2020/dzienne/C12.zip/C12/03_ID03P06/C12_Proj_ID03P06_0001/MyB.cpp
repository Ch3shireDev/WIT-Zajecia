///********************************************************
MyB::MyB(int x3, int x2, int x1, int x0):MyA(x2, x1, x0), x3(x3){}
///********************************************************
void MyB::X2(int x){x2 =x;}
///********************************************************
int MyB::CrC(){return 8*(x3%2) + MyA::CrC();}
///********************************************************
void MyB::SetCrC(){cRc = CrC();}
///********************************************************
int MyB::CRC(){SetCrC(); return cRc;}
///********************************************************
int MyB::X3(){return x3;}
///********************************************************
string MyB::ToString(){
//    return "["   + MyUtility::ToString(x3) +
//                 ", "  + MyA::ToString() +
//                 "] -> "  + MyUtility::ToString(CRC());

    return "("     + MyUtility::ToString(X3()) +
                 ", "  + MyUtility::ToString(MyA::X2()) +
                 ", "  + MyUtility::ToString(X1()) +
                 ", "  + MyUtility::ToString(X0()) +
                 ") -> "  + MyUtility::ToString(CRC());
    }
///********************************************************
///10, 10, 10, 8, 8, 8, 8
