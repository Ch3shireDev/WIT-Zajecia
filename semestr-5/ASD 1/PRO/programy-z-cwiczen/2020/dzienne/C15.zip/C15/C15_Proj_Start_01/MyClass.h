#ifndef MyClass_H
#define MyClass_H
#include "MyUtility.h"


#include "MyClass.cpp"
#endif // MyClass_H
