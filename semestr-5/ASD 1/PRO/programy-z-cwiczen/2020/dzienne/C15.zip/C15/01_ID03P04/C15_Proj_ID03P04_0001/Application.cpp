///***************************************************
void Application::Run(){
    srand(time(0));
    Main06();
    }
///***************************************************
void Application::Main01(){
    cout<<"\n\n\tHappy the last meeting ;) !!!\n\n";
    }
///***************************************************
//void Application::Main02(){
//    A0 myX(2,1);
//    cout<<"myX.x1 = "<<myX.x1<<endl;
//    cout<<"myX.x0 = "<<myX.x0<<endl;
//    }
/////***************************************************
//void Application::Main03(){
//    B0 myX(2, 1, 0);
//    cout<<"myX.A0::x1 = "<<myX.x1<<endl;
//    cout<<"myX.A0::x0 = "<<myX.A0::x0<<endl;
//    cout<<"myX.B0::x0 = "<<myX.x0<<endl;
//    }
/////***************************************************
//void Application::Main04(){
//    C0 myX(3, 2, 1, 0);
//    cout<<"myX.A0::x1 = "<<myX.x1<<endl;
//    cout<<"myX.A0::x0 = "<<myX.A0::x0<<endl;
//    cout<<"myX.B0::x0 = "<<myX.B0::x0<<endl;
//    cout<<"myX.C0::x0 = "<<myX.x0<<endl;
//    }
/////***************************************************
//void Application::Main05(){
//    B1 myX(2, 1, 0);
//    cout<<"myX.A0::x1 = "<<myX.x1<<endl;
//    cout<<"myX.A0::x0 = "<<myX.A0::x0<<endl;
//    cout<<"myX.B0::x0 = "<<myX.x0<<endl;
//    }
///***************************************************
void Application::Main06(){
    D0 myX(3, 2, 1, 0);
//    cout<<"myX.C0::x0 = "<<myX.x0<<endl;
//    cout<<"myX.B0::x1 = "<<myX.B0::x1<<endl;
//    cout<<"myX.B1::x1 = "<<myX.B1::x1<<endl;
    }
///***************************************************
///15, 15, 12, 12, 12, 12
