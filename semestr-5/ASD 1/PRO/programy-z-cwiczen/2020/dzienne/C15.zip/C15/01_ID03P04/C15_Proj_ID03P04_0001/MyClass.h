#ifndef MyClass_H
#define MyClass_H
#include "MyUtility.h"
class A0{
    public:
        A0(int, int);
        int x1;
        int x0;
    };
///*************************************************
class B0:public virtual A0{
    public:
        B0(int, int, int);
        int x0;
    };
///*************************************************
class B1:public virtual A0{
    public:
        B1(int, int, int);
        int x0;
    };
///*************************************************
class C0:public virtual B1, public virtual B0{
    public:
        C0(int, int, int, int);
        int x0;
    };
///*************************************************
class C1:public virtual B1, public virtual B0{
    public:
        C1(int, int, int, int);
        int x0;
    };
///*************************************************
class D0: public virtual C1, public virtual C0{
    public:
        D0(int, int, int, int);

    };
#include "MyClass.cpp"
#endif // MyClass_H
