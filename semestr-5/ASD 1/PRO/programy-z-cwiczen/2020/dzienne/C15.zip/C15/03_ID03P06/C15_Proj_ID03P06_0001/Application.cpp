///***************************************************
void Application::Run(){
    srand(time(0));
    Main07();
    }
///***************************************************
void Application::Main01(){
    cout<<"\n\n\tHappy the last meeting ;) !!!\n\n";
    }
///***************************************************
//void Application::Main02(){
//    A0 myX(1, 0);
//    cout<<"myX.A0::x1 = "<<myX.x1<<endl;
//    cout<<"myX.A0::x0 = "<<myX.x0<<endl;
//    }
/////***************************************************
//void Application::Main03(){
//    B0 myX(2, 1, 0);
//    cout<<"myX.A0::x1 = "<<myX.x1<<endl;
//    cout<<"myX.A0::x0 = "<<myX.A0::x0<<endl;
//    cout<<"myX.B0::x0 = "<<myX.x0<<endl;
//    }
/////***************************************************
//void Application::Main04(){
//    C0 myX(3, 2, 1, 0);
//    cout<<"myX.A0::x1 = "<<myX.x1<<endl;
//    cout<<"myX.A0::x0 = "<<myX.A0::x0<<endl;
//    cout<<"myX.B0::x0 = "<<myX.B0::x0<<endl;
//    cout<<"myX.C0::x0 = "<<myX.x0<<endl;
//    }
/////***************************************************
//void Application::Main05(){
//    D0 myX(3, 2, 1, 0);
//    cout<<"myX.A0::x1 = "<<myX.x1<<endl;
//    cout<<"myX.A0::x0 = "<<myX.A0::x0<<endl;
//    cout<<"myX.B0::x0 = "<<myX.B0::x0<<endl;
//    cout<<"myX.C0::x0 = "<<myX.C0::x0<<endl;
//    cout<<"myX.D0::x0 = "<<myX.x0<<endl;
//    }
///***************************************************
void Application::Main06(){
    C0 myX(3, 2, 1, 0);
    cout<<"myX.B1::A0::x0 = "<<myX.B1::AX0()<<endl;
    cout<<"myX.B0::A0::x0 = "<<myX.B0::AX0()<<endl;
    cout<<"myX.B1::A0::Adr(x0) = "<<myX.B1::AdrX0()<<endl;
    cout<<"myX.B0::A0::Adr(x0) = "<<myX.B0::AdrX0()<<endl;
//    cout<<"myX.A0::x0 = "<<myX.A0::x0<<endl;
//    cout<<"myX.B0::x0 = "<<myX.B0::x0<<endl;
//    cout<<"myX.C0::x0 = "<<myX.x0<<endl;
    }
///***************************************************
void Application::Main07(){
    D0 myX(3,2,1,0);
    }
///***************************************************
///10, 8, 7, 5
