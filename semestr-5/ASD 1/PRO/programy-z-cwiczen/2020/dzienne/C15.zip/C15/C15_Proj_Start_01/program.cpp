#include "Application.h"
int main(){
    Application myApplication;
    myApplication.Run();
    return 0;
    }
