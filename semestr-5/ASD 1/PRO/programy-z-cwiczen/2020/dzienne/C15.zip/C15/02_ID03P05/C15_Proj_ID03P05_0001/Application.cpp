///***************************************************
void Application::Run(){
    srand(time(0));
    Main05();
    }
///***************************************************
void Application::Main01(){
    cout<<"\n\n\tHappy the last meeting ;) !!!\n\n";
    }
///***************************************************
//void Application::Main02(){
//    A0 myX(1, 0);
//    cout<<"myX.x1 = "<< myX.x1<<endl;
//    cout<<"myX.x0 = "<< myX.x0<<endl;
//    }
/////***************************************************
//void Application::Main03(){
//    B0 myX(2, 1, 0);
//    cout<<"myX.A0::x1 = "<< myX.x1<<endl;
//    cout<<"myX.A0::x0 = "<< myX.A0::x0<<endl;
//    cout<<"myX.B0::x0 = "<< myX.x0<<endl;
//    }
/////***************************************************
//void Application::Main04(){
//    C0 myX(3, 2, 1, 0);
//    cout<<"myX.A0::x1 = "<< myX.x1<<endl;
//    cout<<"myX.A0::x0 = "<< myX.A0::x0<<endl;
//    cout<<"myX.B0::x0 = "<< myX.B0::x0<<endl;
//    cout<<"myX.C0::x0 = "<< myX.x0<<endl;
//    }
///***************************************************
void Application::Main05(){
    D0 myX(3, 2, 1, 0);

    cout<<"myX.x1 = "<<myX.x1<<endl;
//    cout<<"myX.B0::x1 = "<<myX.B0::X1()<<endl;
//    cout<<"myX.B1::x1 adr  = "<<myX.B1::Adr()<<endl;
//    cout<<"myX.B0::x1 adr  = "<<myX.B0::Adr()<<endl;
    }
///***************************************************
///25, 20, 20, 15, 15, 15, 10, 10, 10, 10
