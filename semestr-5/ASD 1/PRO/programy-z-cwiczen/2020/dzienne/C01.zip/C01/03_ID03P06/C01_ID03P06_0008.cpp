#include <cstdio>

int main(){
    int x, y;
    int * px;

    px = &x;
    printf("x? = ");
    scanf("%d", px);
    px = &y;
    printf("y? = ");
    scanf("%d", px);

    printf("x = %d, y = %d\n", x, y);

    return 0;
    }

