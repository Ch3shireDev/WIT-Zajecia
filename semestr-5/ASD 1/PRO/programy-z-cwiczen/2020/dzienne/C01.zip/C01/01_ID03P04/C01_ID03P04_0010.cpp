#include <cstdio>
///#include <stdio.h> C01_ID03P04_0001.c

int main(){
    int x, y;

    x = 5;
    y = x++;
    printf("x = %d, y = %d\n", x, y);
    printf("----------------------------\n");

    x = 5;
    y = ++x;
    printf("x = %d, y = %d\n", x, y);
    printf("----------------------------\n");

    x = 5;
    x++;
    printf("x = %d\n", x);
    printf("----------------------------\n");

    x = 5;
    ++x;
    printf("x = %d\n", x);
    printf("----------------------------\n");


    return 0;
    }
