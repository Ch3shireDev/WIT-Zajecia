#include <cstdio>
///#include <stdio.h> C01_ID03P05_0001.c

int main(){
    int x;

    printf("x? = ");
    fscanf(stdin, "%d", &x);

    printf("x = %d\n", x);



    return 0;
    }
