#include <cstdio>

int main(){
    int x;

    printf("x? = ");
    fscanf(stdin, "%d", &x);

    printf("x = %d\n", x);

    return 0;
    }

