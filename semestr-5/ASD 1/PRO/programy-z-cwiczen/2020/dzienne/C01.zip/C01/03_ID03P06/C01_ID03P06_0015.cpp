#include <cstdio>

int main(){
    double a;
    int *p1, *p2;
    double * pd;
    char * pc;

    pd = &a;

    p1 = p2 = (int*)&a;
    pc = (char*)&a;
    *p1 = 12;
    printf("x = %d, y = %d\n", *p1, *p2);
    ++p2;
    *p2 = 99;
    printf("x = %d, y = %d\n", *p1, *p2);
    printf("-------------------\n");
    printf("p1 = %p\n", (void*)p1);
    printf("p2 = %p\n", (void*)p2);
    printf("pd = %p\n", (void*)pd);
    ++pd;
    printf("pd = %p\n", (void*)pd);
    printf("pc = %p\n", (void*)pc);
    ++pc;
    printf("pc = %p\n", (void*)pc);
    ++pc;
    printf("pc = %p\n", (void*)pc);
    ++pc;
    printf("pc = %p\n", (void*)pc);

    return 0;
    }
