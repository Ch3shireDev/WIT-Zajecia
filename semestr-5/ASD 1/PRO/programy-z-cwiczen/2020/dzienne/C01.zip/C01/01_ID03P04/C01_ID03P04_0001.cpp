#include <cstdio>
///#include <stdio.h> C01_ID03P04_0001.c

int main(){
    printf("Konstantynopolitanczykowianeczka\n");
    fprintf(stdout,"Konstantynopolitanczykowianeczka\n");
    return 0;
    }
