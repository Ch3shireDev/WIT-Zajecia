#include <cstdio>
///#include <stdio.h> C01_ID03P04_0001.c

int main(){
    int x, y;
    int *px;

    px = &x;

    printf("x? = ");
    scanf("%d", px);

    px = &y;

    printf("y? = ");
    scanf("%d", px);

    printf("x = %d, y = %d\n", x, y);

    printf("x = %d, y = %d\n", x, *px);

    return 0;
    }
