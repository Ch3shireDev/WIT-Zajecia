#include <cstdio>
///#include <stdio.h> C01_ID03P05_0001.c

int main(){
    int x, y;
    int *px, *py;

    px = &x;
    py = &y;

    printf("x? = ");
    scanf("%d", px);

    printf("y? = ");
    scanf("%d", py);

    printf("x = %d, y = %d\n", x, y);
    printf("x = %d, y = %d\n", *px, *py);
    printf("------------------------\n");
    *px = 123;
    *py = 245;
    printf("x = %d, y = %d\n", x, y);
    printf("x = %d, y = %d\n", *px, *py);


    return 0;
    }
