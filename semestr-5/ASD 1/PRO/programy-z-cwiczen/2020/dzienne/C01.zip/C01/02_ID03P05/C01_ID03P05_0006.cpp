#include <cstdio>
///#include <stdio.h> C01_ID03P05_0001.c

int main(){
    int x, y;
    int * px;

    px = &x;

    printf("x? = ");
    scanf("%d", px);

    printf("x = %d\n", x);
    printf("x = %d\n", *px);

    px = & y;

    printf("y? = ");
    scanf("%d", px);

    printf("y = %d\n", y);
    printf("y = %d\n", *px);

    return 0;
    }
