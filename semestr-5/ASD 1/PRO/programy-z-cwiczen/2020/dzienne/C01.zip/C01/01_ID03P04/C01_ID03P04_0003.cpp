#include <cstdio>
///#include <stdio.h> C01_ID03P04_0001.c

int main(){
    int x;

    printf("x? = ");
    scanf("%d", &x);

    printf("x = %d\n", x);

    return 0;
    }
