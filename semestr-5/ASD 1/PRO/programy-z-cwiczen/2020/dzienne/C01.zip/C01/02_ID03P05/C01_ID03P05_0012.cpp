#include <cstdio>

int main(){
    double a;
    int * p1, *p2;

    p1 = p2 = (int*)&a;
    ++p2;
    *p1 = 5;
    *p2 = 7;

    printf("x = %d, y = %d\n", *p1, *p2);
    printf("&a = %p\n", (void*)&a);
    printf("p1 = %p\n", (void*)p1);
    printf("p2 = %p\n", (void*)p2);



    return 0;
    }
