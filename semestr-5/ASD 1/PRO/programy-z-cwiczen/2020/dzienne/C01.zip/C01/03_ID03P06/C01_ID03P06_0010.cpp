#include <cstdio>

int main(){
    int x, y;
    int *px, *py;

    px = &x;
    py = &y;
    printf("x? = ");
    scanf("%d", px);

    printf("y? = ");
    scanf("%d", py);


    printf("x = %d, y = %d\n", x, y);
    printf("x = %d, y = %d\n", *px, *py);

    *px = 122;
    *py = 999;

    printf("x = %d, y = %d\n", x, y);
    printf("x = %d, y = %d\n", *px, *py);


    return 0;
    }

