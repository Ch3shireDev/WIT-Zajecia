#include <cstdio>
///dla gcc
///#include <stdio.h>
///C01_ID03P05_0001.c

int main(){
    int x, y;
    int *px, *py, *pt;
    px = &x;
    py = &y;
    printf("x? = ");
    scanf("%d", px);
    printf("y? = ");
    scanf("%d", py);

    pt = px;
    px = py;
    py = pt;

    printf("x = %d, y = %d\n", x, y);
    printf("x = %d, y = %d\n", *px, *py);
    return 0;
    }
