#include <cstdio>
///#include <stdio.h> C01_ID03P04_0001.c

int main(){
    int x, y;
    int *px, *py;

    px = &x;
    py = &y;

    printf("x? = ");
    scanf("%d", px);

    printf("y? = ");
    scanf("%d", py);

    /**
    Pa�stwa kod
    */

    printf("x = %d, y = %d\n", x, y);
    printf("x = %d, y = %d\n", *px, *py);
    return 0;
    }
/**
x? = 7
y? = 5

x = 7, y = 5
x = 5, y = 7
15, 12, 10, 9, 9, 8, 8, 8, 7, 7, 7, 7
*/
