#include <cstdio>
///dla gcc
///#include <stdio.h>
///C01_ID03P06_0001.c

int main(){
    int x, y;

    x = 5;
    y = 7;

    printf("x = %d, y = %d\n", x, y);

    printf("x = %d, y = %d\n", y, x);

    printf("x = %d, y = \n", x, y);

    printf("x = %d, y = %d, z = %d, v = %d\n", x);



    return 0;
    }

