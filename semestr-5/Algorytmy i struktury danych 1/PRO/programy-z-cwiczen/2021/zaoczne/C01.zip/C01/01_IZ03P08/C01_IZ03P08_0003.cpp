#include <cstdio>

int main(){
    int x;

    printf("x? = ");
    scanf("%d", &x);
    
    printf("\n\tx = %d\n\n", x);
    
    return 0;
    }
