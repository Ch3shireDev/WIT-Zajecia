#include <cstdio>

int main(){
    int x, y;
    
    x = 65;
    y = 7;
    
    printf("x = %d\n", x);
    printf("x = %d\n");
    printf("x = %c\n", x);
    
    
    return 0;
    }
