#include <cstdio>

int main(){
    int x, y = 12;
    int* px;
    
    px = &x;
    
    printf("x? = ");
    
    scanf("%d", px);
    
    
    y = 2 * *px;
    
    printf("y = %d\n", y);
    
    y*=*px;

    printf("y = %d\n", y);
    
    return 0;
    }
