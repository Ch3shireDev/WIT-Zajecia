#include <cstdio>

int main(){
    int x, y;
    int * wx, *wy, *wt;

    wx = &x;
    wy = &y;

    printf("x? = ");
    scanf("%d", &x);

    printf("y? = ");
    scanf("%d", &y);
    
    
    /**
    
    
    
    */
    
    
    printf("x = %d, y =%d \n",x, y);
    printf("*wx = %d, *wy =%d \n",*wx, *wy);
    
    
    
    return 0;
    }

/**    
x? = 5
y? = 3    
    
x = 5, y = 3
*wx = 3, *wy = 5    
*/
/**    
x? = 1
y? = 3    
    
x = 1, y = 3
*wx = 1, *wy = 3    
*/
///30, 25, 25, 20, 20, 20, 12, 12, 12, 12, 10 ...
