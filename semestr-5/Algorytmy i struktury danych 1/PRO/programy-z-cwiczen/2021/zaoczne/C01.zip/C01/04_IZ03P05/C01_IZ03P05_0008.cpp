#include <cstdio>

int main(){
    int x, y;
    int* px;
    
    px = &x;
    
    printf("x? = ");

    scanf("%d", px);
    
    y=2**px;
    
    printf("y = %d\n", y);
    
    return 0;
    }
