#include <cstdio>

int main(){
    int x;
    int* px;
    printf("sizeof(int)  = %d\n", sizeof(int));
    printf("sizeof(char)  = %d\n", sizeof(char));
    printf("sizeof(double)  = %d\n", sizeof(double));
    
    px = &x;
    
    x = 12;
    //printf("x = %d");
    
    return 0;
    }
