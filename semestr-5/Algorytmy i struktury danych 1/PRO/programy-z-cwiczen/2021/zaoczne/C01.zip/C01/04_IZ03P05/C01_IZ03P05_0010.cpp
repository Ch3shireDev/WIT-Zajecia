#include <cstdio>

int main(){
    int x, y=20;
    int* px;
    
    px = &x;
    
    printf("x? = ");

    scanf("%d", px);
    
    y=20/ *px;
    
    printf("y = %d\n", y);
    
    return 0;
    }
