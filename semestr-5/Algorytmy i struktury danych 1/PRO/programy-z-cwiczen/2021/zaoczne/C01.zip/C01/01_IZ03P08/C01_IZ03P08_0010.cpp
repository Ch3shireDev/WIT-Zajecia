#include <cstdio>

int main(){
    int x,y=2;
    int* px;
    int**ppx;
    ppx = &px;
    px = &x;

    printf("x? = ");
    scanf("%d", &x);    
    printf("x = %d\n", x);
        
    y*=5***ppx;/// y*=5  <=>  y = y * 5
    
    printf("\ny = %d\n", y);
    
    return 0;
    }
