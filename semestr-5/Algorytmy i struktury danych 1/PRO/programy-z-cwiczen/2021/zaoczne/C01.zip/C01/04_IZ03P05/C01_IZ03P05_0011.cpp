#include <cstdio>

int main(){
    int x, y=20;
    int* px;
    int** ppx;
    ppx = &px;
    px = &x;
    
    printf("x? = ");

    scanf("%d", px);
    
    y=2***ppx;
    
    printf("y = %d\n", y);

    printf("x? = ");

    scanf("%d", *ppx);
    printf("x = %d\n", x);

    printf("&x = %p\n",(void*)&x);
    printf("px = %p\n",(void*)px);
    printf("&px = %p\n",(void*)&px);
    printf("*ppx = %p\n",(void*)*ppx);
    printf("&y = %p\n",(void*)&y);
        
    return 0;
    }
