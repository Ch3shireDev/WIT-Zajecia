#include <cstdio>

int main(){    
    double dx;    
    int * wx;
   
    wx = (int*)&dx;
    
    printf("x? = ");
    scanf("%d", wx);
    ++wx;
    printf("y? = ");
    scanf("%d", wx);
    --wx;
    printf("x = %d", *wx);
    ++wx;
    printf(", y = %d", *wx);
    
    return 0;
    }
