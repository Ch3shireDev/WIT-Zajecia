#include <cstdio>

int main(){
    int x, y;
    
    x = 65;
    y = 46;
    
    printf("x = %c\n", x);
    printf("x = %d, y = %c\n", x, y);
    
    return 0;
    }
