#include <cstdio>

int main(){
    int x, y = 12;
    int* px, *py = &y;
    int**ppx;
    ppx = & px;
    px = &x;
    
    printf("x? = ");
    
    scanf("%d", px);
    
    
    y = 2***ppx;
    
    printf("y = %d\n", y);
    
    *py*=**ppx;
    
    printf("y = %d\n", y);
    
    return 0;
    }
