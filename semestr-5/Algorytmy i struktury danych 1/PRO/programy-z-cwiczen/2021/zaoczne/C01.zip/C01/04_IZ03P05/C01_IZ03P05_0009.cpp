#include <cstdio>

int main(){
    int x, y=20;
    int* px;
    
    px = &x;
    
    printf("x? = ");

    scanf("%d", px);
    
    y*=*px;
    
    printf("y = %d\n", y);
    
    return 0;
    }
