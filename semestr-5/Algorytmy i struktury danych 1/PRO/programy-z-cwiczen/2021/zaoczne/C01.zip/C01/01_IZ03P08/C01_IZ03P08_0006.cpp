#include <cstdio>

int main(){
    int x;
    int* px;
    
    
    px = &x;
    x = 5;
    
    
    printf("x = %d\n", x);
    printf("*px = x = %d\n", *px);
    
    return 0;
    }
