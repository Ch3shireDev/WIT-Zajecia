#include <cstdio>

int main(){
    int x;
    int* px;
    
    px = &x;
    
    printf("x? = ");
    
    scanf("%d", px);
    
    printf("x = %d\n", x);
    printf("*px = %d\n", *px);
    
    printf("&x = %p\n",(void*)&x);
    printf("px = %p\n", (void*)px);
    
    
    return 0;
    }
