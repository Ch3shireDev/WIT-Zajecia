#include <cstdio>

int main(){
    int x,y;
    int* px;
    int**ppx;
    ppx = &px;
    px = &x;

    printf("x? = ");
    scanf("%d", &x);    
    printf("x = %d\n", x);
        
    y=5***ppx;
    
    printf("\ny = %d\n", y);
    
    return 0;
    }
