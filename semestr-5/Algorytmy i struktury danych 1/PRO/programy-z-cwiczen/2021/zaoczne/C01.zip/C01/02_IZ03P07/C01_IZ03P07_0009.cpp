#include <cstdio>

int main(){
    int x, y = 2;
    int* px;
    int**ppx;
    ppx = &px;
    px = &x;
    
    printf("x? = ");
    scanf("%d", px);

    y=2***ppx;
    
    printf("y = %d\n", y);
    
    return 0;
    }
