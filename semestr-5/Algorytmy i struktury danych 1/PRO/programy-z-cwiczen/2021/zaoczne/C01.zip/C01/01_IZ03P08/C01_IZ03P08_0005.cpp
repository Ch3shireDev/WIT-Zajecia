#include <cstdio>

int main(){
    int x;
    int* px;
    x = 5;
    px = &x;
    printf("&x = %p\n", &x);
    printf("px = %p\n", px);
    printf("&px = %p\n", &px);
    x = 12;
    //printf("x = %d");
    
    return 0;
    }
