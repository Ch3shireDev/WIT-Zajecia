#include <cstdio>

int main(){
    int x, y;
    x = 65;
    y = 7;

    printf("x = %d\n", x);
    printf("x = %c\n", x);
    
    printf("x = %d, y = %d\n", x, y);
    
    
    return 0;
    }
