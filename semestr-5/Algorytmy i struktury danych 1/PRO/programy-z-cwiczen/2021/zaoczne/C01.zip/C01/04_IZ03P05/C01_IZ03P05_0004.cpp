#include <cstdio>

int main(){
    int x;
    
    printf("x? = ");

    scanf("%d", &x);
    
    printf("x = %d\n", x);
    
    return 0;
    }
