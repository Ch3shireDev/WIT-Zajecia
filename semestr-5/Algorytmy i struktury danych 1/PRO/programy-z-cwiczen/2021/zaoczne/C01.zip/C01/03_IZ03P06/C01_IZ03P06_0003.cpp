#include <cstdio>

int main(){
    int x, y;
    
    x = 65;
    y = 7;
    
    printf("x = %d, y = %d\n", x, y);
    
    printf("x = %d, y = %d\n", y, x);
    
    return 0;
    }
