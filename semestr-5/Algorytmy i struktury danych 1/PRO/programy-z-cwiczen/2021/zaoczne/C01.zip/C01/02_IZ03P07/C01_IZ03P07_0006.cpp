#include <cstdio>

int main(){
    int x;
    int* px;
    
    px = &x;
    
    printf("x? = ");

    scanf("%d", px);

    printf("x = %d\n", *px);
    printf("x = %d\n", x);
    
    
    return 0;
    }
