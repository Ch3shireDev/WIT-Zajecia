#ifndef TabInt01_H
#define TabInt01_H
#include "MyUtility.h"
class TabInt01{
    public:
        TabInt01(int=0);
        TabInt01(const TabInt01&);
        ~TabInt01();
        TabInt01 operator=(const TabInt01&);
        int Length()const;
        int& operator[](int);
    private:
        int  sT;
        int* pT;
    };
///**********************************************************
ostream& operator<<(ostream&, TabInt01&);
///**********************************************************
#include "TabInt01.cpp"
#endif // TabInt01_H
