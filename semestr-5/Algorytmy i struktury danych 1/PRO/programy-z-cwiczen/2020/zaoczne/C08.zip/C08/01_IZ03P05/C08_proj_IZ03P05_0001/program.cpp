#include "Application.h"
#include "MyUtility.h"


int main(){
    srand(time(0));
    Application application;
    application.Run();
    return 0;
    }
