///**********************************************************
TabInt01::TabInt01(int sT){
    if(sT<1){
        this->sT = 0;
        this->pT =NULL;
        }
    else{
        this->sT = sT;
        this->pT =new int[this->sT];
        }
    }
///**********************************************************
TabInt01::TabInt01(const TabInt01& t){
    if(t.sT<1){
        this->sT = 0;
        this->pT =NULL;
        }
    else{
        this->sT = t.sT;
        this->pT =new int[this->sT];
        for(int i=0; i< this->sT;++i)
            this->pT[i] = t.pT[i];
        }
    }
///**********************************************************
TabInt01::~TabInt01(){
    delete[] this->pT;
    this->sT = 0;
    this->pT = NULL;
    }
///**********************************************************
TabInt01 TabInt01::operator=(const TabInt01& t){
    if(NULL!=this->pT) delete[] this->pT;
    if(t.sT<1){
        this->sT = 0;
        this->pT =NULL;
        }
    else{
        this->sT = t.sT;
        this->pT =new int[this->sT];
        for(int i=0; i< this->sT;++i)
            this->pT[i] = t.pT[i];
        }
    return *this;
    }
///**********************************************************
int TabInt01::Length()const{return this->sT;}
///**********************************************************
int& TabInt01::operator[](int i){return this->pT[i];}
///**********************************************************
///**********************************************************
ostream& operator<<(ostream& s, TabInt01& t){
    for(int i=0; i< t.Length();++i){
        s.width(2);
        s<<t[i];
        s<<" ";
        }
    return s;
    }
///**********************************************************
