///**********************************************************
TabInt01::TabInt01(int sT){
    if( sT<1){
        this->pT = NULL;
        this->sT = 0;
        }
    else{
        this->pT = new int[sT];
        this->sT = sT;
        }
    }
///**********************************************************
TabInt01::TabInt01(const TabInt01& t){
    if( t.sT<1){
        this->pT = NULL;
        this->sT = 0;
        }
    else{
        this->pT = new int[t.sT];
        this->sT = t.sT;
        for(int i =0; i< sT;++i)
            this->pT[i]=t.pT[i];
        }
    }
///**********************************************************
TabInt01::~TabInt01(){
    //cout<<"destruktor TabInt01\n";
    delete[] pT;
    pT = NULL;
    sT = 0;
    }
///**********************************************************
TabInt01 TabInt01::operator=(const TabInt01 & t){
    if(this->pT!=NULL) delete[] this->pT;
    if( t.sT<1){
        this->pT = NULL;
        this->sT = 0;
        }
    else{
        this->pT = new int[t.sT];
        this->sT = t.sT;
        for(int i =0; i< sT;++i)
            this->pT[i]=t.pT[i];
        }
    return *this;
    }
///**********************************************************
int TabInt01::Length(){return sT;}
///**********************************************************
int& TabInt01::operator[](int i){return this->pT[i];}
///**********************************************************
///**********************************************************
ostream& operator<<(ostream& s, TabInt01& t){
    for(int i=0; i<t.Length();++i)
        s<<t[i]<<" ";
    return s;
    }
///**********************************************************
