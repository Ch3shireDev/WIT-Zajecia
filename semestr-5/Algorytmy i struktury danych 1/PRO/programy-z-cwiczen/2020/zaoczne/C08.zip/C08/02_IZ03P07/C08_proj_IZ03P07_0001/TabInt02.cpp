///***********************************************************************
TabInt02::TabInt02(int sT1, int sT2){
    if(sT1<1){
        this->sT = 0;
        this->pT= NULL;
        }
    else{
        this->sT = sT1;
        pT = new TabInt01[sT];
        if(sT2>0)   for(int i=0;i<sT1;++i) pT[i] = TabInt01(sT2);
        }
    }
///***********************************************************************
TabInt02::TabInt02(const TabInt02& t){
    if(t.sT<1){
        this->sT = 0;
        this->pT = NULL;
        }
    else{
        this->sT = t.sT;
        this->pT = new TabInt01[sT];
        for(int i=0; i<sT;++i)
            this->pT[i] = t.pT[i];
        }
    }
///***********************************************************************
TabInt02::~TabInt02(){
    delete[] pT;
    this->pT = NULL;
    this->sT= 0;
    }
///***********************************************************************
TabInt02 TabInt02::operator=(const TabInt02& t){
    if(NULL!=this->pT) delete[] this->pT;
    if(t.sT<1){
        this->sT = 0;
        this->pT = NULL;
        }
    else{
        this->sT = t.sT;
        this->pT = new TabInt01[sT];
        for(int i=0; i<sT;++i)
            this->pT[i] = t.pT[i];
        }
    return *this;
    }
///***********************************************************************
int TabInt02::Length(){return sT;}
///***********************************************************************
int TabInt02::GetLength(int i){
    if(0==i) return sT;
    return pT[0].Length();
    }
///***********************************************************************
TabInt01& TabInt02::operator[](int i){return pT[i];}
///***********************************************************************
///***********************************************************************
ostream& operator<<(ostream& s, TabInt02& t){
    for(int i=0; i< t.Length();++i)
        s<<t[i]<<endl;
    return s;
    }
///***********************************************************************
