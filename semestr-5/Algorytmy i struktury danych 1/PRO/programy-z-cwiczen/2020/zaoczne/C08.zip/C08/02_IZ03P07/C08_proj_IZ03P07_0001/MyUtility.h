#ifndef MyUtility_H
#define MyUtility_H

#include <iostream>
#include <sstream>
#include <ctime>
#include<cstdlib>

using std::cout;
using std::cin;
using std::endl;
using std::string;
using std::ostringstream;
using std::ostream;
using std::istream;



class MyUtility{
    public:
        static int MyRead(const char*);
        static string ToString(int);
        static string ToString(double);
        };
#include "MyUtility.cpp"

#endif // MyUtility_H
