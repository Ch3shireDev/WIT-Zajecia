///**********************************************************
TabInt02::TabInt02(int sT1, int sT2){
    if( sT1<1){
        this->pT = NULL;
        this->sT = 0;
        }
    else{
        this->pT = new TabInt01[sT1];
        this->sT = sT1;
        if(sT2>0)
            for(int i = 0; i<sT;++i)
                pT[i] = TabInt01(sT2);
        }
    }
///**********************************************************
TabInt02::TabInt02(const TabInt02& t){
     if( t.sT<1){
        this->pT = NULL;
        this->sT = 0;
        }
    else{
        this->pT = new TabInt01[t.pT[0].Length()];
        this->sT = t.sT;
        for(int i =0; i< sT;++i)
            this->pT[i]=t.pT[i];
        }
    }
///**********************************************************
TabInt02::~TabInt02(){
    delete[] pT;
    pT =NULL;
    sT = 0;
    }
///**********************************************************
TabInt02 TabInt02::operator=(const TabInt02 & t){
    if(this->pT!=NULL) delete[] this->pT;
    if( t.sT<1){
        this->pT = NULL;
        this->sT = 0;
        }
    else{
        this->pT = new TabInt01[t.pT[0].Length()];
        this->sT = t.sT;
        for(int i =0; i< sT;++i)
            this->pT[i]=t.pT[i];
        }
    return *this;
    }
///**********************************************************
int TabInt02::Length(){return sT;}
///**********************************************************
TabInt01& TabInt02::operator[](int i){return this->pT[i];}
///**********************************************************
int TabInt02::GetLength(int i){if(0==i) return sT; return pT[0].Length();}
///**********************************************************
///**********************************************************
ostream& operator<<(ostream& s, TabInt02& t){
    for(int i=0; i<t.Length();++i)
        s<<t[i]<<endl;
    return s;
    }
///**********************************************************

///**********************************************************
