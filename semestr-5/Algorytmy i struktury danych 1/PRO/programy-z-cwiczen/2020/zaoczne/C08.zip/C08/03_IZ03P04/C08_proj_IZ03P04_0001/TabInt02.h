#ifndef TabInt02_H
#define TabInt02_H
#include "MyUtility.h"
#include "TabInt01.h"
class TabInt02{
    public:
        TabInt02(int=0, int=0);
        TabInt02(const TabInt02&);
        ~TabInt02();
        TabInt02 operator=(const TabInt02&);
        int Length();
        int GetLength(int)const;
        TabInt01& operator[](int);

    private:
        int  sT;
        TabInt01* pT;
    };
///**********************************************************
ostream& operator<<(ostream&, TabInt02&);
///**********************************************************
#include "TabInt02.cpp"
#endif // TabInt02_H

