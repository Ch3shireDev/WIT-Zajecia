///********************************************************************
void Test01(){TabInt01 t(999999999);}
void Test02(TabInt01 pom){}
///********************************************************************
void Application::Run(){
    Main07();
    }
///********************************************************************
void Application::Main01(){
    cout<<"\n\n\t\tHappy new  week end !!!\n\n";
    }
///********************************************************************
//void Application::Main02(){
//    TabInt01 t(5);
//    for(int i = 0;i<t.sT;++i)
//        t.pT[i] = 2*i;
//    for(int i = 0;i<t.sT;++i)
//        cout<<t.pT[i]<<endl;
//    }
/////********************************************************************
//void Application::Main03(){
//    for(int i=0; i<99999;++i)
//        Test01();
//    }
/////********************************************************************
//void Application::Main04(){
//    TabInt01 t(5);
//    for(int i = 0;i<t.sT;++i)
//        t.pT[i] = 2*i;
//    for(int i = 0;i<t.sT;++i)
//        cout<<t.pT[i]<<endl;
//    Test02(t);
//
//    TabInt01 t2(5);
//    for(int i = 0;i<t.sT;++i)
//        t2.pT[i] = 99999;
//    cout<<"\n\n*****************\n\n";
//    for(int i = 0;i<t.sT;++i)
//        cout<<t.pT[i]<<endl;
//    cout<<"\n\n*****************\n\n";
//    for(int i = 0;i<t.sT;++i)
//        cout<<t2.pT[i]<<endl;
//    }
/////********************************************************************
//void Application::Main05(){
//    TabInt01 t(5);
//    for(int i = 0;i<t.sT;++i)
//        t.pT[i] = 2*i;
//    for(int i = 0;i<t.sT;++i)
//        cout<<t.pT[i]<<endl;
//
//    TabInt01 t2;
//    ///t2.operator=(t);
//    t2 = t;
//
//    cout<<"\n\n*****************\n\n";
//    for(int i = 0;i<t.sT;++i)
//        cout<<t2.pT[i]<<endl;
//    }
///********************************************************************
void Application::Main06(){
    TabInt01 t(5);
    t[0] = 20;
    cout<<t[0]<<endl;
    t.operator[](1) = 17;
    cout<<t[1]<<endl;
    cout<<"\n\n**********\n\n"<<t<<endl;
    }
///********************************************************************
void Application::Main07(){
    TabInt02 t(5,4);
    for(int i =0; i<t.GetLength(0);++i)
        for(int j =0; j<t.GetLength(1);++j)
            t[i][j]=i+j;

    cout<<t;
    }
///********************************************************************
