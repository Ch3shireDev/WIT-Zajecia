#ifndef TabInt02_H
#define TabInt02_H
#include "MyUtility.h"
#include "TabInt01.h"
class TabInt02{


    };
#include "TabInt02.cpp"
#endif // TabInt02_H

