///********************************************************************
void Test01( ){TabInt01 t(999999999);}
void Test02(TabInt01 pom){}
///********************************************************************
void Application::Run(){
    Main07();
    }
///********************************************************************
//void Application::Main01(){
//    TabInt01 t(5);
//
//    for(int i=0;i< t.sT;++i)
//        t.pT[i] = i*2;
//    for(int i=0;i< t.sT;++i)
//        cout<<t.pT[i]<<" ";
//    cout<<endl;
//    }
/////********************************************************************
//void Application::Main02(){
//    for(int i=0;i< 99999;++i)
//        Test01();
//    }
/////********************************************************************
//void Application::Main03(){
//    TabInt01 t(5);
//    for(int i = 0; i<t.sT;++i)
//        t.pT[i] = i*2;
//    for(int i = 0; i<t.sT;++i)
//        cout<<t.pT[i]<<" ";
//    cout<<"\n\n*******************\n\n";
//    Test02(t);
//    TabInt01 t2(5);
//    for(int i = 0; i<t2.sT;++i)
//        t2.pT[i] = 999;
//    for(int i = 0; i<t.sT;++i)
//        cout<<t.pT[i]<<" ";
//    cout<<"\n\n*******************\n\n";
//    for(int i = 0; i<t.sT;++i)
//        cout<<t2.pT[i]<<" ";
//    cout<<"\n\n*******************\n\n";
//
//    }
/////********************************************************************
//void Application::Main04(){
//    TabInt01 t(5);
//    for(int i = 0; i<t.sT;++i)
//        t.pT[i] = i*2;
//    for(int i = 0; i<t.sT;++i)
//        cout<<t.pT[i]<<" ";
//    cout<<"\n\n*******************\n\n";
//    Test02(t);
//    TabInt01 t2(7);
//    for(int i = 0; i<t2.sT;++i)
//        t2.pT[i] = 999;
//    for(int i = 0; i<t2.sT;++i)
//        cout<<t2.pT[i]<<" ";
//    cout<<"\n\n*******************\n\n";
//
//    ///t2.operator=(t);
//    t2 = t;
//    for(int i = 0; i<t2.sT;++i)
//        cout<<t2.pT[i]<<" ";
//    cout<<"\n\n*******************\n\n";
//    }
///********************************************************************
void Application::Main05(){
    TabInt01 t(5);
    for(int i=0; i< t.Length();++i)
        t.operator[](i) = 2*i;
    for(int i=0; i< t.Length();++i)
        cout<<t[i]<<" ";
    cout<<endl;
    }
///********************************************************************
void Application::Main06(){
    TabInt01 t(5);
    for(int i=0; i< t.Length();++i)
        t.operator[](i) = 2*i;

    cout<<t<<endl;
    }
///********************************************************************
void Application::Main07(){
    TabInt02 t(4, 5);
    for(int i=0; i< t.GetLength(0);++i)
        for(int j=0; j< t.GetLength(1);++j)
            t[i][j] = i+j;

    cout<<t;
    }
///********************************************************************
