///********************************************************************
void Test01(){TabInt01 t(999999999);}
void Test02(TabInt01 pom){}
///********************************************************************
void Application::Run(){
    Main07();
    }
///********************************************************************
//void Application::Main01(){
//    TabInt01 t1(5);
//    for(int i=0; i< t1.sT;++i)
//        t1.pT[i] = i*2;
//    for(int i=0; i< t1.sT;++i)
//        cout<<t1.pT[i]<<" ";
//    cout<<endl;
//    }
/////********************************************************************
//void Application::Main02(){
//    for(int i=0; i< 99999;++i)
//        Test01();
//    }
/////********************************************************************
//void Application::Main03(){
//    TabInt01 t1(5);
//    for(int i=0; i< t1.sT;++i)
//        t1.pT[i] = i*2;
//    for(int i=0; i< t1.sT;++i)
//        cout<<t1.pT[i]<<" ";
//    cout<<endl;
//    Test02(t1);
//
//    TabInt01 t2(5);
//    for(int i=0; i< t2.sT;++i)
//        t2.pT[i] = 9;
//
//    for(int i=0; i< t1.sT;++i)
//        cout<<t1.pT[i]<<" ";
//    cout<<endl;
//
//    cout<<t1.pT<<endl;
//    cout<<t2.pT<<endl;
//
//    }
/////********************************************************************
//void Application::Main04(){
//    TabInt01 t1(5);
//    for(int i=0; i< t1.sT;++i)
//        t1.pT[i] = i*2;
//    for(int i=0; i< t1.sT;++i)
//        cout<<t1.pT[i]<<" ";
//    cout<<endl;
//
//    TabInt01 t2;
//
//    ///t2.operator=(t1);
//    t2 = t1;
//    for(int i=0; i< t2.sT;++i)
//        cout<<t2.pT[i]<<" ";
//    cout<<endl;
//
//    }
///********************************************************************
void Application::Main05(){
    TabInt01 t1(5);
    for(int i=0; i< t1.Length();++i)
        t1[i] = 2*i;
    for(int i=0; i< t1.Length();++i)
        cout<<t1[i]<<" ";
    cout<<endl;
    }
///********************************************************************
void Application::Main06(){
    TabInt01 t1(5);
    for(int i=0; i< t1.Length();++i)
        t1[i] = 2*i;
    cout<<t1<<endl;
    }
///********************************************************************
void Application::Main07(){
    TabInt02 t(6,8);
    for(int i = 0; i< t.GetLength(0);++i)
        for(int j =0; j<t.GetLength(1);++j)
            t[i][j] = i+j;
            /// t.operator[](i).operator[](j) = i + j;
    for(int i = 0; i< t.GetLength(0);++i, cout<<endl)
        for(int j =0; j<t.GetLength(1);++j){
            cout.width(2);
            cout<<t[i][j];
            cout<<" ";
            }
    cout<<"\n\n**************************************\n\n";
    for(int i = 0; i< t.GetLength(0);++i)
        cout<<t[i]<<endl;
    cout<<"\n\n**************************************\n\n";
    cout<<t<<endl;
    }
///********************************************************************
