#include <cstdio>
#include <cstdlib>

int main(){
    double x;
    char * t;

    t =(char*)&x;

    ///t[i] <=> *(t+i)

    t[0] = 'a';
    t[1] = 'b';
    t[2] = 'c';
    t[3] = 'd';
    t[4] = 'e';
    t[5] = 'r';
    t[6] = 't';
    t[7] = '\0';


    for(int  i =0; i<8;++i)
        printf("%c\n",t[i]);

    printf("%s\n",t);

    return 0;
    }
