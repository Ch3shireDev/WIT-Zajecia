#include <cstdio>
#include <cstdlib>

int main(){
    int *t0, *t1, *t2;
    int*  *t;
    int s0 = 3, s1 = 5;
    int i, j;

    t=(int**)malloc(sizeof(int*)*s0);

    t0 = (int*)malloc(sizeof(int)*s1);
    t1 = (int*)malloc(sizeof(int)*s1);
    t2 = (int*)malloc(sizeof(int)*s1);

    t[0] = t0;
    t[1] = t1;
    t[2] = t2;

    for(j = 0; j < s1; ++j)
        t[0][j] = 0 + j;
    for(j = 0; j < s1; ++j)
        t[1][j] = 1 + j;
    for(j = 0; j < s1; ++j)
        t[2][j] = 2 + j;


    for(j = 0; j < s1; ++j)
        printf("[%2d]",t[0][j]);
    printf("\n");
    for(j = 0; j < s1; ++j)
        printf("[%2d]",t[1][j]);
    printf("\n");
    for(j = 0; j < s1; ++j)
        printf("[%2d]",t[2][j]);
    printf("\n");
    printf("-----------------------------\n");


    free(t2);
    free(t1);
    free(t0);

    return 0;
    }
