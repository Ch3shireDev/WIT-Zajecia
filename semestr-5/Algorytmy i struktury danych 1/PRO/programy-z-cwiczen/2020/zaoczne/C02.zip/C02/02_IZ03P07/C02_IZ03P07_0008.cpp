#include <cstdio>
#include <cstdlib>

int main(){
    char *t;
    int s = 8;

    t =(char*) malloc(s*sizeof(char));


    t[0] = 'a'; ///*(t+0) = 'a';
    t[1] = 'b';
    t[2] = 'c';
    t[3] = 'd';
    t[4] = 'e';
    t[5] = 'f';
    t[6] = 'g';
    t[7] = 'h';

    for(int i = 0; i<s;++i)
        printf("%c\n",t[i]);

    free(t);

    return 0;
    }
