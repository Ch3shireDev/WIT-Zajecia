#include <cstdio>
#include <cstdlib>

int main(){
    int s0 =3, s1 = 5;
    int * t0, *t1, *t2;
    int* *t;
    int i, j;

    t = (int**)malloc(sizeof(int*)*s0);

    t0 = (int*)malloc(sizeof(int)*s1);
    t1 = (int*)malloc(sizeof(int)*s1);
    t2 = (int*)malloc(sizeof(int)*s1);

    t[0] = t0;
    t[1] = t1;
    t[2] = t2;


    for(i = 0; i<s1; ++i)
        t[0][i] = 0 + i;

    for(i = 0; i<s1; ++i)
        t[1][i] = 1 + i;

    for(i = 0; i<s1; ++i)
        t[2][i] = 2 + i;

    for(i = 0; i < s1; ++i){
        printf("[%2d]", t0[i]);
        }
    printf("\n");

    for(i = 0; i < s1; ++i){
        printf("[%2d]", t1[i]);
        }
    printf("\n");

    for(i = 0; i < s1; ++i){
        printf("[%2d]", t2[i]);
        }
    printf("\n");


    free(t2);
    free(t1);
    free(t0);

    return 0;
    }
