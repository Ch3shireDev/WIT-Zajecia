#include <cstdio>
#include <cstdlib>

int main(){
    int s = 5;
    int * t, *k;

    t =(int*)malloc(s*sizeof(int));


    for(int  i =0; i<s;++i)
        t[i] = i;


    for(int  i =0; i<s;++i)
        printf("%d\n",t[i]);

    ///t[i] <=> *(t+i) <=> *(i+t) <=> i[t]

    printf("---------------\n");

    for(int  i =0; i<s;++i)
        printf("%d\n",i[t]);

    2[t] = 99;///<=>t[2] = 99
    2[++t]=123;///
    --t;

    printf("---------------\n");

    for(int  i =0; i<s;++i)
        printf("%d\n",i[t]);

    printf("---------------\n");

    k = t+s;
    while(t<k){
        printf("%d\n",0[t++]);
        }

    t-=s;
    free(t);

    return 0;
    }
