#include <cstdio>
#include <cstdlib>

int main(){
    int s = 5;
    char * t;

    t =(char*)malloc(s*sizeof(char));

    ///t[i] <=> *(t+i)

    t[0] = 'a';
    t[1] = 'b';
    t[2] = 'c';
    t[3] = 'd';
    t[4] = 'e';


    for(int  i =0; i<s;++i)
        printf("%c\n",t[i]);


    return 0;
    }
