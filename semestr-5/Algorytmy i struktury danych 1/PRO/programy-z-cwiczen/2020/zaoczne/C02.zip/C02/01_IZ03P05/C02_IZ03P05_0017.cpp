#include <cstdio>
#include <cstdlib>

int main(){
    int s0 =3, s1 = 5;
    int* *t;
    int i, j;

    t = (int**)malloc(sizeof(int*)*s0);

    for(j = 0; j< s0; ++j)
        t[j] = (int*)malloc(sizeof(int)*s1);

    for(j = 0; j< s0; ++j)
        for(i = 0; i<s1; ++i)
            t[j][i] = j + i;

    for(j = 0; j< s0; ++j){
        for(i = 0; i<s1; ++i)
            printf("[%2d]", t[j][i]);
        printf("\n");
        }
    printf("---------------------------\n");
    for(j = 0; j< s0; ++j){
        for(i = 0; i<s1; ++i)
            printf("[%2d]", *(*(t+j)+i));
        printf("\n");
        }

    for(j = 0; j< s0; ++j)
        free(t[j]);
    free(t);

    return 0;
    }
