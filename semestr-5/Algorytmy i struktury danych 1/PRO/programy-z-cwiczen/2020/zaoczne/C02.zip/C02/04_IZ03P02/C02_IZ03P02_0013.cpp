#include <cstdio>
#include <cstdlib>

int main(){
    int* fib;
    int n;

    printf("n? = ");
    scanf("%d", &n);

    fib = (int*) malloc(sizeof(int)*n);

    if(n>0) fib[0] = 1;
    if(n>1) fib[1] = 1;

    for(int i = 2; i< n;++i)
        fib[i] = fib[i-1] + fib[i-2];


    for(int i = 0; i< n;++i)
        printf("%d\n",fib[i]);


    free(fib);

    return 0;
    }
/**
--------------------
n? = 0
--------------------
n? = 1
1
--------------------
n? = 2
1
1
--------------------
n? = 3
1
1
2
--------------------
n? = 8
1
1
2
3
5
8
13
21
--------------------

15, 12, 12, 12, 10, 10, 10, 10, 8, 8, 8, 8, 8

*/
