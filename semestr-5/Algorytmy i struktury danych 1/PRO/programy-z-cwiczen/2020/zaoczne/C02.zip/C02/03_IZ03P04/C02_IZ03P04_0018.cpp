#include <cstdio>
#include <cstdlib>

int main(){
    int* *t;
    int *t0, *t1, *t2;
    int s0 = 3, s1 = 5;
    int i, j;

    t = (int**) malloc(sizeof(int*)*s0);

    t0 = (int*)malloc(sizeof(int)*s1);
    t1 = (int*)malloc(sizeof(int)*s1);
    t2 = (int*)malloc(sizeof(int)*s1);


    t[0] = t0;
    t[1] = t1;
    t[2] = t2;

    for(i = 0; i < s0; ++i )
        for(j = 0; j < s1; ++j)
            t[i][j] = i +j;

    for(i = 0; i < s0; ++i ){
        for(j = 0; j < s1; ++j)
            printf("[%2d]", t[i][j]);
        printf("\n");
        }

    printf("----------------------------\n");

    for(i = 0; i < s0; ++i ){
        free(t[i]);

    free(t);
    return 0;
    }
