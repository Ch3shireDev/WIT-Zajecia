#include <cstdio>
#include <cstdlib>

int main(){
    double x;
    char *t;

    t = (char*)&x;


    ///*(t+0) = 'a';
    t[0] = 'a';
    t[1] = 'b';
    t[2] = 'c';
    t[3] = 'd';
    t[4] = 'e';
    t[5] = 'f';
    t[6] = 'g';
    t[7] = 'h';

    for(int i = 0; i < 8; ++i)
        printf("%c\n",t[i]);





    return 0;
    }
