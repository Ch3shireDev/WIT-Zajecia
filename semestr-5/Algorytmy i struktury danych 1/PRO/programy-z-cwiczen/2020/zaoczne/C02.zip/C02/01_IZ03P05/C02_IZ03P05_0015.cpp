#include <cstdio>
#include <cstdlib>

int main(){
    int s0 =3, s1 = 5;
    int * t0, *t1, *t2;
    int* *t;
    int i, j;

    t = (int**)malloc(sizeof(int*)*s0);

    t[0] = (int*)malloc(sizeof(int)*s1);
    t[1] = (int*)malloc(sizeof(int)*s1);
    t[2] = (int*)malloc(sizeof(int)*s1);


    for(j = 0; j< s0; ++j)
        for(i = 0; i<s1; ++i)
            t[j][i] = j + i;


    for(j = 0; j< s0; ++j){
        for(i = 0; i<s1; ++i)
            printf("[%2d]", t[j][i]);
        printf("\n");
        }




    free(t[2]);
    free(t[1]);
    free(t[0]);

    return 0;
    }
