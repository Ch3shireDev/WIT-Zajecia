#include <cstdio>
#include <cstdlib>

int main(){
    int n;
    int * t;

    printf("n? = ");
    scanf("%d", &n);

    t = (int*)malloc(sizeof(int)*n);

    if(n>0) t[0] =1;
    if(n>1) t[1] =1;

    for(int i = 2; i < n; ++i)
        t[i ] = t[i-1] + t[i-2];

    for(int i = 0; i < n; ++i)
        printf("%d\n", t[i]);
    return 0;
    }
/**
n? = 8
1
1
2
3
5
8
13
21
--------------------------
n? = 0
--------------------------
n? = 1
1
--------------------------
n? = 2
1
1
--------------------------
18, 15, 12, 12, 11, 11, 11, 10, 10, 10, 10,
*/
