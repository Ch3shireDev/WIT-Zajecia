#include <cstdio>
#include <cstdlib>

int main(){
    int *t;
    int s = 8;

    t = (int*)malloc(sizeof(int)*s);

    for(int i = 0; i<s; ++i)
        t[i] = i;

    for(int i = 0; i<s; ++i)
        printf("%d\n", t[i]);

    printf("-------------\n");


    ///t[i] <=> *(t + i) <=> *(i + t) <=> i[t]


    2[t] = 99;
    2[++t] = 123;
    --t;
    for(int i = 0; i<s; ++i)
        printf("%d\n", t[i]);

    printf("-------------\n");

    free(t);

    return 0;
    }
