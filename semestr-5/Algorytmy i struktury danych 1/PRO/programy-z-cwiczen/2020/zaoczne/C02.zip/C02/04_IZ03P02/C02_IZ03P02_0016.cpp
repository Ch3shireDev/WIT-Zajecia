#include <cstdio>
#include <cstdlib>

int main(){
    int* *t;
    int* t0, *t1, *t2;
    int s0 = 3, s1 =5;
    int i, j;

    t = (int**) malloc(sizeof(int)*s0);

    t0 = (int*) malloc(sizeof(int)*s1);
    t1 = (int*) malloc(sizeof(int)*s1);
    t2 = (int*) malloc(sizeof(int)*s1);


    for(j = 0; j < s1; ++j)
        t0[j] = 0 + j;

    for(j = 0; j < s1; ++j)
        t1[j] = 1 + j;

    for(j = 0; j < s1; ++j)
        t2[j] = 2 + j;


    for(j = 0; j < s1; ++j)
        printf("[%2d]",t0[j]);
    printf("\n");

    for(j = 0; j < s1; ++j)
        printf("[%2d]",t1[j]);
    printf("\n");

    for(j = 0; j < s1; ++j)
        printf("[%2d]",t2[j]);
    printf("\n");

    printf("---------------------\n");


    free(t2);
    free(t1);
    free(t0);

    free(t);

    return 0;
    }
