///********************************************************************
void Application::Run(){
    Main04();
    }
///********************************************************************
void Application::Main01(){
    cout<<"\n\t\tTest test test\n";
    }
///********************************************************************
void Application::Main02(){
    MyClass01 mC01;
    mC01.Ini(1,2,3);
    cout<<"x2 = "<<mC01.x2<<", x1 = "<<mC01.x1<<", x0 = "<<mC01.x0<<endl;
    }
///********************************************************************
void Application::Main03(){
    MyClass01 mC01;
    mC01.Ini(1,2,3);
    string myStr = "x2 = " + MyUtility::ToString(mC01.x2) +
                   ", x1 = " + MyUtility::ToString(mC01.x1) +
                   ", x0 = " + MyUtility::ToString(mC01.x0);

    cout<<myStr<<endl;
    }
///********************************************************************
void Application::Main04(){
    MyClass01 mC01;
    mC01.Ini(1,2,3);
    cout<<mC01.ToString()<<endl;
    }
///********************************************************************
