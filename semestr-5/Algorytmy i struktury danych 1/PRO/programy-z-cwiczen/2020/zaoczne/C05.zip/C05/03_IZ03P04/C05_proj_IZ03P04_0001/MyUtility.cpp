///***********************************************
int MyUtility::MyRead(string myStr){
    int x;
    cout<<myStr;
    cin>>x;
    return x;
    }
///***********************************************
string MyUtility::ToString(int x){
    string myStr;
    ostringstream convert;
    convert<<x;
    myStr = convert.str();
    return myStr;
    }
///***********************************************
string MyUtility::ToString(double  x){
    string myStr;
    ostringstream convert;
    convert<<x;
    myStr = convert.str();
    return myStr;
    }
///***********************************************
