#include <iostream>
#include "Application.h"
#include "MyUtility.h"
using std::cout;
using std::cin;
using std::endl;
using std::string;


int main(){
    Application application;
    application.Run();

    return 0;
    }
