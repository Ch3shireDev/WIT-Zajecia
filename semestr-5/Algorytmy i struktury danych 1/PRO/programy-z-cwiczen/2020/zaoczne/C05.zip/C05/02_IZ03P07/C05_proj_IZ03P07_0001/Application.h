#ifndef Application_H
#define Application_H
#include <iostream>
#include "MyUtility.h"
#include "MyClass01.h"
using std::cout;
using std::cin;
using std::endl;
using std::string;
class Application{
    public:
        void Run();
        void Main01();
        void Main02();
        void Main03();
        void Main04();
        void Main05();
        void Main06();
        void Main07();
        void Main08();
        void Main09();
        void Main10();
        void Main11();
        void Main12();
        void Main13();
        void Main14();
        void Main15();
        void Main16();
        void Main17();
        void Main18();
        void Main19();
        void Main20();
    };
#include "Application.cpp"
#endif // Application_H
