///**********************************************************
int MyUtility::MyRead(string myStr){
    int x;
    cout<<myStr;
    cin>>x;
    return x;
    }
///**********************************************************
string MyUtility::ToString(int x){
    ostringstream convert;
    convert<<x;
    return convert.str();
    }
///**********************************************************
string MyUtility::ToString(double x){
    ostringstream convert;
    convert<<x;
    return convert.str();
    }
///**********************************************************
