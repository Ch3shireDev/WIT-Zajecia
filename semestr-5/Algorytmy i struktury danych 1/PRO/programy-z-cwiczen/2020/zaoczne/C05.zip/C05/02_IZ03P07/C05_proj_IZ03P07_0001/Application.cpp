///***********************************************************
void Application::Run(){
    Main04();
    }
///***********************************************************
void Application::Main01(){
    cout<<"Test ... test ... test ..."<<endl;
    }
///***********************************************************
void Application::Main02(){
    string myStr;
    myStr = "x = " + MyUtility::ToString(MyUtility::MyRead());
    cout<<myStr<<endl;
    }
///***********************************************************
void Application::Main03(){
    MyClass01 mC01;
    mC01.Ini(1,2,3);
    cout<<"x2 = "<<mC01.x2<<", x1 = "<<mC01.x1<<", x0 = "<<mC01.x0<<endl;
    }
///***********************************************************
void Application::Main04(){
    MyClass01 mC01;
    mC01.Ini(1,2,3);
    cout<<mC01.ToString()<<endl;
    }
///***********************************************************
