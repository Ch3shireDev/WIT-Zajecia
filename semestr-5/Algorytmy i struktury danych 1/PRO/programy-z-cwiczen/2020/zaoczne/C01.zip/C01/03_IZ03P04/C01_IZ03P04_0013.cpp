#include <cstdio>

int main(){
    double x;
    int * p1;

    p1 = (int*)&x;


    printf("a? = ");
    scanf("%d", p1);
    ++p1;
    printf("b? = ");
    scanf("%d", p1);
    --p1;
    printf("a = %d, b = ", *p1);
    ++p1;
    printf("%d\n", *p1);



    return 0;
    }
