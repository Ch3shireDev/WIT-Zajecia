#include <cstdio>

int main(){
    double x;
    int * p1, *p2;

    p1 = p2 = (int*)&x;
    ++p2;

    printf("a? = ");
    scanf("%d", p1);
    printf("b? = ");
    scanf("%d", p2);

    printf("a = %d, b = %d\n", *p1, *p2);
    printf("t[0] = %d, t[1] = %d\n", p1[0], p1[1]);


    printf("adres w p1 = %p\n",(void*)p1);
    printf("adres w p2 = %p\n",(void*)p2);


    return 0;
    }
