#include <cstdio>

int main(){
    int x, y;
    int * wx, *wy, *wt;

    wx = &x;
    wy = &y;

    printf("x? = ");
    scanf("%d", wx);
    printf("y? = ");
    scanf("%d", wy);


    /**
    Pa�stwa kod
    */

    wt = wx;
    wx = wy;
    wy = wt;

    printf("x = %d, y = %d\n",x, y);
    printf("*wx = %d, *wy = %d\n",*wx, *wy);


    return 0;
    }
/**

x? = 5
y? = 7


x = 5, y= 7
*wx = 7, *wy = 5


15, 12, 10, 9, 9, 8, 8, 8, 7, 7, 7, 7
*/
