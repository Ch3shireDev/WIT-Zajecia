#include <cstdio>
/// #include <stdio.h> C01_IZ03P02_0001.c


int main(){
    int x, y;
    int *px, *py;
    int z=3;

    px =&x;

    py = px;
    printf("x? = ");
    scanf("%d", py);

    printf("x = %d\n", x);
    printf("x = %d\n", *px);
    printf("x = %d\n", *py);
    printf("-----------------------\n");
    *py =547;

    printf("x = %2d\n", x);
    x =3;
    printf("x = %*d\n",z, *px);
    printf("x = %d\n", *py);


    return 0;
    }
