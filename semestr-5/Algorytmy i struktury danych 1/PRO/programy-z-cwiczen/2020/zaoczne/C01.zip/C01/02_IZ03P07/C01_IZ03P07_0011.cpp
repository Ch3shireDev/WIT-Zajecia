#include <cstdio>

int main(){
    double x;
    int *p1, *p2;

    p1 = p2 =(int*)&x;
    printf("adres p1 = %p, adres p2 = %p\n",(void*)p1, (void*)p2);
    ++p2;
    printf("adres p1 = %p, adres p2 = %p\n",(void*)p1, (void*)p2);

    *p1 = 5;
    *p2 = 7;

    printf("p1 = %d, p2 = %d\n", *p1, *p2);


    return 0;
    }
