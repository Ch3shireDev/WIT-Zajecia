#include <cstdio>
///#include <stdio.h> C01_IZ03P07_0001.c


int main(){
    int x;

    x = 5;

    printf("x = %d\n",x);


    return 0;
    }
