#include <cstdio>
///#include <stdio.h> C01_IZ03P07_0001.c


int main(){
    int x, y;
    int * wx;
    x = 5;
    wx = &x;

    printf("x? = ");
    scanf("%d", wx);

    y =23;
    printf("x = %d, y = %d\n",x, y);
    printf("x = %d, y = \n",x, y);


    printf("x = %d, y = %d  %d  %d\n",x);

    *wx = 12;
    printf("x = %d, y = %d\n",y, x);
    printf("*wx = %d\n",*wx);


    return 0;
    }
