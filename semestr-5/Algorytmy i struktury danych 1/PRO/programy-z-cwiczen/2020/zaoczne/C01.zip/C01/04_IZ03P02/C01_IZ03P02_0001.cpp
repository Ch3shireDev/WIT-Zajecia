#include <cstdio>
/// #include <stdio.h> C01_IZ03P02_0001.c


int main(){
    printf("Konstantynopolitanczykowianeczka\n");
    fprintf(stdout,"Konstantynopolitanczykowianeczka\n");


    return 0;
    }
