#include <cstdio>
/// #include <stdio.h> C01_IZ03P02_0001.c


int main(){
    int x;

    x = 65;

    printf("x = %d\n",x);

    printf("zn = %c\n",(char)x);

    /// "x = %d"

    return 0;
    }
