#include <cstdio>

int main(){
    int x;
    int * wx;

    wx = &x;

    printf("x? = ");
    scanf("%d", wx);

    printf("x = %d\n",x);



    return 0;
    }
