#include <cstdio>
/// #include <stdio.h> C01_IZ03P02_0001.c


int main(){
    int x;
    int *px;

    px =&x;


    printf("x? = ");
    scanf("%d", px);

    printf("x = %d\n", x);


    return 0;
    }
