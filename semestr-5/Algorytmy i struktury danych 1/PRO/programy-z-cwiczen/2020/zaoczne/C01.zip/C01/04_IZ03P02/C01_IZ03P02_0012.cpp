#include <cstdio>
/// #include <stdio.h> C01_IZ03P02_0001.c


int main(){
    printf("size of int     = %d\n", sizeof(int));
    printf("size of double  = %d\n", sizeof(double));

    printf("size of int*    = %d\n", sizeof(int*));
    printf("size of double* = %d\n", sizeof(double*));


    return 0;
    }
