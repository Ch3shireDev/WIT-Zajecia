#include <cstdio>
/// #include <stdio.h> C01_IZ03P02_0001.c


int main(){
    int x, y;
    int *px, *py;

    px =&x;
    py =&y;

    printf("x? = ");
    scanf("%d", px);
    printf("y? = ");
    scanf("%d", py);

    /**

    Pa�stwa kod

    */

    printf("x = %d, y = %d\n", x, y);
    printf("*px = %d, *py = %d\n", *px, *py);

    return 0;
    }
/**
x? = 12
y? = 6
x = 12, y = 6
*px = 6, *py = 12

15, 12, 10, 9, 9, 8, 8, 8, 7, 7, 7, 7
*/
