#include <cstdio>

int main(){
    int x, y;
    int * wx, *wy, *wt;

    wx = &x;
    wy = &y;

    printf("x? = ");
    scanf("%d", &x);

    printf("y? = ");
    scanf("%d", &y);


    wt = wx;
    wx = wy;
    wy = wt;

/**

*/

    printf("x = %d, y =%d \n",x, y);
    printf("*wx = %d, *wy =%d \n",*wx, *wy);


    /**
    x? = 5
    y? = 7
    x = 5, y = 7
    *wx = 7, *wy = 5


    15, 12, 10, 8, 8, 7, 7, 7, 6, 6, 6, 6

    */



    return 0;
    }
