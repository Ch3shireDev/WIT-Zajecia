#include <cstdio>
/// #include <stdio.h> C01_IZ03P04_0001.c

int main(){
    int x;
    int * wx, *wy;
    wx = &x;

    wy = wx;

    printf("x? = ");
    scanf("%d", wx);

    printf("x = %d\n",x);

    printf("*wx = %d\n", *wy);

    return 0;
    }
