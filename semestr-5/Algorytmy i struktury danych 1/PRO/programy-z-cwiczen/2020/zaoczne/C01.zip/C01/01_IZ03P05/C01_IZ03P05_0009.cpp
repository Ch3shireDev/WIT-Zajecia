#include <cstdio>

int main(){
    double x;
    int * wx, *wy;

    wx = wy = (int*)&x;
    printf("wx = %p\n",(int*)wx);
    printf("wy = %p\n",(int*)wy);
    ++wy;
    printf("wy = %p\n",(int*)wy);


    printf("x? = ");
    scanf("%d", wx);

    printf("y? = ");
    scanf("%d", wy);

    printf("x = %d, y =%d\n", *wx, *wy);


    return 0;
    }
