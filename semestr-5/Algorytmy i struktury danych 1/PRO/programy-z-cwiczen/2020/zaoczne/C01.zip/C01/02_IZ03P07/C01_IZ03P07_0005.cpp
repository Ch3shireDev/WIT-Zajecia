#include <cstdio>
///#include <stdio.h> C01_IZ03P07_0001.c


int main(){
    int x;
    int * wx;
    x = 5;
    wx = &x;

    printf("x? = ");
    scanf("%d", wx);

    printf("x = %d\n",x);

    *wx = 12;
    printf("x = %d\n",x);
    printf("*wx = %d\n",*wx);


    return 0;
    }
