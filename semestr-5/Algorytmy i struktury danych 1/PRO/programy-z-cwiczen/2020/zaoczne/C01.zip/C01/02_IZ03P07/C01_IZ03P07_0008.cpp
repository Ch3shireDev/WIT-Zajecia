#include <cstdio>

int main(){
    int x;
    int *p1, **p2, ***p3;

    p1 = &x;
    p2 = &p1;
    p3 = &p2;


    printf("x? = ");
    scanf("%d", p1);

    printf("x = %d \n",x);
    printf("*p1 = %d\n",*p1);
    printf("**p2 = %d\n",**p2);
    printf("***p3 = %d\n",***p3);

    printf("x? = ");
    scanf("%d", *p2);

    printf("x = %d \n",x);
    printf("*p1 = %d\n",*p1);
    printf("**p2 = %d\n",**p2);
    printf("***p3 = %d\n",***p3);

    return 0;
    }
