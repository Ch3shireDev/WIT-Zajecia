#include <cstdio>
/// #include <stdio.h> C01_IZ03P02_0001.c


int main(){
    double x, *px;
    int *p1,  *p2;

    px = &x;
    p1 = p2 = (int*)&x;
    ++p2;

    *p1 = 7;
    *p2 = 12;

    printf("a = %d, b = %d\n", *p1, *p2);
    printf("p1 = %p, p2 = %p\n",(void*)p1, (void*)p2);
    printf("px = %p\n",(void*)px);
    ++px;
    printf("px = %p\n",(void*)px);


    return 0;
    }
