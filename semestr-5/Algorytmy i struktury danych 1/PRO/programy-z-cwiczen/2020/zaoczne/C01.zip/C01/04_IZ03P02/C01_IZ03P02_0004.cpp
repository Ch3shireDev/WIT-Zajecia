#include <cstdio>
/// #include <stdio.h> C01_IZ03P02_0001.c


int main(){
    int x;


    printf("x? = ");
    scanf("%d", &x);

    printf("x = %d\n", x);


    return 0;
    }
