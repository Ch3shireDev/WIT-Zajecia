#include <cstdio>

int main(){
    int x, y;

    x = 5;
    y = x++;
    printf("x = %d, y = %d\n",x,y);

    x = 5;
    y = ++x;
    printf("x = %d, y = %d\n",x,y);


    x = 5;
    x++;
    printf("x = %d\n",x);

    x = 5;
    ++x;
    printf("x = %d\n",x);



    return 0;
    }
