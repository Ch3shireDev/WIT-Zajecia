#include <cstdio>
#include <cstdlib>

///***********************************************
int MyRead(const char*);
///***********************************************
///***********************************************
int MyRead(const char* myStr){
    int x;
    printf("%s", myStr);
    scanf("%d", &x);
    return x;
    }
///***********************************************
///***********************************************
int main(){
    int x = MyRead("x? = ");
    printf("x = %d\n", x);

    return 0;
    }

