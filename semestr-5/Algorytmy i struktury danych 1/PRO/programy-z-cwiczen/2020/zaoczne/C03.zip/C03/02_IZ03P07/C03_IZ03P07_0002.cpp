#include <cstdio>
#include <cstdlib>

///***********************************************
int MyRead(const char*);
void MySwap(int*, int*);
void MySwap(int&, int&);
///***********************************************
///***********************************************
int MyRead(const char* myStr){
    int x;
    printf("%s", myStr);
    scanf("%d",&x);
    return x;
    }
///***********************************************
void MySwap(int* a, int* b){
    int tmp;
    tmp = *a;
    *a = *b;
    *b = tmp;
    }
///***********************************************
void MySwap(int& a, int& b){
    int tmp;
    tmp = a;
    a = b;
    b = tmp;
    }
///***********************************************
///***********************************************
int main(){
    int x, y;
    x = MyRead("x? = ");
    y = MyRead("y? = ");
    printf("x = %d, y = %d\n",x, y);
    MySwap(&x, &y);
    printf("x = %d, y = %d\n",x, y);

    return 0;
    }
