#include <cstdio>
#include <cstdlib>

typedef int ala;
///***********************************************
int MyRead(const char*);
///***********************************************
///***********************************************
int MyRead(const char* myStr){
    int x;
    printf("%s", myStr);
    scanf("%d",&x);
    return x;
    }
///***********************************************
///***********************************************
int main(){
    int x;
    ala y;
    y = 12;
    x = y;
    printf("x = %d, y = %d\n", x, y);
    return 0;
    }
