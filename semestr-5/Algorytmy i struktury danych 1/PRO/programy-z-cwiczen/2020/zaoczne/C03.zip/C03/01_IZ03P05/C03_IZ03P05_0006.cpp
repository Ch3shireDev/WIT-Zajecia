#include <cstdio>
#include <cstdlib>

///***********************************************
int MyRead(const char*);
void MySwap(int*, int*);
void MySort(int*, int*, int*);
///***********************************************
///***********************************************
int MyRead(const char* myStr){
    int x;
    printf("%s", myStr);
    scanf("%d", &x);
    return x;
    }
///***********************************************
void MySwap(int* x, int* y){
    int tmp;
    tmp = *x;
    *x = *y;
    *y = tmp;
    }
///***********************************************
void MySort(int* x, int* y, int* z){
    if(*x>*y) MySwap(x,y);
    if(*y>*z) MySwap(y,z);
    if(*x>*y) MySwap(x,y);
    }
///***********************************************
///***********************************************
int main(){
    int a0, b0, c0;
    int a1, b1, c1;
    a0 = MyRead("a? = ");
    b0 = MyRead("b? = ");
    c0 = MyRead("c? = ");

    a1 = a0;
    b1 = b0;
    c1 = c0;

    MySort(&a1, &b1, &c1);

    printf("(%d, %d, %d)->(%d, %d, %d)", a0, b0, c0, a1, b1, c1);

    return 0;
    }

/**
a? = 5
b? = 3
c? = 7
(5, 3, 7) -> (3, 5, 7)
*/
/**
a? = 9
b? = 3
c? = 1
(9, 3, 1) -> (1, 3, 9)
*/
///10, 10, 10, 8, 8, 8, 8
