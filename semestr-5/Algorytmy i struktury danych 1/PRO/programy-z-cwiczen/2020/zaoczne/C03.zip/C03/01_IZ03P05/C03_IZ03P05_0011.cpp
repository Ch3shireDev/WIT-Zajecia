#include <cstdio>
#include <cstdlib>

///***********************************************


///***********************************************
int MyRead(const char*);
void Print1(int);
void Print2(int);
void Print3(int);
///***********************************************
///***********************************************
int MyRead(const char* myStr){
    int x;
    printf("%s", myStr);
    scanf("%d", &x);
    return x;
    }
///***********************************************
void Print1(int x){printf("Print1 : %d\n", x);}
///***********************************************
void Print2(int x){printf("\t\tPrint2 : %d\n", x);}
///***********************************************
void Print3(int x){printf("\t\t\t\tPrint3 : %d\n", x);}
///***********************************************
///***********************************************
int main(){
    int x = MyRead("x? = ");
    Print1(x);
    Print2(x);
    Print3(x);

    return 0;
    }
