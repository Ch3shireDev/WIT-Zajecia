#include <cstdio>
#include <cstdlib>

typedef void (*FF0)(int);
///***********************************************
int MyRead(const char*);
void Print1(int);
void Print2(int);
void Print3(int);
///***********************************************
///***********************************************
int MyRead(const char* myStr){
    int x;
    printf("%s", myStr);
    scanf("%d", &x);
    return x;
    }
///***********************************************
void Print1(int x){printf("Print1 -> %d\n",x);}
///***********************************************
void Print2(int x){
    for(int i=0; i<x;++i) printf(" ");
    printf("Print2 -> %d\n",x);
    }
///***********************************************
void Print3(int x){
    for(int i=0; i<x;++i) printf("--");
    printf("> Print3 -> %d\n",x);
    }
///***********************************************
///***********************************************
int main(){
    int x =3, y = 5;
    FF0 p1, p2, p3;
    Print1(x);
    Print2(x);
    Print3(x);

    p1 = Print1;
    p2 = Print2;
    p3 = Print3;

    printf("\n---------------------\n\n");

    p1(y);
    p2(y);
    p3(y);

    return 0;
    }
