#include <cstdio>
#include <cstdlib>

typedef void(*FF0)(int);
///***********************************************
int MyRead(const char*);
void Print1(int);
void Print2(int);
void Print3(int);
///***********************************************
///***********************************************
int MyRead(const char* myStr){
    int x;
    printf("%s", myStr);
    scanf("%d",&x);
    return x;
    }
///***********************************************
void Print1(int x){
    printf("Print1:\n");
    }
///***********************************************
void Print2(int x){
    int i;
    for(i = 0; i<x;++i)printf("-");
    printf("Print2:\n");
    }
///***********************************************
void Print3(int x){
    int i, j;
    for(j = 0; j<x;++j, printf("Print3:\n"))
        for(i = 0; i<=j;++i)printf("-");
    }
///***********************************************
///***********************************************
int main(){
    FF0 p1, p2, p3;
    Print1(3);
    Print2(3);
    Print3(3);


    p1 =Print1;
    p2 =Print2;
    p3 =Print3;

    p1(2);
    p2(2);
    p3(5);

    printf("Adres Print1: %p, Adres p1: %p\n", (void*)Print1, (void*)p1);
    printf("Adres Print2: %p, Adres p2: %p\n", (void*)Print2, (void*)p2);
    printf("Adres Print3: %p, Adres p3: %p\n", (void*)Print3, (void*)p3);

    return 0;
    }
