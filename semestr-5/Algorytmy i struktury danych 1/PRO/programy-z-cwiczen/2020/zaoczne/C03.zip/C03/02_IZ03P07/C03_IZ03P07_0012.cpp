#include <cstdio>
#include <cstdlib>

typedef void(*FF0)(int);
///***********************************************
int MyRead(const char*);
void Print1(int);
void Print2(int);
void Print3(int);
///***********************************************
///***********************************************
int MyRead(const char* myStr){
    int x;
    printf("%s", myStr);
    scanf("%d",&x);
    return x;
    }
///***********************************************
void Print1(int x){
    printf("Print1:\n");
    }
///***********************************************
void Print2(int x){
    int i;
    for(i = 0; i<x;++i)printf("-");
    printf("Print2:\n");
    }
///***********************************************
void Print3(int x){
    int i, j;
    for(j = 0; j<x;++j, printf("Print3:\n"))
        for(i = 0; i<=j;++i)printf("-");
    }
///***********************************************
///***********************************************
int main(){
    int sT=7, i;
    FF0 *t;
    t = (FF0*) malloc(sizeof(FF0)*sT);

    t[0] = Print1;
    t[1] = Print1;
    t[2] = Print3;
    t[3] = Print1;
    t[4] = Print2;
    t[5] = Print1;
    t[6] = Print3;

    for(i=0; i<sT;++i) t[i](i);


    free(t);
    return 0;
    }
