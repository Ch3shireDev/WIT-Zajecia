#include <cstdio>
#include <cstdlib>

///***********************************************
int MyRead(const char*);
int Add(int, int);
int Add(int, int, int);
///***********************************************
///***********************************************
int MyRead(const char* myStr){
    int x;
    printf("%s", myStr);
    scanf("%d", &x);
    return x;
    }
///***********************************************
int Add(int a, int b){return a + b;}
///***********************************************
int Add(int a, int b, int c){return a + b + c;}
///***********************************************
///***********************************************
int main(){
    int x0, x1, x2;
    x0 = MyRead("x0? = ");
    x1 = MyRead("x1? = ");
    x2 = MyRead("x2? = ");
    printf("%d + %d = %d\n", x0, x1, Add(x0, x1));
    printf("%d + %d + %d = %d\n", x0, x1, x2, Add(x0, x1, x2));

    return 0;
    }

