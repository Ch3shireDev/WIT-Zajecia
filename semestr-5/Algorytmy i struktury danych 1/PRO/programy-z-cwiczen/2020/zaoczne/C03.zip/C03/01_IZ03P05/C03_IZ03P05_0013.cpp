#include <cstdio>
#include <cstdlib>

///***********************************************
typedef void (*FF0)(int);
///***********************************************
int MyRead(const char*);
void Print1(int);
void Print2(int);
void Print3(int);
///***********************************************
///***********************************************
int MyRead(const char* myStr){
    int x;
    printf("%s", myStr);
    scanf("%d", &x);
    return x;
    }
///***********************************************
void Print1(int x){printf("Print1 : %d\n", x);}
///***********************************************
void Print2(int x){printf("\t\tPrint2 : %d\n", x);}
///***********************************************
void Print3(int x){printf("\t\t\t\tPrint3 : %d\n", x);}
///***********************************************
///***********************************************
int main(){
    int sT = 5, i;
    FF0* tF;

    tF = (FF0*)malloc(sizeof(FF0)*sT);

    tF[0] = Print1;
    tF[1] = Print1;
    tF[2] = Print2;
    tF[3] = Print1;
    tF[4] = Print3;


    for(i = 0; i<sT;++i)tF[i](i);


    return 0;
    }
