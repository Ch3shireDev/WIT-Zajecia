#include <cstdio>
#include <cstdlib>

///***********************************************
int MyRead(const char*);
void MySwap(int*, int*);
void MySwapPt(int**, int**);
void MySort(int*, int*, int*);
void MySortPt(int**, int**, int**);
///***********************************************
///***********************************************
int MyRead(const char* myStr){
    int x;
    printf("%s", myStr);
    scanf("%d", &x);
    return x;
    }
///***********************************************
void MySwap(int* x, int* y){
    int tmp;
    tmp = *x;
    *x = *y;
    *y = tmp;
    }
///***********************************************
void MySwapPt(int** x, int** y){
    int* tmp;
    tmp = *x;
    *x = *y;
    *y = tmp;
    }
///***********************************************
void MySort(int* x, int* y, int* z){
    if(*x>*y) MySwap(x,y);
    if(*y>*z) MySwap(y,z);
    if(*x>*y) MySwap(x,y);
    }
///***********************************************
void MySortPt(int** x, int** y, int** z){
    if(**x>**y) MySwapPt(x,y);
    if(**y>**z) MySwapPt(y,z);
    if(**x>**y) MySwapPt(x,y);
    }
///***********************************************
///***********************************************
int main(){
    int a, b, c;
    int *pa, *pb, *pc;
    a = MyRead("a? = ");
    b = MyRead("b? = ");
    c = MyRead("c? = ");

    pa = &a;
    pb = &b;
    pc = &c;

    MySortPt(&pa, &pb, &pc);

    printf("(%d, %d, %d)->(%d, %d, %d)", a, b, c, *pa, *pb, *pc);

    return 0;
    }

