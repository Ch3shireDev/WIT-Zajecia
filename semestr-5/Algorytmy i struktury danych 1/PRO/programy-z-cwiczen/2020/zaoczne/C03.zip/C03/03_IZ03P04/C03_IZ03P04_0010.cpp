#include <cstdio>
#include <cstdlib>

typedef void(*FF0)(int);
///***********************************************
int MyRead(const char*);
void Print1(int);
void Print2(int);
void Print3(int);
void Aqq(int);
///***********************************************
///***********************************************
int MyRead(const char* myStr){
    int x;
    printf("%s", myStr);
    scanf("%d", &x);
    return x;
    }
///***********************************************
void Print1(int x){
    printf("Print1-%d\n",x);
    }
///***********************************************
void Print2(int x){
    for(int i =0; i<x;++i) printf(" ");
    printf("Print2-%d\n",x);
    }
///***********************************************
void Print3(int x){
    for(int i =0; i<x;++i) printf("--");
    printf("> Print3-%d\n",x);
    }
///***********************************************
void Aqq(int x){printf("A q q, a q q, a q q\n");}
///***********************************************
///***********************************************
int main(){
    int x = 3;
    int y = 5;
    FF0 p1, p2, p3, aq;
    Print1(x);
    Print2(x);
    Print3(x);

    p1 =Print1;
    p2 =Print2;
    p3 =Print3;

    printf("\n----------------------------\n\n");

    p1(y);
    p2(y);
    p3(y);
    printf("\n----------------------------\n\n");

    printf("Adresy: Print1: %p       Print2:%p       Print3:%p\n",
           (void*)Print1, (void*)Print2, (void*)Print3);
    printf("Adresy: p1:     %p       p2:    %p       p3:    %p\n",
           (void*)p1, (void*)p2, (void*)p3);

    aq = Aqq;
    Aqq(200);
    aq(99);

    return 0;
    }

