#include <cstdio>
#include <cstdlib>

///***********************************************
int MyRead(const char*);
void MySwap(int*, int*);
void MySort(int*, int*, int*);
///***********************************************
///***********************************************
int MyRead(const char* myStr){
    int x;
    printf("%s", myStr);
    scanf("%d", &x);
    return x;
    }
///***********************************************
void MySwap(int* a, int* b){
    int tmp;
    tmp = *a;
    *a = *b;
    *b = tmp;
    }
///***********************************************
void MySort(int* a, int* b, int* c){
    if(*a>*b) MySwap(a, b);
    if(*b>*c) MySwap(b, c);
    if(*a>*b) MySwap(a, b);
    }
///***********************************************
///***********************************************
int main(){
    int x0 , y0, z0;
    int x1 , y1, z1;
    x0 = MyRead("x? = ");
    y0 = MyRead("y? = ");
    z0 = MyRead("z? = ");

    x1 = x0;
    y1 = y0;
    z1 = z0;

    MySort(&x1, &y1, &z1);

    printf("(%d, %d, %d) -> (%d, %d, %d)\n",x0, y0, z0, x1, y1, z1);

    return 0;
    }

/**
x? = 8
y? = 3
z? = 5
(8, 3, 5) -> (3, 5, 8)
*/

/**
x? = 8
y? = 6
z? = 2
(8, 6, 2) -> (2, 6, 8)
*/

