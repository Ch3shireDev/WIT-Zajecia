#include <cstdio>
#include <cstdlib>

///***********************************************
int MyRead(const char*);
void MySwap(int*, int*);
void MySwapPt(int**, int**);
void MySort(int*, int*, int*);
///***********************************************
///***********************************************
int MyRead(const char* myStr){
    int x;
    printf("%s", myStr);
    scanf("%d",&x);
    return x;
    }
///***********************************************
void MySwap(int* a, int* b){
    int tmp;
    tmp = *a;
    *a = *b;
    *b = tmp;
    }
///***********************************************
void MySwapPt(int** a, int** b){
    int* tmp;
    tmp = *a;
    *a = *b;
    *b = tmp;
    }
///***********************************************
void MySort(int* x, int* y, int* z){
    if(*x>*y)MySwap(x,y);
    if(*y>*z)MySwap(y,z);
    if(*x>*y)MySwap(x,y);
    }
///***********************************************
void MySortPt(int** x, int** y, int** z){
    if(**x>**y)MySwapPt(x,y);
    if(**y>**z)MySwapPt(y,z);
    if(**x>**y)MySwapPt(x,y);
    }
///***********************************************
///***********************************************
int main(){
    int x, y, z;
    int *px, *py, *pz;
    x = MyRead("x? = ");
    y = MyRead("y? = ");
    z = MyRead("z? = ");

    px = &x;
    py = &y;
    pz = &z;

    MySortPt(&px, &py, &pz);

    printf("(%d, %d, %d) -> (%d, %d, %d)\n",x, y, z, *px, *py, *pz);

    return 0;
    }
