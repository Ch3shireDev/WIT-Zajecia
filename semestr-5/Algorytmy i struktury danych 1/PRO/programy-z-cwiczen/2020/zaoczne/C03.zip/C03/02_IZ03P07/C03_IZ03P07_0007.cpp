#include <cstdio>
#include <cstdlib>

///***********************************************
int MyRead(const char*);
int MyMax(int, int);
int MyMax(int, int, int);
int MyMax(int, int, int, int, int, int, int);
///***********************************************
///***********************************************
int MyRead(const char* myStr){
    int x;
    printf("%s", myStr);
    scanf("%d",&x);
    return x;
    }
///***********************************************
int MyMax(int x0, int x1){
    if(x0>x1)return x0;
    return x1;
    }
///***********************************************
int MyMax(int x0, int x1, int x2){
    return MyMax(MyMax(x0, x1), x2);
    }
///***********************************************
int MyMax(int x0, int x1, int x2, int x3, int x4, int x5 , int x6){
    return MyMax(MyMax(x0, x1, x2),MyMax(x3, x4, x5) ,x6);
    }
///***********************************************
///***********************************************
int main(){
    int x0, x1, x2, x3, x4, x5, x6;
    x0 = MyRead("x0? = ");
    x1 = MyRead("x1? = ");
    x2 = MyRead("x2? = ");
    x3 = MyRead("x3? = ");
    x4 = MyRead("x4? = ");
    x5 = MyRead("x5? = ");
    x6 = MyRead("x6? = ");

    printf("Max(%d, %d) = %d\n", x0, x1, MyMax(x0, x1));
    printf("Max(%d, %d, %d) = %d\n", x0, x1, x2, MyMax(x0, x1, x2));
    printf("Max(%d, %d, %d, %d, %d, %d, %d) = %d\n", x0, x1, x2, x3, x4, x5, x6, MyMax(x0, x1, x2, x3, x4, x5, x6));

    return 0;
    }
///15, 12, 12, 10, 10, 10, 8, 8, 8, 8
