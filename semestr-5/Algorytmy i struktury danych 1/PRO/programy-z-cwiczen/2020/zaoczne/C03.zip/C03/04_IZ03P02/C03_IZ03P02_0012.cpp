#include <cstdio>
#include <cstdlib>

typedef void (*FF0)(int);
///***********************************************
int MyRead(const char*);
void Print1(int);
void Print2(int);
void Print3(int);
///***********************************************
///***********************************************
int MyRead(const char* myStr){
    int x;
    printf("%s", myStr);
    scanf("%d", &x);
    return x;
    }
///***********************************************
void Print1(int x){printf("Print1 -> %d\n",x);}
///***********************************************
void Print2(int x){
    for(int i=0; i<x;++i) printf(" ");
    printf("Print2 -> %d\n",x);
    }
///***********************************************
void Print3(int x){
    for(int i=0; i<x;++i) printf("--");
    printf("> Print3 -> %d\n",x);
    }
///***********************************************
///***********************************************
int main(){
    int sT = 8;
    FF0 *t;
    t = (FF0*)malloc(sizeof(FF0)*sT);

    t[0] = Print3;
    t[1] = Print3;
    t[2] = Print1;
    t[3] = Print2;
    t[4] = Print1;
    t[5] = Print2;
    t[6] = Print3;
    t[7] = Print1;

    for(int i =0; i<sT; ++i) t[i](i);

    free(t);
    return 0;
    }
