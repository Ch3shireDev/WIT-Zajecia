#include <cstdio>
#include <cstdlib>

///***********************************************
int MyRead(const char*);
int Add(int, int);
int Add(int, int, int);
///***********************************************
///***********************************************
int MyRead(const char* myStr){
    int x;
    printf("%s", myStr);
    scanf("%d",&x);
    return x;
    }
///***********************************************
int Add(int a, int b){return a + b;}
///***********************************************
int Add(int a, int b, int c){return a + b + c;}
///***********************************************
///***********************************************
int main(){
    printf("Suma = %d\n",Add(MyRead("x? = "), MyRead("y? = ")));
    printf("Suma = %d\n",Add(MyRead("x? = "), MyRead("y? = "), MyRead("z? = ")));

    return 0;
    }
