#include <cstdio>
#include <cstdlib>

///***********************************************
int MyRead(const char*);
///***********************************************
int MyAdd(int, int);
int MyAdd(int, int, int);
///***********************************************
int MyRead(const char* myStr){
    int x;
    printf("%s", myStr);
    scanf("%d", &x);
    return x;
    }
///***********************************************
int MyAdd(int x0, int x1){return x0 + x1;}
int MyAdd(int x0, int x1, int x2){return x0 + x1 + x2;}
///***********************************************
///***********************************************
int main(){
    printf("Suma2 = %d\n", MyAdd(MyRead("x0? = "), MyRead("x1? = ")));
    printf("Suma3 = %d\n", MyAdd(MyRead("x0? = "), MyRead("x1? = "), MyRead("x2? = ")));

    return 0;
    }

