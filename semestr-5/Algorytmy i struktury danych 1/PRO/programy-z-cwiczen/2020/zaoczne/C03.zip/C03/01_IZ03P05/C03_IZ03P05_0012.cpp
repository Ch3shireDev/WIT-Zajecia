#include <cstdio>
#include <cstdlib>

///***********************************************
typedef void (*FF0)(int);
///***********************************************
int MyRead(const char*);
void Print1(int);
void Print2(int);
void Print3(int);
///***********************************************
///***********************************************
int MyRead(const char* myStr){
    int x;
    printf("%s", myStr);
    scanf("%d", &x);
    return x;
    }
///***********************************************
void Print1(int x){printf("Print1 : %d\n", x);}
///***********************************************
void Print2(int x){printf("\t\tPrint2 : %d\n", x);}
///***********************************************
void Print3(int x){printf("\t\t\t\tPrint3 : %d\n", x);}
///***********************************************
///***********************************************
int main(){
    int x = MyRead("x? = ");
    FF0 ptPr1,ptPr2,ptPr3;
    Print1(x);
    Print2(x);
    Print3(x);

    ptPr1 = Print1;
    ptPr2 = Print2;
    ptPr3 = Print3;

    x = MyRead("y? = ");

    ptPr1(x);
    ptPr2(x);
    ptPr3(x);

    printf("Adres Print1: %p, Adres ptPr1: %p\n", (void*)Print1, (void*)ptPr1);
    printf("Adres Print2: %p, Adres ptPr2: %p\n", (void*)Print2, (void*)ptPr2);
    printf("Adres Print3: %p, Adres ptPr3: %p\n", (void*)Print3, (void*)ptPr3);


    return 0;
    }
