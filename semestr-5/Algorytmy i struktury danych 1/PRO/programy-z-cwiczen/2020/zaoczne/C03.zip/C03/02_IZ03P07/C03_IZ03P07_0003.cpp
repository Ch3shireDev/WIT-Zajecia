#include <cstdio>
#include <cstdlib>

///***********************************************
int MyRead(const char*);
void MySwap(int*, int*);
void MySort(int*, int*, int*);
///***********************************************
///***********************************************
int MyRead(const char* myStr){
    int x;
    printf("%s", myStr);
    scanf("%d",&x);
    return x;
    }
///***********************************************
void MySwap(int* a, int* b){
    int tmp;
    tmp = *a;
    *a = *b;
    *b = tmp;
    }
///***********************************************
void MySort(int* x, int* y, int* z){
    if(*x>*y)MySwap(x,y);
    if(*y>*z)MySwap(y,z);
    if(*x>*y)MySwap(x,y);
    }
///***********************************************
///***********************************************
int main(){
    int x0, y0, z0;
    int x1, y1, z1;
    x0 = MyRead("x? = ");
    y0 = MyRead("y? = ");
    z0 = MyRead("z? = ");

    x1 = x0;
    y1 = y0;
    z1 = z0;

    MySort(&x1, &y1, &z1);

    printf("(%d, %d, %d) -> (%d, %d, %d)\n",x0, y0, z0, x1, y1, z1);

    return 0;
    }
