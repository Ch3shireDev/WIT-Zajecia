#include <cstdio>
#include <cstdlib>

///***********************************************
int MyRead(const char*);
int Add(int, int);
int MyMax(int, int);
///***********************************************
///***********************************************
int MyRead(const char* myStr){
    int x;
    printf("%s", myStr);
    scanf("%d",&x);
    return x;
    }
///***********************************************
int Add(int a, int b){return a + b;}
///***********************************************
int MyMax(int x0, int x1){
    if(x0>x1)return x0;
    return x1;
    }
///***********************************************
///***********************************************
int main(){
    int x0, x1;
    x0 = MyRead("x0? = ");
    x1 = MyRead("x1? = ");

    printf("Max(%d, %d) = %d\n", x0, x1, MyMax(x0, x1));

    return 0;
    }
