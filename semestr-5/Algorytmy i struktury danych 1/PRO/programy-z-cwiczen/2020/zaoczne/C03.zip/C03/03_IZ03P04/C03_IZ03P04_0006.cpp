#include <cstdio>
#include <cstdlib>

typedef int ala;
///***********************************************
int MyRead(const char*);
///***********************************************
///***********************************************
int MyRead(const char* myStr){
    int x;
    printf("%s", myStr);
    scanf("%d", &x);
    return x;
    }
///***********************************************
///***********************************************
int main(){
    ala x = 7;
    int y;
    y = x;
    printf("x = %d, y = %d\n", x, y);

    return 0;
    }

