#include <iostream>
using std::cout;
using std::cin;
using std::endl;
using std::string;
///***********************************************
class MyClass{
    public:
        double x1;
        int x0;
    };
///***********************************************
void Ini(MyClass&, double, int);
void Print(const MyClass&);
int MyRead(const char*);
///***********************************************
///***********************************************
int MyRead(const char* myStr){
    int x;
    cout<<myStr;
    cin>>x;
    return x;
    }
///***********************************************
///***********************************************
int main(){
    MyClass myC01;
    myC01.x1 = 3.2;
    myC01.x0 = 5;
    cout<<"myC01: ";
    cout<<"x1 = "<<myC01.x1<<", x0 = "<< myC01.x0<<endl;


    return 0;
    }
