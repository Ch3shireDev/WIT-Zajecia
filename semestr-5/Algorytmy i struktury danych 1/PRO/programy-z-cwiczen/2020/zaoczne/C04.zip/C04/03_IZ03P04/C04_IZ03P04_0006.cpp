#include <iostream>
using std::cout;
using std::cin;
using std::endl;
using std::string;

///***********************************************
int MyRead(const char*);
///***********************************************
///***********************************************
int MyRead(const char* myStr){
    int x;
    cout<<myStr;
    cin>>x;
    return x;
    }

///***********************************************
///***********************************************
int main(){
    int x = MyRead("x? = ");
    cout<<"x = "<<x<<endl;

    return 0;
    }
