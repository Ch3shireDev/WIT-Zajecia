#include <iostream>
using std::cout;
using std::cin;
using std::endl;
using std::string;
///***********************************************
class MyClass{
    public:
        void Ini(double, int);
        void Print()const;
        MyClass Add(double)const;
        MyClass Add(int)const;
        MyClass Add(const MyClass&)const;
        double x1;
        int x0;
    };
///***********************************************
int MyRead(const char*);
///***********************************************
///***********************************************
void MyClass::Ini(double px1, int px0){
    x1 = px1;
    x0 = px0;
    }
///***********************************************
void MyClass::Print()const{
    cout<<"x1 = "<<x1<<", x0 = "<< x0<<endl;
    }
///***********************************************
MyClass MyClass::Add(double x)const{
    MyClass myClass;
    myClass.Ini(x1 + x, x0);
    return myClass;
    }
///***********************************************
MyClass MyClass::Add(int x)const{
    MyClass myClass;
    myClass.Ini(x1, x0 + x);
    return myClass;
    }
///***********************************************
MyClass MyClass::Add(const MyClass& myS)const{
    MyClass myClass;
    myClass.Ini(x1 + myS.x1, x0 + myS.x0);
    return myClass;
    }
///***********************************************
///***********************************************
int MyRead(const char* myStr){
    int x;
    cout<<myStr;
    cin>>x;
    return x;
    }
///***********************************************
///***********************************************
int main(){
    MyClass myC01, myC02, myC03, myC04;

    myC01.Ini(5.2, 17);
    cout<<"myC01: ";
    myC01.Print();

    myC02 = myC01.Add(7.14);
    myC03 = myC01.Add(4);

    myC04 = myC02.Add(myC03);

    cout<<"myC02: ";
    myC02.Print();
    cout<<"myC03: ";
    myC03.Print();

    cout<<"myC04: ";
    myC04.Print();



    return 0;
    }
/**
myC04 = myC02 + myC03
myC04.x1 = myC02.x1 + myC03.x1
myC04.x0 = myC02.x0 + myC03.x0



10, 9, 9, 9, 8, 8, 8, 8, 8
*/
