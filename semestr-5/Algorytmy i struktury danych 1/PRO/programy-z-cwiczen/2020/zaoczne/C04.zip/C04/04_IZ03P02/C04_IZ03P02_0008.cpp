#include <iostream>
using std::cout;
using std::cin;
using std::endl;
using std::string;
class MyClass{
    public:

        double x1;
        int x0;
    };
///***********************************************
void Ini(MyClass&, double, int);
void Print(const MyClass&);
int MyRead(const char*);
///***********************************************
///***********************************************
void Ini(MyClass& myClass, double x1, int x0){
    myClass.x1 = x1;
    myClass.x0 = x0;
    }
///***********************************************
void Print(const MyClass& myClass){
    cout<<"x1 = "<<myClass.x1<<", x0 = "<<myClass.x0<<endl;
    }
///***********************************************
int MyRead(const char* myStr){
    int x;
    cout<<myStr;
    cin>>x;
    return x;
    }
///***********************************************
///***********************************************
int main(){
    MyClass myC01;
    myC01.x1 = 12.5;
    myC01.x0 = 7;
    cout<<"x1 = "<<myC01.x1<<", x0 = "<<myC01.x0<<endl;

    return 0;
    }
