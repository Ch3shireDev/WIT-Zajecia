#include <cstdio>
#include <cstdlib>

struct MyStruct01{
    double x1;
    int x0;
    };
///***********************************************
void* MyStruct(double, int);
int MyRead(const char*);
///***********************************************
///***********************************************
void* MyStruct(double x1, int x0){
    void* myStruct;
    double * pd;
    int* pi;

    myStruct = malloc(sizeof(double) + sizeof(int));

    pd = (double*)myStruct;
    pi = (int*)(pd+1);
    *pd = x1;
    *pi = x0;

    return myStruct;
    }
///***********************************************
int MyRead(const char* myStr){
    int x;
    printf("%s", myStr);
    scanf("%d", &x);
    return x;
    }
///***********************************************
///***********************************************
int main(){
    MyStruct01 myS01;

    myS01.x1 =2.3;
    myS01.x0 = 4;


    printf("double = % f, int = %d\n", myS01.x1, myS01.x0);

    return 0;
    }
