#include <iostream>
using std::cout;
using std::cin;
using std::endl;
using std::string;
class MyClass{
    public:
        void Ini(double, int);
        MyClass Add(const MyClass&)const;
        MyClass operator+(const MyClass&)const;
        MyClass Add(double)const;
        MyClass Add(int)const;
        void Print()const;
        double x1;
        int x0;
    };
///***********************************************
int MyRead(const char*);
///***********************************************
///***********************************************
void MyClass::Ini(double px1, int px0){
    x1 = px1;
    x0 = px0;
    }
///***********************************************
MyClass MyClass::Add(const MyClass& myS)const{
    MyClass myT;
    myT.Ini(x1 + myS.x1, x0 + myS.x0);
    return myT;
    }
///***********************************************
MyClass MyClass::operator+(const MyClass& myS)const{
    MyClass myT;
    myT.Ini(x1 + myS.x1, x0 + myS.x0);
    return myT;
    }
///***********************************************
MyClass MyClass::Add(double x)const{
    MyClass myClass;
    myClass.Ini(x1 + x, x0);
    return myClass;
    }
///***********************************************
MyClass MyClass::Add(int x)const{
    MyClass myClass;
    myClass.Ini(x1, x0 + x);
    return myClass;
    }
///***********************************************
void MyClass::Print()const{
    cout<<"x1 = "<<x1<<", x0 = "<<x0<<endl;
    }
///***********************************************
///***********************************************
int MyRead(const char* myStr){
    int x;
    cout<<myStr;
    cin>>x;
    return x;
    }
///***********************************************
///***********************************************
int main(){
    MyClass myC01, myC02, myC03, myC04;
    myC01.Ini(2.5,7);
    cout<<"myC01: ";
    myC01.Print();

    myC02 = myC01.Add(12.9);
    myC03 = myC01.Add(98);

    cout<<"myC02: ";
    myC02.Print();
    cout<<"myC03: ";
    myC03.Print();


    myC04 = myC03 + myC02;

    cout<<"myC04: ";
    myC04.Print();


    return 0;
    }
/**
myC04 = myC03 + myC02
myC04.x1 = myC03.x1 + myC02.x1
myC04.x0 = myC03.x0 + myC02.x0


9, 9, 9, 8, 8, 8, 8, 8
*/
