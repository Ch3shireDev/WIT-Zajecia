#include <cstdio>
#include <cstdlib>

///***********************************************
void* MyStruct(double, int);
void Print(void *);
int MyRead(const char*);
///***********************************************
///***********************************************
void* MyStruct(double x1, int x0){
    void* myStruct = malloc(sizeof(double) + sizeof(int));
    double* px1;
    int* px0;

    px1 = (double*)myStruct;
    px0 = (int*)(px1+1);

    *px1 = x1;
    *px0 = x0;

    return myStruct;
    }
///***********************************************
void Print(void * myStruct){
    double* px1;
    int* px0;

    px1 = (double*)myStruct;
    px0 = (int*)(px1+1);
    printf("x1 = %f, x0 = %d\n", *px1, *px0);
    }
///***********************************************
int MyRead(const char* myStr){
    int x;
    printf("%s", myStr);
    scanf("%d", &x);
    return x;
    }
///***********************************************
///***********************************************
int main(){
    void* myS0;
    myS0 = MyStruct(2.3, 7);
    printf("myS0: ");
    Print(myS0);

    return 0;
    }
