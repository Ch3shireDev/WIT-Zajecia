#include <iostream>
using std::cout;
using std::cin;
using std::endl;
using std::string;

class MyStruct01{
    public:
        double x1;
        int x0;
    };
///***********************************************
int MyRead(const char*);
///***********************************************
///***********************************************
int MyRead(const char* myStr){
    int x;
    printf("%s", myStr);
    scanf("%d", &x);
    return x;
    }
///***********************************************
///***********************************************
int main(){
    MyStruct01 myS01;

    myS01.x1 =2.3;
    myS01.x0 = 4;

    cout<<"double = "<<myS01.x1<<", int = "<<myS01.x0<<endl;

    return 0;
    }
