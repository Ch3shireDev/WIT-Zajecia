#include <iostream>
using std::cout;
using std::cin;
using std::endl;
using std::string;
class MyClass{
    public:
        void Ini(double, int);
        MyClass Add(double)const;
        MyClass Add(int)const;
        void Print()const;
        double x1;
        int x0;
    };
///***********************************************
int MyRead(const char*);
///***********************************************
///***********************************************
void MyClass::Ini(double px1, int px0){
    x1 = px1;
    x0 = px0;
    }
///***********************************************
MyClass MyClass::Add(double x)const{
    MyClass myClass;
    myClass.Ini(x1 + x, x0);
    return myClass;
    }
///***********************************************
MyClass MyClass::Add(int x)const{
    MyClass myClass;
    myClass.Ini(x1, x0 + x);
    return myClass;
    }
///***********************************************
void MyClass::Print()const{
    cout<<"x1 = "<<x1<<", x0 = "<<x0<<endl;
    }
///***********************************************
///***********************************************
int MyRead(const char* myStr){
    int x;
    cout<<myStr;
    cin>>x;
    return x;
    }
///***********************************************
///***********************************************
int main(){
    MyClass myC01, myC02, myC03;
    myC01.Ini(2.5,7);
    cout<<"myC01: ";
    myC01.Print();

    myC02 = myC01.Add(12.9);
    myC03 = myC01.Add(98);

    cout<<"myC02: ";
    myC02.Print();
    cout<<"myC03: ";
    myC03.Print();

    return 0;
    }
