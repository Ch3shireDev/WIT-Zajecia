#include <iostream>
using namespace std;
///***********************************************
int MyRead(const char*);
///***********************************************
///***********************************************
int MyRead(const char* myStr){
    int x;
    printf("%s", myStr);
    scanf("%d", &x);
    return x;
    }
///***********************************************
///***********************************************
int main(){
    cout<<"Ala ma kota"<<endl;

    return 0;
    }
