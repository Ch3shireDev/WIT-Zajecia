#include <iostream>
using std::cout;
using std::cin;
using std::endl;
using std::string;
///***********************************************
class MyClass{
    public:
        void Ini(double, int);
        void Print()const;

        double x1;
        int x0;
    };
///***********************************************
void Ini(MyClass&, double, int);
void Print(const MyClass&);
int MyRead(const char*);
///***********************************************
///***********************************************
void MyClass::Ini(double px1, int px0){
    x1 = px1;
    x0 = px0;
    }
///***********************************************
void MyClass::Print()const{
    cout<<"x1 = "<<x1<<", x0 = "<< x0<<endl;
    }
///***********************************************
///***********************************************
void Ini(MyClass& myClass, double x1, int x0){
    myClass.x1 = x1;
    myClass.x0 = x0;
    }
///***********************************************
void Print(const MyClass& myC01){
    cout<<"x1 = "<<myC01.x1<<", x0 = "<< myC01.x0<<endl;
    }
///***********************************************
int MyRead(const char* myStr){
    int x;
    cout<<myStr;
    cin>>x;
    return x;
    }
///***********************************************
///***********************************************
int main(){
    MyClass myC01, myC02;
    Ini(myC01, 3.2, 6);
    cout<<"myC01: ";
    Print(myC01);

    myC02.Ini(5.2, 17);
    cout<<"myC02: ";
    myC02.Print();

    return 0;
    }
