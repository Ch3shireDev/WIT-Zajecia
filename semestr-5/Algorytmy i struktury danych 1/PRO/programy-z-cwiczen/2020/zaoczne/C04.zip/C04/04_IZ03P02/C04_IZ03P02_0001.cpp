#include <cstdio>
#include <cstdlib>
///***********************************************
void* MyStructNew(double, int);
void MyStructIni(void*, double, int);
void MyStructPrint(void*);
int MyRead(const char*);
///***********************************************
///***********************************************
void* MyStructNew(double x1, int x0){
    void* myStruct = malloc(sizeof(double) + sizeof(int));
    double* pd;
    int* pi;

    pd = (double*)myStruct;
    pi = (int*)(pd+1);
    *pd = x1;
    *pi = x0;

    return myStruct;
    }
///***********************************************
void MyStructIni(void* myStruct, double x1, int x0){
    double* pd;
    int* pi;

    pd = (double*)myStruct;
    pi = (int*)(pd+1);
    *pd = x1;
    *pi = x0;
    }
///***********************************************
void MyStructPrint(void* myStruct){
    printf("x1 = %f, x0 = %d\n", *(double*)(myStruct),*(int*)((double*)(myStruct)+1));
    }
///***********************************************
int MyRead(const char* myStr){
    int x;
    printf("%s", myStr);
    scanf("%d", &x);
    return x;
    }
///***********************************************
///***********************************************
int main(){
    void* myS01;
    myS01 = MyStructNew(12.4, 9);
    MyStructPrint(myS01);
    MyStructIni(myS01,248.125,1024);
    MyStructPrint(myS01);

    return 0;
    }
