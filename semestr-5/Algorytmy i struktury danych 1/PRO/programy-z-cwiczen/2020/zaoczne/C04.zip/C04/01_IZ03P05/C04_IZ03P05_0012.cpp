#include <iostream>
using std::cout;
using std::cin;
using std::endl;
using std::string;

class MyStruct01{
    public:

        void Ini(double, int);
        void Print();
        MyStruct01 Add(double)const;
        MyStruct01 Add(int)const;
        MyStruct01 Add(const MyStruct01&)const;
        double x1;
        int x0;
    };
///***********************************************
int MyRead(const char*);
///***********************************************
///***********************************************
void MyStruct01::Ini(double px1, int px0){
    x1 = px1;
    x0 = px0;
    }
///***********************************************
void MyStruct01::Print(){
    cout<<"x1 = "<<x1<<", x0 = "<<x0<<endl;
    }
///***********************************************
MyStruct01 MyStruct01::Add(double x)const{
    MyStruct01 myStruct01;
    myStruct01.Ini(x1 + x, x0);
    return myStruct01;
    }
///***********************************************
MyStruct01 MyStruct01::Add(int x)const{
    MyStruct01 myStruct01;
    myStruct01.Ini(x1, x0 + x);
    return myStruct01;
    }
///***********************************************
MyStruct01 MyStruct01::Add(const MyStruct01& myS)const{
    MyStruct01 mySt;
    mySt.Ini(x1 + myS.x1, x0 + myS.x0);
    return mySt;
    }
///***********************************************
///***********************************************
int MyRead(const char* myStr){
    int x;
    printf("%s", myStr);
    scanf("%d", &x);
    return x;
    }
///***********************************************
///***********************************************
int main(){
    MyStruct01 myS01, myS02, myS03, myS04;


    myS03.Ini(6.1,12);
    myS01 = myS03.Add(9.4);
    myS02 = myS03.Add(8);
    cout<<"myS03:\t";
    myS03.Print();
    cout<<"myS01:\t";
    myS01.Print();
    cout<<"myS02:\t";
    myS02.Print();

    ///1 wywo�anie metody Add z klasy

    myS04 = myS01.Add(myS02);

    cout<<"myS04:\t";
    myS04.Print();

    return 0;
    }
/**
myS04 = myS01 + myS02
myS04.x1 = myS01.x1 + myS02.x1
myS04.x0 = myS01.x0 + myS02.x0

10,9, 9, 9, 8, 8, 8, 8
*/
