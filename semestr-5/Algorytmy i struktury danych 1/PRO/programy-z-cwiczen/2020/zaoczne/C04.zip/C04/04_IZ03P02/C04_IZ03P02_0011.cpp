#include <iostream>
using std::cout;
using std::cin;
using std::endl;
using std::string;
class MyClass{
    public:
        void Ini(double, int);
        void Print();
        double x1;
        int x0;
    };
///***********************************************
void Ini(MyClass&, double, int);
void Print(const MyClass&);
int MyRead(const char*);
///***********************************************
///***********************************************
void MyClass::Ini(double px1, int px0){
    x1 = px1;
    x0 = px0;
    }
///***********************************************
void MyClass::Print(){
    cout<<"x1 = "<<x1<<", x0 = "<<x0<<endl;
    }
///***********************************************
///***********************************************
void Ini(MyClass& myClass, double x1, int x0){
    myClass.x1 = x1;
    myClass.x0 = x0;
    }
///***********************************************
void Print(const MyClass& myClass){
    cout<<"x1 = "<<myClass.x1<<", x0 = "<<myClass.x0<<endl;
    }
///***********************************************
int MyRead(const char* myStr){
    int x;
    cout<<myStr;
    cin>>x;
    return x;
    }
///***********************************************
///***********************************************
int main(){
    MyClass myC01;
    myC01.Ini(2.5,7);
    myC01.Print();

    return 0;
    }
