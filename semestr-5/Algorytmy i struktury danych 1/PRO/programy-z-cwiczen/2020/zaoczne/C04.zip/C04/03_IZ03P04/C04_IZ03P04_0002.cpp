#include <cstdio>
#include <cstdlib>

struct MyStruct01{
    double x1;
    int x0;
    };
///***********************************************
int MyRead(const char*);
void* MyStruct(double , int);
void MyStructIni(void*, double , int);
void MyStructPrint(void*);
///***********************************************
///***********************************************
int MyRead(const char* myStr){
    int x;
    printf("%s", myStr);
    scanf("%d", &x);
    return x;
    }
///***********************************************
void* MyStruct(double x1, int x0){
    void* myStruct = malloc(sizeof(double)+ sizeof(int));
    double * pd;
    int* pi;
    pd = (double*)myStruct;
    pi = (int*)(pd+1);

    *pd = x1;
    *pi = x0;

    return myStruct;
    }
///***********************************************
void MyStructIni(void* myStruct, double x1, int x0){
    double * pd;
    int* pi;
    pd = (double*)myStruct;
    pi = (int*)(pd+1);

    *pd = x1;
    *pi = x0;
    }
///***********************************************
void MyStructPrint(void* myStruct){
    double * pd;
    int* pi;
    pd = (double*)myStruct;
    pi = (int*)(pd+1);
    printf("x1 = %f, x0 = %d\n", *pd, *pi);
    }
///***********************************************
///***********************************************
int main(){
    void* myS01;
    MyStruct01 myS02;

    myS02.x1 = 46.4;
    myS02.x0 = 128;

    printf("x1 = %f, x0 = %d\n", myS02.x1, myS02.x0);

    MyStructPrint((void*)(&myS02));

    myS01 = MyStruct(2.7,6);
    MyStructPrint(myS01);
    MyStructIni(myS01, 11.5, 9);
    MyStructPrint(myS01);

    return 0;
    }
