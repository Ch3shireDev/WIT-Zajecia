#include <iostream>
using std::cout;
using std::cin;
using std::endl;
using std::string;

class MyStruct01{
    public:

        void Ini(double, int);
        void Print();

        double x1;
        int x0;
    };
///***********************************************
int MyRead(const char*);
void Ini(MyStruct01&, double, int);
void Print(const MyStruct01&);
///***********************************************
///***********************************************
void MyStruct01::Ini(double px1, int px0){
    x1 = px1;
    x0 = px0;
    }
///***********************************************
void MyStruct01::Print(){
    cout<<"x1 = "<<x1<<", x0 = "<<x0<<endl;
    }

///***********************************************
///***********************************************
int MyRead(const char* myStr){
    int x;
    printf("%s", myStr);
    scanf("%d", &x);
    return x;
    }
///***********************************************
void Ini(MyStruct01& myS, double x1, int x0){
    myS.x1 = x1;
    myS.x0 = x0;
    }
///***********************************************
void Print(const MyStruct01& myS){
    cout<<"x1 = "<<myS.x1<<", x0 = "<<myS.x0<<endl;
    }
///***********************************************
///***********************************************
int main(){
    MyStruct01 myS01, myS02, myS03;

    myS01.x1 =2.3;
    myS01.x0 = 4;
    Ini(myS02, 7.4, 8);

    myS03.Ini(6.1,12);

    cout<<"myS01:\t";
    cout<<"double = "<<myS01.x1<<", int = "<<myS01.x0<<endl;
    cout<<"myS02:\t";
    Print(myS02);
    cout<<"myS03:\t";
    myS03.Print();



    return 0;
    }
