#include <cstdio>
#include <cstdlib>

struct MyStruct01{
    double x1;
    int x0;
    };
///***********************************************
int MyRead(const char*);
void MyStructIni(void*, double , int);
void MyStructPrint(void*);
///***********************************************
///***********************************************
int MyRead(const char* myStr){
    int x;
    printf("%s", myStr);
    scanf("%d", &x);
    return x;
    }
///***********************************************
void MyStructIni(void* myStruct, double x1, int x0){
    double * pd;
    int* pi;
    pd = (double*)myStruct;
    pi = (int*)(pd+1);

    *pd = x1;
    *pi = x0;
    }
///***********************************************
void MyStructPrint(void* myStruct){
    double * pd;
    int* pi;
    pd = (double*)myStruct;
    pi = (int*)(pd+1);
    printf("x1 = %f, x0 = %d\n", *pd, *pi);
    }
///***********************************************
///***********************************************
int main(){
    MyStruct01 myS02;

    MyStructIni((void*)(&myS02), 99.1, 256);
    MyStructPrint((void*)(&myS02));
    myS02.x1 =12.9;


    return 0;
    }
