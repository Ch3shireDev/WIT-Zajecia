#include <cstdio>
#include <cstdlib>
///***********************************************
struct MyStruct01{
    double x1;
    int x0;
    };
///***********************************************
void* MyStruct(double, int);
void Print(void *);
int MyRead(const char*);
///***********************************************
///***********************************************
void* MyStruct(double x1, int x0){
    void* myStruct = malloc(sizeof(double) + sizeof(int));
    double* px1;
    int* px0;

    px1 = (double*)myStruct;
    px0 = (int*)(px1+1);

    *px1 = x1;
    *px0 = x0;

    return myStruct;
    }
///***********************************************
void Print(void * myStruct){
    double* px1;
    int* px0;

    px1 = (double*)myStruct;
    px0 = (int*)(px1+1);
    printf("x1 = %f, x0 = %d\n", *px1, *px0);
    }
///***********************************************
int MyRead(const char* myStr){
    int x;
    printf("%s", myStr);
    scanf("%d", &x);
    return x;
    }
///***********************************************
///***********************************************
int main(){
    void* myS0;
    MyStruct01 myS01;
    myS01.x1 = 4.8;
    myS01.x0 = 12;
    myS0 = MyStruct(2.3, 7);
    printf("myS0: ");
    Print(myS0);
    printf("myS01: x1 = %f, x0 = %d\n", myS01.x1, myS01.x0);
    Print((void*)(&myS01));


    return 0;
    }
