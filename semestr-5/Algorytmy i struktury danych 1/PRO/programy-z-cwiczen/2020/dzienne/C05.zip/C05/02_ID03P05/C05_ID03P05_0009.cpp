#include <iostream>
using std::cout;
using std::cin;
using std::endl;
using std::string;
///*****************************************************************************
class MyClass{
    public:
        int x2;
        int x1;
        int x0;

        };
///*****************************************************************************
///*****************************************************************************
int MyRead(string ="x? = ");
void MyClassIni(MyClass*, int, int, int);
void MyClassIni(MyClass&, int, int, int);
///*****************************************************************************
int MyRead(string myStr){
    int x;
    cout<<myStr;
    cin>>x;
    return x;
    }
///*****************************************************************************
void MyClassIni(MyClass* myClass, int x2, int x1, int x0){
    (*myClass).x2 = x2;
    (*myClass).x1 = x1;
    (*myClass).x0 = x0;
    }
///*****************************************************************************
void MyClassIni(MyClass& myClass, int x2, int x1, int x0){
    myClass.x2 = x2;
    myClass.x1 = x1;
    myClass.x0 = x0;
    }
///*****************************************************************************
///*****************************************************************************
int main(){
    MyClass myClass01;
    MyClass myClass02;

    MyClassIni(&myClass01,MyRead("x2? = "),MyRead("x1? = "),MyRead("x0? = "));
    MyClassIni( myClass02,MyRead("x2? = "),MyRead("x1? = "),MyRead("x0? = "));

    cout<<"MyClass("<< myClass01.x2
               <<", "<<myClass01.x1
               <<", "<<myClass01.x0
               <<")"<<endl;


    cout<<"MyClass("<< myClass02.x2
               <<", "<<myClass02.x1
               <<", "<<myClass02.x0
               <<")"<<endl;

    return 0;
    }
