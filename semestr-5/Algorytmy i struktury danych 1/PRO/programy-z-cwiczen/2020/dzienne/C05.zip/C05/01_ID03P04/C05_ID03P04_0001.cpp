#include <iostream>
///using namespace std;
using std::cout;
using std::cin;
using std::endl;
int main(){
    ///std::cout<<"Ala ma kota\n";
    cout<<"Ala ma kota\n";
    return 0;
    }
