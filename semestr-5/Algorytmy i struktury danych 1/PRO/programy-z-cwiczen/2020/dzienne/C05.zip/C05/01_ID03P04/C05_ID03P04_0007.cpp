#include <iostream>
///****************************************************
using std::cout;
using std::cin;
using std::endl;
using std::string;
///****************************************************
class MyClass01{
    public:
        int x2;
        int x1;
        int x0;

        void MyClass01Ini(int, int, int);
        };
///****************************************************
int MyRead(string = "x? = ");
///****************************************************
///****************************************************
void MyClass01::MyClass01Ini(int tx2, int tx1, int tx0){
    x2 = tx2;
    x1 = tx1;
    x0 = tx0;
    }
///****************************************************
///****************************************************
int MyRead(string myStr){
    int x;
    cout<<myStr;
    cin>>x;
    return x;
    }
///****************************************************
///****************************************************
int main(){
    MyClass01 myClass01;

    cout<<"myClass01::"<<endl;
    myClass01.MyClass01Ini(
                 MyRead("x2? = "),
                 MyRead("x1? = "),
                 MyRead("x0? = "));


    cout<<"myClass01("<<myClass01.x2<<", "
        <<myClass01.x1<<", "<<myClass01.x0<<")"<<endl;

    return 0;
    }
///10, 8, 8, 6, 6, 6, 4, 4, 4, 4
