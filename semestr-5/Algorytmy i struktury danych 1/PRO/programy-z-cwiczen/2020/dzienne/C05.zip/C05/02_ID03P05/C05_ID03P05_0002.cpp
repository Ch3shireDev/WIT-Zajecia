#include <iostream>

int main(){
    std::cout<<"Ala ma kota"<<std::endl;
    return 0;
    }
