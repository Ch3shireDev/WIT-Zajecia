#include <iostream>
using std::cout;
using std::endl;
using std::string;
using std::cin;
///************************************************************************
class MyClass{
    public:
        int x2;
        int x1;
        int x0;

        };
///************************************************************************
///************************************************************************
int MyRead(string = "x? = ");
void MyClassIni(MyClass*, int, int, int);
///************************************************************************
///************************************************************************
int MyRead(string myStr){
    int x;
    cout<<myStr;
    cin>>x;
    return x;
    }
///************************************************************************
void MyClassIni(MyClass* myC, int x2, int x1, int x0){
    (*myC).x2 = x2;
    (*myC).x1 = x1;
    (*myC).x0 = x0;
    }
///************************************************************************
///************************************************************************
int main(){
    MyClass myClass01;

    myClass01.x2 = MyRead("x2? = ");
    myClass01.x1 = MyRead("x1? = ");
    myClass01.x0 = MyRead("x0? = ");

    cout<<"MyClass("<<myClass01.x2
              <<", "<<myClass01.x1
              <<", "<<myClass01.x0
              <<")" <<endl;


    return 0;
    }
