#include <iostream>
using namespace std;
int main(){
    cout<<"Ala ma kota ..."<<endl;

    return 0;
    }
