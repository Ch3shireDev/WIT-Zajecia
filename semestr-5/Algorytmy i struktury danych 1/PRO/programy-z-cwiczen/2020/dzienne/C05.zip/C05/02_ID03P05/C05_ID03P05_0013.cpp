#include <iostream>
using std::cout;
using std::cin;
using std::endl;
using std::string;
///*****************************************************************************
class MyClass{
    public:
        int x2;
        int x1;
        int x0;

        void Ini(int, int, int);
        MyClass Add(MyClass);
        void Print();
        };
///*****************************************************************************
///*****************************************************************************
int MyRead(string ="x? = ");
///*****************************************************************************
void MyClass::Ini(int tx2, int tx1, int tx0){
    x2 = tx2;
    x1 = tx1;
    x0 = tx0;
    }
///*****************************************************************************
MyClass MyClass::Add(MyClass myC02){
    MyClass myC03;
    myC03.x2 = x2 + myC02.x2;
    myC03.x1 = x1 + myC02.x1;
    myC03.x0 = x0 + myC02.x0;
    return myC03;
    }
///*****************************************************************************
void MyClass::Print(){
    cout<<"MyClass("<< x2<<", "<<x1<<", "<<x0<<")"<<endl;
    }
///*****************************************************************************
///*****************************************************************************
int MyRead(string myStr){
    int x;
    cout<<myStr;
    cin>>x;
    return x;
    }
///*****************************************************************************
///*****************************************************************************
int main(){
    MyClass myClass01, myClass02, myClass03;
    myClass01.Ini(MyRead("x2? = "),MyRead("x1? = "),MyRead("x0? = "));
    myClass02.Ini(MyRead("x2? = "),MyRead("x1? = "),MyRead("x0? = "));

    myClass03 = myClass02.Add(myClass01);

    myClass03.Print();

    return 0;
    }
/**
myClass01.x2 = 3
myClass01.x1 = 2
myClass01.x0 = 1
+
myClass02.x2 = 30
myClass02.x1 = 20
myClass02.x0 = 10
=
myClass03.x2 = 33
myClass03.x1 = 22
myClass03.x0 = 11

16, 16, 16, 14, 14, 14, 14, 12, 12, 12, 12, 12, 10 ...


*/

