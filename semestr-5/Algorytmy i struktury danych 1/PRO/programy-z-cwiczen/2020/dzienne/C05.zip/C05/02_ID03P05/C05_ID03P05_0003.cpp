#include <iostream>
using std::cout;
using std::endl;

int main(){
    cout<<"Ala ma kota"<<endl;
    return 0;
    }
