#include <iostream>
using std::cout;
using std::endl;
using std::string;
using std::cin;
///************************************************************************
class MyClass{
    public:
        int x2;
        int x1;
        int x0;

        void Ini(int, int, int);
        MyClass Add(const MyClass&);
        void Print();
        };
///************************************************************************
///************************************************************************
int MyRead(string = "x? = ");
///************************************************************************
///************************************************************************
void MyClass::Ini(int tx2, int tx1, int tx0){
    x2 = tx2;
    x1 = tx1;
    x0 = tx0;
    }
///************************************************************************
MyClass MyClass::Add(const MyClass& myC01){
    MyClass myC03;
    myC03.Ini(x2 + myC01.x2, x1 + myC01.x1,x0 + myC01.x0);
    return myC03;
    }
///************************************************************************
void MyClass::Print(){
    cout<<"MyClass("<<x2<<", "<<x1<<", "<<x0<<")" <<endl;
    }
///************************************************************************
///************************************************************************
int MyRead(string myStr){
    int x;
    cout<<myStr;
    cin>>x;
    return x;
    }
///************************************************************************
///************************************************************************
int main(){
    MyClass myClass01, myClass02, myClass03;

    myClass01.Ini(MyRead("x2? = "),MyRead("x1? = "),MyRead("x0? = "));
    myClass02.Ini(MyRead("x2? = "),MyRead("x1? = "),MyRead("x0? = "));
    myClass03 = myClass02.Add(myClass01);
    myClass03.Print();
    return 0;
    }
/**
x0? = 1
x1? = 2
x2? = 3

x0? = 10
x1? = 20
x2? = 30

MyClass(33, 22, 11)
*/
