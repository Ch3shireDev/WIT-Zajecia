#include <iostream>
using std::cout;
using std::cin;
using std::endl;

int main(){
    int x;
    cout<<"x? = ";
    cin>>x;
    cout<<"x = "<<x<<endl;
    return 0;
    }
