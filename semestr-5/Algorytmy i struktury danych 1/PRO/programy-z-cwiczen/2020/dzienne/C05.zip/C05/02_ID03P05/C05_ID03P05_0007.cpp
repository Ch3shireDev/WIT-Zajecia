#include <iostream>
using std::cout;
using std::cin;
using std::endl;
using std::string;
///*****************************************************************************
class MyClass{
    public:
        int x2;
        int x1;
        int x0;

        };
///*****************************************************************************
///*****************************************************************************
int MyRead(string ="x? = ");
///*****************************************************************************
int MyRead(string myStr){
    int x;
    cout<<myStr;
    cin>>x;
    return x;
    }
///*****************************************************************************
///*****************************************************************************
int main(){
    MyClass myClass01;

    myClass01.x2 = MyRead("x2? = ");
    myClass01.x1 = MyRead("x1? = ");
    myClass01.x0 = MyRead("x0? = ");

    cout<<"MyClass("<< myClass01.x2
               <<", "<<myClass01.x1
               <<", "<<myClass01.x0
               <<")"<<endl;


    return 0;
    }
