#include <iostream>
///****************************************************
using std::cout;
using std::cin;
using std::endl;
using std::string;
///****************************************************
class MyClass01{
    public:
        int x2;
        int x1;
        int x0;
        };
///****************************************************
int MyRead(string = "x? = ");
void MyClass01Ini(MyClass01&, int, int, int);
void MyClass01Ini(MyClass01*, int, int, int);
///****************************************************
///****************************************************
int MyRead(string myStr){
    int x;
    cout<<myStr;
    cin>>x;
    return x;
    }
///****************************************************
void MyClass01Ini(MyClass01& myClass01, int x2, int x1, int x0){
    myClass01.x2 = x2;
    myClass01.x1 = x1;
    myClass01.x0 = x0;
    }
///****************************************************
void MyClass01Ini(MyClass01* myClass01, int x2, int x1, int x0){
    (*myClass01).x2 = x2;
    (*myClass01).x1 = x1;
    (*myClass01).x0 = x0;
    }
///****************************************************
///****************************************************
int main(){
    MyClass01 myClass01;
    MyClass01 myClass02;
    cout<<"myClass01::"<<endl;
    MyClass01Ini(myClass01,
                 MyRead("x2? = "),
                 MyRead("x1? = "),
                 MyRead("x0? = "));
    cout<<"myClass02::"<<endl;
    MyClass01Ini(&myClass02,
                 MyRead("x2? = "),
                 MyRead("x1? = "),
                 MyRead("x0? = "));
    cout<<"myClass01("<<myClass01.x2<<", "
        <<myClass01.x1<<", "<<myClass01.x0<<")"<<endl;

    cout<<"myClass02("<<myClass02.x2<<", "
        <<myClass02.x1<<", "<<myClass02.x0<<")"<<endl;

    return 0;
    }
