#ifndef MyC_H
#define MCA_H
#include "MyUtility.h"
#include "MyA.h"
class MyC:public MyA{
    public:
        MyC(int, int, int, int);
        string ToString(string myStr="");
        int X3();
        int X2();
        virtual MyA* Clone();

    protected:
        int x3;
        int x2;
    };
#include "MyC.cpp"
#endif // MyC_H
