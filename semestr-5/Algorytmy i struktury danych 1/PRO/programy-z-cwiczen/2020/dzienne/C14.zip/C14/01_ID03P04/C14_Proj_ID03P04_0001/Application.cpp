///***************************************************
void Application::Run(){
    srand(time(0));
    Main12();
    }
///***************************************************
void Application::Main01(){
    cout<<"\n\n\tHappy new day  ...27... !!!\n\n";
    }
///***************************************************
void Application::Main02(){
    MyNode* n00, *n01, *n02, *n03, *n04;

    n00 = new MyNode;
    n00->x = 0;
    n00->next = NULL;

    n01 = new MyNode;
    n01->x = 1;
    n01->next = NULL;

    n02 = new MyNode;
    n02->x = 2;
    n02->next = NULL;

    n03 = new MyNode;
    n03->x = 3;
    n03->next = NULL;

    n04 = new MyNode;
    n04->x = 4;
    n04->next = NULL;

    cout<<"n00->x = "<<n00->x<<endl;
    cout<<"n01->x = "<<n01->x<<endl;
    cout<<"n02->x = "<<n02->x<<endl;
    cout<<"n03->x = "<<n03->x<<endl;
    cout<<"n04->x = "<<n04->x<<endl;
    }
///***************************************************
void Application::Main03(){
    MyNode* n00, *n01, *n02, *n03, *n04;

    n00 = new MyNode;
    n00->x = 0;
    n00->next = NULL;

    n01 = new MyNode;
    n01->x = 1;
    n01->next = NULL;

    n02 = new MyNode;
    n02->x = 2;
    n02->next = NULL;

    n03 = new MyNode;
    n03->x = 3;
    n03->next = NULL;

    n04 = new MyNode;
    n04->x = 4;
    n04->next = NULL;

    n00->next = n01;
    n01->next = n02;
    n02->next = n03;
    n03->next = n04;

    cout<<"n00->x = "<<n00->x<<endl;
    cout<<"n01->x = "<<n01->x<<endl;
    cout<<"n02->x = "<<n02->x<<endl;
    cout<<"n03->x = "<<n03->x<<endl;
    cout<<"n04->x = "<<n04->x<<endl;
    }
///***************************************************
void Application::Main04(){
    MyNode* n00, *n01, *n02, *n03, *n04;

    n00 = new MyNode;
    n00->x = 0;
    n00->next = NULL;

    n01 = new MyNode;
    n01->x = 1;
    n01->next = NULL;

    n02 = new MyNode;
    n02->x = 2;
    n02->next = NULL;

    n03 = new MyNode;
    n03->x = 3;
    n03->next = NULL;

    n04 = new MyNode;
    n04->x = 4;
    n04->next = NULL;

    n00->next = n01;
    n01->next = n02;
    n02->next = n03;
    n03->next = n04;

    cout<<"n00->x = "<<n00->x<<endl;
    cout<<"n01->x = "<<n00->next->x<<endl;
    cout<<"n02->x = "<<n01->next->x<<endl;
    cout<<"n03->x = "<<n02->next->x<<endl;
    cout<<"n04->x = "<<n03->next->x<<endl;
    }
///***************************************************
void Application::Main05(){
    MyNode* n00, *n01, *n02, *n03, *n04;

    n00 = new MyNode;
    n00->x = 0;
    n00->next = NULL;

    n01 = new MyNode;
    n01->x = 1;
    n01->next = NULL;

    n02 = new MyNode;
    n02->x = 2;
    n02->next = NULL;

    n03 = new MyNode;
    n03->x = 3;
    n03->next = NULL;

    n04 = new MyNode;
    n04->x = 4;
    n04->next = NULL;

    n00->next = n01;
    n01->next = n02;
    n02->next = n03;
    n03->next = n04;

    cout<<"n00->x = "<<n00->x<<endl;
    cout<<"n01->x = "<<n00->next->x<<endl;
    cout<<"n02->x = "<<n00->next->next->x<<endl;
    cout<<"n03->x = "<<n00->next->next->next->x<<endl;
    cout<<"n04->x = "<<n00->next->next->next->next->x<<endl;
    }
///***************************************************
void Application::Main06(){
    MyNode* n00, *n01, *n02, *n03, *n04;

    n00 = new MyNode;
    n01 = new MyNode;
    n02 = new MyNode;
    n03 = new MyNode;
    n04 = new MyNode;

    n00->x = 0;
    n00->next = NULL;

    n01->x = 1;
    n01->next = NULL;

    n02->x = 2;
    n02->next = NULL;

    n03->x = 3;
    n03->next = NULL;

    n04->x = 4;
    n04->next = NULL;

    n00->next = n01;
    n01->next = n02;
    n02->next = n03;
    n03->next = n04;

    cout<<"n00->x = "<<n00->x<<endl;
    cout<<"n01->x = "<<n00->next->x<<endl;
    cout<<"n02->x = "<<n00->next->next->x<<endl;
    cout<<"n03->x = "<<n00->next->next->next->x<<endl;
    cout<<"n04->x = "<<n00->next->next->next->next->x<<endl;
    }
///***************************************************
void Application::Main07(){
    MyNode* n00, *n01, *n02, *n03, *n04;

    n00 = new MyNode;
    n01 = new MyNode;
    n02 = new MyNode;
    n03 = new MyNode;
    n04 = new MyNode;

    n00->next = n01;
    n01->next = n02;
    n02->next = n03;
    n03->next = n04;
    n04->next = NULL;


    n00->x = 0;
    n01->x = 1;
    n02->x = 2;
    n03->x = 3;
    n04->x = 4;

    cout<<"n00->x = "<<n00->x<<endl;
    cout<<"n01->x = "<<n00->next->x<<endl;
    cout<<"n02->x = "<<n00->next->next->x<<endl;
    cout<<"n03->x = "<<n00->next->next->next->x<<endl;
    cout<<"n04->x = "<<n00->next->next->next->next->x<<endl;
    }
///***************************************************
void Application::Main08(){
    MyNode* n00, *n01, *n02, *n03, *n04;

    n00 = new MyNode;
    n01 = new MyNode;
    n02 = new MyNode;
    n03 = new MyNode;
    n04 = new MyNode;

    n00->next = n01;
    n00->next->next = n02;
    n00->next->next->next = n03;
    n00->next->next->next->next = n04;
    n00->next->next->next->next->next = NULL;


    n00->x = 0;
    n00->next->x = 1;
    n00->next->next->x = 2;
    n00->next->next->next->x = 3;
    n00->next->next->next->next->x = 4;

    cout<<"n00->x = "<<n00->x<<endl;
    cout<<"n01->x = "<<n00->next->x<<endl;
    cout<<"n02->x = "<<n00->next->next->x<<endl;
    cout<<"n03->x = "<<n00->next->next->next->x<<endl;
    cout<<"n04->x = "<<n00->next->next->next->next->x<<endl;
    }
///***************************************************
void Application::Main09(){
    MyNode* n00;

    n00 = new MyNode;
    n00->next = new MyNode;
    n00->next->next = new MyNode;
    n00->next->next->next = new MyNode;
    n00->next->next->next->next = new MyNode;
    n00->next->next->next->next->next = NULL;


    n00->x = 0;
    n00->next->x = 1;
    n00->next->next->x = 2;
    n00->next->next->next->x = 3;
    n00->next->next->next->next->x = 4;

    cout<<"n00->x = "<<n00->x<<endl;
    cout<<"n01->x = "<<n00->next->x<<endl;
    cout<<"n02->x = "<<n00->next->next->x<<endl;
    cout<<"n03->x = "<<n00->next->next->next->x<<endl;
    cout<<"n04->x = "<<n00->next->next->next->next->x<<endl;
    }
///***************************************************
void Application::Main10(){
    MyNode* n00, *walk;

    n00 = new MyNode;
    walk = n00;
    walk->next = new MyNode;
    walk = walk->next;
    walk->next= new MyNode;
    walk = walk->next;
    walk->next = new MyNode;
    walk = walk->next;
    walk->next = new MyNode;
    walk = walk->next;
    walk->next = NULL;


    n00->x = 0;
    n00->next->x = 1;
    n00->next->next->x = 2;
    n00->next->next->next->x = 3;
    n00->next->next->next->next->x = 4;

    cout<<"n00->x = "<<n00->x<<endl;
    cout<<"n01->x = "<<n00->next->x<<endl;
    cout<<"n02->x = "<<n00->next->next->x<<endl;
    cout<<"n03->x = "<<n00->next->next->next->x<<endl;
    cout<<"n04->x = "<<n00->next->next->next->next->x<<endl;
    }
///***************************************************
void Application::Main11(){
    MyNode* n00, *walk;

    n00 = new MyNode;
    walk = n00;
    for(int i = 1;i<5;++i){
        walk->next = new MyNode;
        walk = walk->next;
        }
    walk->next = NULL;


    n00->x = 0;
    n00->next->x = 1;
    n00->next->next->x = 2;
    n00->next->next->next->x = 3;
    n00->next->next->next->next->x = 4;

    cout<<"n00->x = "<<n00->x<<endl;
    cout<<"n01->x = "<<n00->next->x<<endl;
    cout<<"n02->x = "<<n00->next->next->x<<endl;
    cout<<"n03->x = "<<n00->next->next->next->x<<endl;
    cout<<"n04->x = "<<n00->next->next->next->next->x<<endl;
    }
///***************************************************
void Application::Main12(){
    MyNode* n00, *walk;

    n00 = new MyNode;
    walk = n00;
    for(int i = 1;i<5;++i){
        walk->next = new MyNode;
        walk = walk->next;
        }
    walk->next = NULL;

    walk = n00;
    walk->x =0;

    while (walk->next!=NULL){
        walk->next->x = walk->x +1;
        walk = walk->next;
        }

    walk = n00;

    while (walk!=NULL){
        cout<<"x = "<<walk->x<<endl;
        walk = walk->next;
        }


    }
///***************************************************
///50, 40, 40, 30, 30, 30, 25, 25, 25, 25
