#ifndef MyNode_H
#define MyNode_H
#include "MyUtility.h"
class MyNode{

    public:
        int x;
        MyNode * next;
    };
#include "MyNode.cpp"
#endif //MyNode_H
