///*********************************************************
MyNode::MyNode(int x):x(x),next(NULL){}
///*********************************************************
///*********************************************************
MyNode* MyListNew(int sL, int bG, int sT){
    MyNode* n0, *walk;

    if(sL<1) return NULL;

    n0 = new MyNode(bG);
    walk = n0;

    for(int i = 1; i<sL;++i){
        walk->next = new MyNode(walk->x+sT);
        walk = walk->next;
        }
    return n0;
    }
///*********************************************************
MyNode* MyListPrint(MyNode* n0){
    if(n0 == NULL) return NULL;
    while(n0->next != NULL){
        cout<<"x = "<<n0->x<<endl;
        n0=n0->next;
        }
    cout<<"x = "<<n0->x<<endl;
    return n0;
    }
///*********************************************************
