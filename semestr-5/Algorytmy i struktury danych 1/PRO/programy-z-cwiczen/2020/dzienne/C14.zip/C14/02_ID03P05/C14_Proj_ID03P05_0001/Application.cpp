///***************************************************
void Application::Run(){
    srand(time(0));
    Main19();
    }
///***************************************************
void Application::Main01(){
    cout<<"\n\n\tHappy new day  >>>27<<< !!!\n\n";
    }
///***************************************************
void Application::Main02(){
    MyNode* n0, *n1, *n2, *n3, *n4;

    n0 = new MyNode;
    n1 = new MyNode;
    n2 = new MyNode;
    n3 = new MyNode;
    n4 = new MyNode;

    n0->x = 0;
    n1->x = 1;
    n2->x = 2;
    n3->x = 3;
    n4->x = 4;

    n0->next = n1;
    n1->next = n2;
    n2->next = n3;
    n3->next = n4;
    n4->next = NULL;

    cout<<"x = "<<n0->x<<endl;
    cout<<"x = "<<n1->x<<endl;
    cout<<"x = "<<n2->x<<endl;
    cout<<"x = "<<n3->x<<endl;
    cout<<"x = "<<n4->x<<endl;

    }
///***************************************************
void Application::Main03(){
    MyNode* n0, *n1, *n2, *n3, *n4;

    n0 = new MyNode;
    n1 = new MyNode;
    n2 = new MyNode;
    n3 = new MyNode;
    n4 = new MyNode;

    n0->x = 0;
    n1->x = 1;
    n2->x = 2;
    n3->x = 3;
    n4->x = 4;

    n0->next = n1;
    n1->next = n2;
    n2->next = n3;
    n3->next = n4;
    n4->next = NULL;

    cout<<"x = "<<n0->x<<endl;
    cout<<"x = "<<n1->x<<endl;
    cout<<"x = "<<n2->x<<endl;
    cout<<"x = "<<n3->x<<endl;
    cout<<"x = "<<n3->next->x<<endl;

    }
///***************************************************
void Application::Main04(){
    MyNode* n0, *n1, *n2, *n3, *n4;

    n0 = new MyNode;
    n1 = new MyNode;
    n2 = new MyNode;
    n3 = new MyNode;
    n4 = new MyNode;

    n0->x = 0;
    n1->x = 1;
    n2->x = 2;
    n3->x = 3;
    n4->x = 4;

    n0->next = n1;
    n1->next = n2;
    n2->next = n3;
    n3->next = n4;
    n4->next = NULL;

    cout<<"x = "<<n0->x<<endl;
    cout<<"x = "<<n1->x<<endl;
    cout<<"x = "<<n2->x<<endl;
    cout<<"x = "<<n2->next->x<<endl;
    cout<<"x = "<<n2->next->next->x<<endl;

    }
///***************************************************
void Application::Main05(){
    MyNode* n0, *n1, *n2, *n3, *n4;

    n0 = new MyNode;
    n1 = new MyNode;
    n2 = new MyNode;
    n3 = new MyNode;
    n4 = new MyNode;

    n0->x = 0;
    n1->x = 1;
    n2->x = 2;
    n3->x = 3;
    n4->x = 4;

    n0->next = n1;
    n1->next = n2;
    n2->next = n3;
    n3->next = n4;
    n4->next = NULL;

    cout<<"x = "<<n0->x<<endl;
    cout<<"x = "<<n1->x<<endl;
    cout<<"x = "<<n1->next->x<<endl;
    cout<<"x = "<<n1->next->next->x<<endl;
    cout<<"x = "<<n1->next->next->next->x<<endl;

    }
///***************************************************
void Application::Main06(){
    MyNode* n0, *n1, *n2, *n3, *n4;

    n0 = new MyNode;
    n1 = new MyNode;
    n2 = new MyNode;
    n3 = new MyNode;
    n4 = new MyNode;

    n0->x = 0;
    n1->x = 1;
    n2->x = 2;
    n3->x = 3;
    n4->x = 4;

    n0->next = n1;
    n1->next = n2;
    n2->next = n3;
    n3->next = n4;
    n4->next = NULL;

    cout<<"x = "<<n0->x<<endl;
    cout<<"x = "<<n0->next->x<<endl;
    cout<<"x = "<<n0->next->next->x<<endl;
    cout<<"x = "<<n0->next->next->next->x<<endl;
    cout<<"x = "<<n0->next->next->next->next->x<<endl;

    }
///***************************************************
void Application::Main07(){
    MyNode* n0, *n1, *n2, *n3, *n4;

    n0 = new MyNode;
    n1 = new MyNode;
    n2 = new MyNode;
    n3 = new MyNode;
    n4 = new MyNode;

    n0->x = 0;
    n1->x = 1;
    n2->x = 2;
    n3->x = 3;
    n4->x = 4;

    n0->next = n1;
    n0->next->next = n2;
    n0->next->next->next = n3;
    n0->next->next->next->next = n4;
    n0->next->next->next->next->next = NULL;

    cout<<"x = "<<n0->x<<endl;
    cout<<"x = "<<n0->next->x<<endl;
    cout<<"x = "<<n0->next->next->x<<endl;
    cout<<"x = "<<n0->next->next->next->x<<endl;
    cout<<"x = "<<n0->next->next->next->next->x<<endl;

    }
///***************************************************
void Application::Main08(){
    MyNode* n0, *n1, *n2, *n3, *n4;

    n0 = new MyNode;
    n1 = new MyNode;
    n2 = new MyNode;
    n3 = new MyNode;
    n4 = new MyNode;

    n0->next = n1;
    n0->next->next = n2;
    n0->next->next->next = n3;
    n0->next->next->next->next = n4;
    n0->next->next->next->next->next = NULL;

    n0->x = 0;
    n0->next->x = 1;
    n0->next->next->x = 2;
    n0->next->next->next->x = 3;
    n0->next->next->next->next->x = 4;

    cout<<"x = "<<n0->x<<endl;
    cout<<"x = "<<n0->next->x<<endl;
    cout<<"x = "<<n0->next->next->x<<endl;
    cout<<"x = "<<n0->next->next->next->x<<endl;
    cout<<"x = "<<n0->next->next->next->next->x<<endl;

    }
///***************************************************
void Application::Main09(){
    MyNode* n0;

    n0 = new MyNode;
    n0->next = new MyNode;
    n0->next->next = new MyNode;
    n0->next->next->next = new MyNode;
    n0->next->next->next->next = new MyNode;
    n0->next->next->next->next->next = NULL;

    n0->x = 0;
    n0->next->x = 1;
    n0->next->next->x = 2;
    n0->next->next->next->x = 3;
    n0->next->next->next->next->x = 4;

    cout<<"x = "<<n0->x<<endl;
    cout<<"x = "<<n0->next->x<<endl;
    cout<<"x = "<<n0->next->next->x<<endl;
    cout<<"x = "<<n0->next->next->next->x<<endl;
    cout<<"x = "<<n0->next->next->next->next->x<<endl;

    }
///***************************************************
void Application::Main10(){
    MyNode* n0, *walk;

    n0 = new MyNode;
    walk = n0;

    walk->next = new MyNode;
    walk->next->next = new MyNode;
    walk->next->next->next = new MyNode;
    walk->next->next->next->next = new MyNode;
    walk->next->next->next->next->next = NULL;

    n0->x = 0;
    n0->next->x = 1;
    n0->next->next->x = 2;
    n0->next->next->next->x = 3;
    n0->next->next->next->next->x = 4;

    cout<<"x = "<<n0->x<<endl;
    cout<<"x = "<<n0->next->x<<endl;
    cout<<"x = "<<n0->next->next->x<<endl;
    cout<<"x = "<<n0->next->next->next->x<<endl;
    cout<<"x = "<<n0->next->next->next->next->x<<endl;

    }
///***************************************************
void Application::Main11(){
    MyNode* n0, *walk;

    n0 = new MyNode;
    walk = n0;

    walk->next = new MyNode;
    walk = walk->next;

    walk->next= new MyNode;
    walk->next->next = new MyNode;
    walk->next->next->next = new MyNode;
    walk->next->next->next->next = NULL;

    n0->x = 0;
    n0->next->x = 1;
    n0->next->next->x = 2;
    n0->next->next->next->x = 3;
    n0->next->next->next->next->x = 4;

    cout<<"x = "<<n0->x<<endl;
    cout<<"x = "<<n0->next->x<<endl;
    cout<<"x = "<<n0->next->next->x<<endl;
    cout<<"x = "<<n0->next->next->next->x<<endl;
    cout<<"x = "<<n0->next->next->next->next->x<<endl;

    }
///***************************************************
void Application::Main12(){
    MyNode* n0, *walk;

    n0 = new MyNode;
    walk = n0;

    walk->next = new MyNode;
    walk = walk->next;

    walk->next= new MyNode;
    walk = walk->next;

    walk->next= new MyNode;
    walk = walk->next;

    walk->next = new MyNode;
    walk = walk->next;

    walk->next = NULL;

    n0->x = 0;
    n0->next->x = 1;
    n0->next->next->x = 2;
    n0->next->next->next->x = 3;
    n0->next->next->next->next->x = 4;

    cout<<"x = "<<n0->x<<endl;
    cout<<"x = "<<n0->next->x<<endl;
    cout<<"x = "<<n0->next->next->x<<endl;
    cout<<"x = "<<n0->next->next->next->x<<endl;
    cout<<"x = "<<n0->next->next->next->next->x<<endl;

    }
///***************************************************
void Application::Main13(){
    MyNode* n0, *walk;

    n0 = new MyNode;
    walk = n0;

    for(int i=1; i<5;++i){
        walk->next = new MyNode;
        walk = walk->next;
        }

    walk->next = NULL;

    n0->x = 0;
    n0->next->x = 1;
    n0->next->next->x = 2;
    n0->next->next->next->x = 3;
    n0->next->next->next->next->x = 4;

    cout<<"x = "<<n0->x<<endl;
    cout<<"x = "<<n0->next->x<<endl;
    cout<<"x = "<<n0->next->next->x<<endl;
    cout<<"x = "<<n0->next->next->next->x<<endl;
    cout<<"x = "<<n0->next->next->next->next->x<<endl;

    }
///***************************************************
void Application::Main14(){
    MyNode* n0, *walk;

    n0 = new MyNode;
    walk = n0;

    for(int i=1; i<5;++i){
        walk->next = new MyNode;
        walk = walk->next;
        }

    walk->next = NULL;

    walk = n0;

    n0->x = 0;

    while (walk->next !=NULL){
        walk->next->x = walk->x + 1;
        walk=walk->next;
        }


    cout<<"x = "<<n0->x<<endl;
    cout<<"x = "<<n0->next->x<<endl;
    cout<<"x = "<<n0->next->next->x<<endl;
    cout<<"x = "<<n0->next->next->next->x<<endl;
    cout<<"x = "<<n0->next->next->next->next->x<<endl;

    }
///***************************************************
void Application::Main15(){
    MyNode* n0, *walk;

    n0 = new MyNode;
    walk = n0;

    for(int i=1; i<5;++i){
        walk->next = new MyNode;
        walk = walk->next;
        }

    walk->next = NULL;

    walk = n0;

    n0->x = 0;

    while (walk->next !=NULL){
        walk->next->x = walk->x + 1;
        walk=walk->next;
        }

    walk =n0;
    while (walk!=NULL){
        cout<<"x = "<<walk->x<<endl;
        walk = walk->next;
        }
    }
///***************************************************
void Application::Main16(){
    MyNode* n0, *walk;

    n0 = new MyNode;
    walk = n0;

    for(int i=1; i<5;++i){
        walk->next = new MyNode;
        walk = walk->next;
        }

    walk = n0;

    while (walk->next !=NULL){
        walk->next->x = walk->x + 1;
        walk=walk->next;
        }

    walk =n0;
    while (walk!=NULL){
        cout<<"x = "<<walk->x<<endl;
        walk = walk->next;
        }
    }
///***************************************************
void Application::Main17(){
    MyNode* n0, *walk;

    n0 = new MyNode;
    walk = n0;

    for(int i=1; i<5;++i){
        walk->next = new MyNode(walk->x+1);
        walk = walk->next;
        }

    walk =n0;
    while (walk!=NULL){
        cout<<"x = "<<walk->x<<endl;
        walk = walk->next;
        }
    }
///***************************************************
void Application::Main18(){
    MyNode* n0, *walk;

    n0 = MyListNew(5,10,2);

    walk =n0;
    while (walk!=NULL){
        cout<<"x = "<<walk->x<<endl;
        walk = walk->next;
        }
    }
///***************************************************
void Application::Main19(){
    MyNode* n0, *walk;

    n0 = MyListNew(5,10,2);
    MyListPrint(n0)->next = new MyNode(123);

    cout<<"\n\n***************************\n\n";
    MyListPrint(n0);

    }
///***************************************************




