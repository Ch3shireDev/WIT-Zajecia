#ifndef MyNode_H
#define MyNode_H
#include "MyUtility.h"
class MyNode{
    public:
        MyNode(int = 0);
        int x;
        MyNode* next;
    };
///***************************************************
MyNode* MyListNew(int, int=0, int=1);
///***************************************************
MyNode* MyListPrint(MyNode*);
///***************************************************

#include "MyNode.cpp"
#endif //MyNode_H
