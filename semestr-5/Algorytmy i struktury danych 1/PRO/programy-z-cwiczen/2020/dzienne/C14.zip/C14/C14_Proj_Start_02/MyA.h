#ifndef MyA_H
#define MyA_H
#include "MyUtility.h"

class MyA{
    public:
        MyA(int, int);
        virtual string ToString(string myStr="");
        int X1();
        int X0();

        virtual int X3();
        virtual int X2();
        virtual MyA* Clone();

    protected:
        int x1;
        int x0;

    };
#include "MyA.cpp"
#endif // MyA_H
