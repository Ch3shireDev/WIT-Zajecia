#ifndef MyNode_H
#define MyNode_H
#include "MyUtility.h"
class MyNode{

    };
#include "MyNode.cpp"
#endif //MyNode_H
