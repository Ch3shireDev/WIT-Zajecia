void Application::Run(){
    Main07();
    }
///****************************************
void Application::Main01(){
    cout<<"\n\n\t\tTest Main01\n\n";
    }
///****************************************
void Application::Main02(){
    MyClass01 myClass01;
    myClass01.Ini(1,2,3);
    myClass01.Print("\n");
    }
///****************************************
void Application::Main03(){
    MyClass01 myClass01, m02, m03, m04;
    MyClass01 KonstantynopolitanczykowineczkunieczkazKrakowaiokolic;
    }
///****************************************
void Application::Main04(){
    MyClass01 myClass01, m02, m03, m04;
    MyClass01 KonstantynopolitanczykowineczkunieczkazKrakowaiokolic;
    myClass01.Print("\n");
    m02.Print("\n");
    m03.Print("\n");
    m04.Print("\n");
    KonstantynopolitanczykowineczkunieczkazKrakowaiokolic.Print("\n");
    }
///****************************************
void Application::Main05(){
    MyClass01 myClass01, m02(11,12,13);
    myClass01.Print("\n");
    m02.Print("\n");
    }
///****************************************
void Application::Main06(){
    MyClass01 myClass01, m02(11,12,13);
    myClass01.Print();
    m02.Print("\n");
    }
///****************************************
void Application::Main07(){
    MyClass01 myClass01(11,12,13);
    myClass01.Print("\n");
   // myClass01.x2 =123;
    myClass01.Print("\n");
    }
///****************************************
