#include <cstdio>
#include <cstdlib>

int main(){
    int* *t;

    int s1 = 3, s2 = 5;
    int i, j;

    t=(int**)malloc(s1*sizeof(int*));

    for(i = 0; i<s1; ++i)
        t[i] = (int*)malloc(sizeof(int)*s2);

    for(i = 0; i<s1; ++i)
        for(j=0; j<s2; ++j)
            t[i][j] = i + j;


    for(j=0; j<s2;++j){
        printf("[%2d]", t[0][j]);
        printf("[%2d]", t[1][j]);
        printf("[%2d]", t[2][j]);
        printf("\n");
        }



    return 0;
    }
