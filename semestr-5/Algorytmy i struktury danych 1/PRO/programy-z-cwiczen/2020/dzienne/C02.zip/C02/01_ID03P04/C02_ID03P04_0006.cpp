#include <cstdio>
#include <cstdlib>


int main(){
    int *z;
    z = (int*)malloc(8*sizeof(int));


    z[0] = 'a'; /// z[0]  <=> *(z+0)
    z[1] = 'b'; /// z[1]  <=> *(z+1)
    z[2] = 'c'; /// z[2]  <=> *(z+2)
    z[3] = 'd'; /// z[3]  <=> *(z+3)
    z[4] = 'e'; /// z[4]  <=> *(z+4)
    z[5] = 'f'; /// z[5]  <=> *(z+5)
    z[6] = 'g'; /// z[6]  <=> *(z+6)
    z[7] = 'h'; /// z[7]  <=> *(z+7)




    for(int i = 0; i< 8;++i)
        printf("%d\n",z[i]);


    return 0;
    }
