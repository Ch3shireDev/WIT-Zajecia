#include <cstdio>
#include <cstdlib>

int main(){
    int * t;
    int s = 8;

    t = (int*)malloc(s*sizeof(int));

    for(int i=0; i<s;++i)
        t[i] = i;

    for(int i=0; i<s;++i)
        printf("t[%d] = %d\n", i, t[i]);

    /**
    t[i] <=> *(t+i) <=> *(i+t) <=> i[t]
    */

    2[t] = 123;
    2[++t] = 77;
    --t;
    printf("\n-------------\n\n");

    for(int i=0; i<s;++i)
        printf("t[%d] = %d\n", i, t[i]);

    return 0;
    }
