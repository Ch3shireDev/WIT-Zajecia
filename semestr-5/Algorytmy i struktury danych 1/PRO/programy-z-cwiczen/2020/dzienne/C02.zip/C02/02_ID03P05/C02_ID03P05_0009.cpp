#include <cstdio>
#include <cstdlib>

int main(){
    int *t;
    int s = 1000;
    int x =0;

    t =(int*)malloc(sizeof(int)*s);

    for(int i = 0; i< s;++i){
        t[i] = i;
        x+=t[i];
        //printf("%d\n",t[i]);
        }

    printf("x = %d\n",x);



    free(t);

    return 0;
    }
/**
4, 3, 2, 1

n? = 8

1
1
2
3
5
8
13
21

*/
