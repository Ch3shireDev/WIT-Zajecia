#include <cstdio>


int main(){
    double x;
    int *p1, *p2;

    p1 = p2 = (int*)&x;
    *p1 = 5;
    *(++p2) = 7;
    printf("a = %d, b = %d\n", *p1, *p2);

    return 0;
    }
