#include <cstdio>
#include <cstdlib>


int main(){
    int *z;
    z = (int*)malloc(800*sizeof(int));
    int x = 0;


    for(int i = 0; i< 800;++i){
        z[i] = 97+i;
        x+=i;
        printf("%3d\n",z[i]);
        }


    printf("x = %d\n",x);


    return 0;
    }
