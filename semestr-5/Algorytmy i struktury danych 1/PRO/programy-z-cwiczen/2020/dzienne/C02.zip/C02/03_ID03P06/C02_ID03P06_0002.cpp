#include <cstdio>

int main(){
    double x;
    char *z, *k;
    z = (char*)&x;

    z[0] = 'a'; ///z[0] <=> *(z+0)
    z[1] = 'b'; ///z[1] <=> *(z+1)
    z[2] = 'c';
    z[3] = 'd';
    z[4] = 'e';
    z[5] = 'f';
    z[6] = 'g';
    z[7] = 'h';


    for(int  i = 0; i<8;++i)
        printf("%c\n",z[i]);

    printf("\n--------------------\n\n");
    for(int  i = 0; i<8;++i)
        printf("%c\n",*z++);

    for(int  i = 0; i<8;++i)
        --z;
    printf("\n--------------------\n\n");
    for(int  i = 0; i<8;++i)
        printf("%c\n",*z++);
    k=z;
    z-=8;
    printf("\n--------------------\n\n");
    while(z<k)
        printf("%c\n",*z++);

    z-=8;
    k = z+8;
    printf("\n--------------------\n\n");
    while(z< k)
        printf("%c\n",*z++);

    return 0;
    }
