#include <cstdio>
#include <cstdlib>

int main(){
    int* *t;

    int s1 = 3, s2 = 5;
    int i, j;

    t=(int**)malloc(s1*sizeof(int*));

    for(i = 0; i<s1; ++i)
        t[i] = (int*)malloc(sizeof(int)*s2);

    for(i = 0; i<s1; ++i)
        for(j=0; j<s2; ++j)
            t[i][j] = i + j;


    for(i = 0; i<s1; ++i){
        for(j = 0; j<s2; ++j)
            printf("[%2d]", t[i][j]);
        printf("\n");
        }
    printf("\n-----------------------------\n");


    for(j = 0; j<s2; ++j){
        for(i = 0; i<s1; ++i)
            printf("[%2d]", t[i][j]);
        printf("\n");
        }

    for(i = 0; i<s1; ++i)
        free(t[i]);
    free(t);
    return 0;
    }
