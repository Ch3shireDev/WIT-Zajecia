#include <cstdio>
#include <cstdlib>


int main(){
    int *z;
    z = (int*)malloc(20*sizeof(int));
    int x = 0;


    for(int i = 0; i<20;++i){
        z[i] = 7+i*10;
        x+=i;
        printf("%3d\n",z[i]);
        }


    printf("x = %d\n",x);


    return 0;
    }
