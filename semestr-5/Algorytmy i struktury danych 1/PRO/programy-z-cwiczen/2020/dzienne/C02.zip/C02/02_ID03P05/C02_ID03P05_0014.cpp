#include <cstdio>
#include <cstdlib>

int main(){
    int *t0, *t1, *t2;
    int* *t;

    int s1 = 3, s2 = 5;
    int i, j;

    t=(int**)malloc(s1*sizeof(int*));

    t0 =(int*)malloc(sizeof(int)*s2);
    t1 =(int*)malloc(sizeof(int)*s2);
    t2 =(int*)malloc(sizeof(int)*s2);

    t[0] = (int*)malloc(sizeof(int)*s2);
    t[1] = (int*)malloc(sizeof(int)*s2);
    t[2] = (int*)malloc(sizeof(int)*s2);

    for(j=0; j<s2;++j)
        t[0][j] = 0 +j;

    for(j=0; j<s2;++j)
        t[1][j] = 1 +j;

    for(j=0; j<s2;++j)
        t[2][j] = 2 +j;

    for(j=0; j<s2;++j){
        printf("[%2d]", t[0][j]);
        printf("[%2d]", t[1][j]);
        printf("[%2d]", t[2][j]);
        printf("\n");
        }



    return 0;
    }
