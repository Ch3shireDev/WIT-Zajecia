#include <cstdio>
#include <cstdlib>

int main(){
    int * t;
    int s = 8;

    t = (int*)malloc(s*sizeof(int));

    for(int i=0; i<s;++i)
        t[i] = i;

    for(int i=0; i<s;++i)
        printf("t[%d] = %d\n", i, t[i]);


    return 0;
    }
/**
5, 4, 3, 2, 1
n? = 8

1
1
2
3
5
8
13
21
*/
