#include <cstdio>
#include <cstdlib>

int main(){
    int *t;
    int s;

    printf("n? = ");
    scanf("%d", &s);

    t =(int*)malloc(sizeof(int)*s);

    if(s>0)t[0] = 1;
    if(s>1)t[1] = 1;

    for(int i = 2; i< s;++i)
        t[i] = t[i-1] + t[i-2];

    printf("\n");

    for(int i = 0; i< s;++i)
        printf("%3d\n",t[i]);

    printf("\n----------------------------------\n\n");

    /// *t <=> t[0]
    for(int i = 0; i< s;++i)
        printf("%3d\n",*(t+i));

    /// t[i] <=>  *(t+i) <=>  *(i+t) <=> i[t]

    printf("\n----------------------------------\n\n");

    for(int i = 2; i< s;++i)
        i[t] = i*10;
    for(int i = 0; i< s;++i)
        printf("%3d\n",i[t]);

    printf("\n----------------------------------\n\n");

    2[t] = 123;
    2[++t] = 99;
    --t;
    for(int i = 0; i< s;++i)
        printf("%3d\n",t[i]);


    free(t);
    return 0;
    }
