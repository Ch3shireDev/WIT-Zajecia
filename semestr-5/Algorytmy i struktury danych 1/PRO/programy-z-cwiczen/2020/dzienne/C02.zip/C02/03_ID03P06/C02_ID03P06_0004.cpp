#include <cstdio>
#include <cstdlib>

int main(){
    char *z;

    z = (char*)malloc(8);
    z[0] = 'a'; ///z[0] <=> *(z+0)
    z[1] = 'b'; ///z[1] <=> *(z+1)
    z[2] = 'c';
    z[3] = 'd';
    z[4] = 'e';
    z[5] = 'f';
    z[6] = 'g';
    z[7] = 'h';


    for(int  i = 0; i<8;++i)
        printf("%c\n",z[i]);



    return 0;
    }
