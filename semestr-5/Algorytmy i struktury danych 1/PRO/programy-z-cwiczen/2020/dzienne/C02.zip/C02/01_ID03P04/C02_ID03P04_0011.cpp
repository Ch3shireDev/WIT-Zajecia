#include <cstdio>
#include <cstdlib>


int main(){
    int *z;
    int st=990;

    z = (int*)malloc(st*sizeof(int));



    free(z);

    return 0;
    }
