#include <cstdio>
#include <cstdlib>

int main(){
    int *t;
    int s = 8;

    t =(int*)malloc(sizeof(int)*s);

    for(int i = 0; i< s;++i)
        t[i] = i;

    for(int i = 0; i< s;++i)
        printf("%d\n",t[i]);


    free(t);

    return 0;
    }
