#include <cstdio>
#include <cstdlib>

int main(){
    int* *t;

    int s1 = 3, s2 = 5;
    int i, j;

    t=(int**)malloc(s1*sizeof(int*));

    for(i = 0; i<s1 ;++i)
        t[i] = (int*)malloc(sizeof(int)*s2);

    for(j=0; j<s2;++j)
        t[0][j] = 0 +j;

    for(j=0; j<s2;++j)
        t[1][j] = 1 +j;

    for(j=0; j<s2;++j)
        t[2][j] = 2 +j;

    for(j=0; j<s2;++j){
        printf("[%2d]", t[0][j]);
        printf("[%2d]", t[1][j]);
        printf("[%2d]", t[2][j]);
        printf("\n");
        }



    return 0;
    }
