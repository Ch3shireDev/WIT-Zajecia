#include <cstdio>
#include <cstdlib>

int main(){
    int** t;
    int s0 = 3, s1 = 5;
    int i, j;

    t = (int**) malloc(sizeof(int*)*s0);

    for(i = 0; i< s0;++i)
        t[i] = (int*)malloc(s1*sizeof(int));


    for(j = 0; j<s1;++j)
        t[0][j] = 0 + j;

    for(j = 0; j<s1;++j)
        t[1][j] = 1 + j;

    for(j = 0; j<s1;++j)
        t[2][j] = 2 + j;

    for(i = 0; i< s0;++i){
        for(j = 0; j<s1;++j)
            printf("[%2d]", t[i][j]);
        printf("\n");
        }
    printf("-------------------\n");
    for(j = 0; j<s1;++j){
        for(i = 0; i< s0;++i)
            printf("[%2d]", t[i][j]);
        printf("\n");
        }

    for(i = 0; i< s0;++i)
        free(t[i]);
    free(t);
    return 0;
    }
