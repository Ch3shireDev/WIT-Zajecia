#include <cstdio>
#include <cstdlib>

int main(){
    int** t;
    int s0 = 3, s1 = 5;
    int i, j;

    t = (int**) malloc(sizeof(int*)*s0);

    for(i = 0; i< s0;++i)
        t[i] = (int*)malloc(s1*sizeof(int));


    for(j = 0; j<s1;++j)
        t[0][j] = 0 + j;

    for(j = 0; j<s1;++j)
        t[1][j] = 1 + j;

    for(j = 0; j<s1;++j)
        t[2][j] = 2 + j;

    for(j = 0; j<s1;++j){
        printf("[%2d]", t[0][j]);
        printf("[%2d]", t[1][j]);
        printf("[%2d]", t[2][j]);
        printf("\n");
        }

    return 0;
    }
