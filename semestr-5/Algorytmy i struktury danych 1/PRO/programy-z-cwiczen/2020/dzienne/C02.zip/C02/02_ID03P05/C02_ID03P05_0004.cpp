#include <cstdio>
#include <cstdlib>

int main(){
    void* x;
    char *z;

    x = malloc(8);

    z =(char*)x;

    z[0] = 'a';
    z[1] = 'b';
    z[2] = 'c';
    z[3] = 'd';
    z[4] = 'e';
    z[5] = 'f';
    z[6] = 'g';
    z[7] = 'h';

    for(int i = 0; i< 8;++i)
        printf("%c\n",z[i]);



    return 0;
    }
