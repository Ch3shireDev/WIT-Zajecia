#include <cstdio>
#include <cstdlib>


int main(){
    int *t0, *t1, *t2;
    int s1=3, s2 =5;
    int j;

    t0 = (int*)malloc(sizeof(int)*s2);
    t1 = (int*)malloc(sizeof(int)*s2);
    t2 = (int*)malloc(sizeof(int)*s2);

    for(j=0; j<s2;++j)
        t0[j] = j +0;

    for(j=0; j<s2;++j)
        t1[j] = j +1;

    for(j=0; j<s2;++j)
        t2[j] = j +2;

    for(j=0; j<s2;++j){
        printf("[%2d]", t0[j]);
        printf("[%2d]", t1[j]);
        printf("[%2d]", t2[j]);
        printf("\n");
        }

    return 0;
    }
