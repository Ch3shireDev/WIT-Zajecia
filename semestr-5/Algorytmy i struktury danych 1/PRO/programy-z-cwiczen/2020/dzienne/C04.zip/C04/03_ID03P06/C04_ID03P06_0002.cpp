#include <cstdio>
#include <cstdlib>
///******************************************************
int MyRead(char*);
int MyAdd(int, int);
int MyAdd(double, int);
int MyAdd(int, double);
int MyAdd(double, double);
int MyAdd(int, int, int);
///******************************************************
int MyRead(char* myStr){
    int x;
    printf("%s", myStr);
    scanf("%d", &x);
    return x;
    }
///******************************************************
int MyAdd(int x, int y){return x + y;}
int MyAdd(double x, int y){return (int)(2*x) + y;}
int MyAdd(int x, double y){return x + (int)(4*y);}
int MyAdd(double x, double y){return (int)(2*x + 2*y);}
///******************************************************
int MyAdd(int x, int y,  int z){return x + y + z;}
///******************************************************
///******************************************************
int main(){
    int x = MyRead("x? = ");
    int y = MyRead("y? = ");
    int z = MyRead("z? = ");
    int res = MyAdd(x, y);

    printf("%3d + %3d = %4d\n", x, y, res);
    res = MyAdd(x, y, z);
    printf("%3d + %3d + %3d = %4d\n", x, y, z, res);
    printf("\n\n----------------------------\n\n");
    printf("int + int = %d\n", MyAdd(3, 3));
    printf("double + int = %d\n", MyAdd(3.0, 3));
    printf("int + double = %d\n", MyAdd(3, 3.0));
    printf("double + double = %d\n", MyAdd(3.0, 3.0));


    return 0;
    }

