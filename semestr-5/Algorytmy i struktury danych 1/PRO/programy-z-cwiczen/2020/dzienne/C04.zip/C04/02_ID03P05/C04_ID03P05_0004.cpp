#include <cstdio>
#include <cstdlib>
#include <cstring>
///******************************************************
int MyRead(char*);
int MyAdd(int, int);
int MyAdd(int, int, int);
///******************************************************
int MyRead(char* myStr){
    int x;
    printf("%s", myStr);
    scanf("%d", &x);
    return x;
    }
///******************************************************
int MyAdd(int x, int y){return x+y;}
int MyAdd(int x, int y, int z){return x+y+z;}
///******************************************************
///******************************************************
int main(){

    int x = MyRead("x? = ");
    int y = MyRead("y? = ");
    int z = MyRead("z? = ");
    int res = MyAdd(x, y);
    printf("%d + %d = %d\n", x, y, res);
    res = MyAdd(x, y, z);
    printf("%d + %d + %d = %d\n", x, y, z, res);

    return 0;
    }

