#include <cstdio>
#include <cstdlib>
///******************************************************
void * MyStruct01(double, int);
double MyStruct01ReadDouble(void*);
int MyStruct01ReadInt(void*);
///******************************************************
int MyRead(char*);
///******************************************************
///******************************************************
void * MyStruct01(double xF, int xI){
    void* myStruct01 = malloc(sizeof(double) + sizeof(int));
    *((double*)myStruct01) = xF;
    *((int*)(((double*)myStruct01)+1)) = xI;
    return myStruct01;
    }
///******************************************************
double MyStruct01ReadDouble(void* myStruct01){
    return *((double*)myStruct01);
    }
///******************************************************
int MyStruct01ReadInt(void* myStruct01){
    return *((int*)(((double*)myStruct01)+1));
    }
///******************************************************
int MyRead(char* myStr){
    int x;
    printf("%s", myStr);
    scanf("%d", &x);
    return x;
    }
///******************************************************
///******************************************************
int main(){
    void* myStruct01 = MyStruct01(2.5, 11);

    printf("double  =%lf, int = %d\n",
           MyStruct01ReadDouble(myStruct01),
           MyStruct01ReadInt(myStruct01));

    free(myStruct01);
    return 0;
    }

