#include <cstdio>
#include <cstdlib>
#include <cstring>
///******************************************************
int MyRead(char*);
int MyAdd(int, int);
///******************************************************
int MyRead(char* myStr){
    int x;
    printf("%s", myStr);
    scanf("%d", &x);
    return x;
    }
///******************************************************
int MyAdd(int x, int y){return x+y;}
///******************************************************
///******************************************************
int main(){
    char * myS = (char*) malloc(30);
    char * pomS = "Ala ma kota";

    for(int i = 0; i<strlen(pomS);++i)
        myS[i] = pomS[i];
    myS[strlen(pomS)]='\0';
    printf("pomS: %s\n", pomS);
    printf("myS: %s\n", myS);
    /*
    int x = MyRead("x? = ");
    int y = MyRead("y? = ");
    int res = MyAdd(x, y);
    printf("%d + %d = %d\n", x, y, res);
*/
    free(myS);
    return 0;
    }

