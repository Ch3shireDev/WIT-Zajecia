#include <cstdio>
#include <cstdlib>
///******************************************************
int MyRead(char*);
int MyAdd(int, int);
int MySub(int, int);
int MyComp(int (*Ff)(int, int), int, int);
///******************************************************
int MyRead(char* myStr){
    int x;
    printf("%s", myStr);
    scanf("%d", &x);
    return x;
    }
///******************************************************
int MyAdd(int x0, int x1){return x0 + x1;}
///******************************************************
int MySub(int x0, int x1){return x0 - x1;}
///******************************************************
int MyComp(int (*Ff)(int, int), int x, int y){return Ff(x, y);}
///******************************************************
///******************************************************
int main(){
    int x0 = MyRead("x0? = ");
    int x1 = MyRead("x1? = ");
    printf("%d + %d = %d\n", x0, x1, MyComp(MyAdd, x0, x1));
    printf("%d - %d = %d\n", x0, x1, MyComp(MySub, x0, x1));

    return 0;
    }

///12, 12, 10, 10, 10, 8, 8, 8, 8, 7, 7, 7, 7, 7
