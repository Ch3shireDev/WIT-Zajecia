#include <cstdio>
#include <cstdlib>
#include <cstring>
///******************************************************
int MyRead(char*);
int MyAdd(int, int);
///******************************************************
int MyRead(char* myStr){
    int x;
    printf("%s", myStr);
    scanf("%d", &x);
    return x;
    }
///******************************************************
int MyAdd(int x, int y){return x+y;}
///******************************************************
///******************************************************
int main(){
    char * myS = (char*) malloc(70);
    char * pomS = "Ala ma kota";
    char * pom2 = "Kotki na wierzbie";

    for(int i = 0; i<strlen(pomS);++i)
        myS[i] = pomS[i];
    myS[strlen(pomS)]='\0';
    printf("pomS: %s\n", pomS);
    printf("myS: %s\n", myS);

    for(int i = strlen(pomS)+1; i<strlen(pomS)+1+strlen(pom2);++i)
        myS[i] = pom2[i-strlen(pomS)-1];
    myS[strlen(pomS)+1+strlen(pom2)]='\0';
    printf("myS: %s\n", myS);
    printf("myS: %s\n", myS+strlen(pomS)+1);


    /*
    int x = MyRead("x? = ");
    int y = MyRead("y? = ");
    int res = MyAdd(x, y);
    printf("%d + %d = %d\n", x, y, res);
*/
    free(myS);
    return 0;
    }

