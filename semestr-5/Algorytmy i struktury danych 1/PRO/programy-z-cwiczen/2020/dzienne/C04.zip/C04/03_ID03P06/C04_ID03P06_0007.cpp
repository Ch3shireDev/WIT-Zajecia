#include <cstdio>
#include <cstdlib>
///******************************************************
struct MyStructure02{
    double xF;
    int xI;
    };
///******************************************************
void* MyStructure01(double, int);
double MyStruct01ReadDouble(void*);
int MyStruct01ReadInt(void*);
///******************************************************
int MyRead(char*);
///******************************************************
///******************************************************
void* MyStructure01(double xF, int xI){
    void* myStructure01;
    myStructure01 = malloc(sizeof(double) + sizeof(int));
    *((double*)myStructure01) = xF;
    *((int*)(((double*)myStructure01)+1)) = xI;
    return myStructure01;
    }
///******************************************************
double MyStruct01ReadDouble(void* myStructure01){
    return *((double*)myStructure01);
    }
///******************************************************
int MyStruct01ReadInt(void* myStructure01){
    return *((int*)(((double*)myStructure01)+1));
    }
///******************************************************
int MyRead(char* myStr){
    int x;
    printf("%s", myStr);
    scanf("%d", &x);
    return x;
    }
///******************************************************
///******************************************************
///******************************************************
int main(){
    void* myStructure01 = MyStructure01(3.5, 7);
    printf("double  = %lf\n", MyStruct01ReadDouble(myStructure01));
    printf("int  = %d\n", MyStruct01ReadInt(myStructure01));

    MyStructure02 myStructure02;
    myStructure02.xF = 4.7;
    myStructure02.xI = 12;
    printf("double  = %lf\n", myStructure02.xF);
    printf("int  = %d\n", myStructure02.xI);
    printf("double  = %lf\n", *((double*)&myStructure02));
    printf("int  = %d\n", *(((double*)&myStructure02)+1));

    return 0;
    }

