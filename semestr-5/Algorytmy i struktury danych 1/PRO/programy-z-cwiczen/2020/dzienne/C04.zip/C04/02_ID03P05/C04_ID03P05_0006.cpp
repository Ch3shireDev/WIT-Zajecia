#include <cstdio>
#include <cstdlib>
///******************************************************
int MyRead(char*);
int MyAdd(int, int);
int MySub(int, int);
int MyComp(int (*Ff)(int, int), int, int);
///******************************************************
int MyRead(char* myStr){
    int x;
    printf("%s", myStr);
    scanf("%d", &x);
    return x;
    }
///******************************************************
int MyAdd(int x, int y){return x + y;}
///******************************************************
int MySub(int x, int y){return x - y;}
///******************************************************
int MyComp(int (*Ff)(int, int), int x, int y){
    return Ff(x, y);
    }
///******************************************************
///******************************************************
int main(){

    int x0 = MyRead("x0? = ");
    int x1 = MyRead("x1? = ");
    printf("%d + %d = %d\n", x0, x1, MyComp(MyAdd, x0, x1));
    printf("%d - %d = %d\n", x0, x1, MyComp(MySub, x0, x1));
    return 0;
    }

