void FF(){
    TabInt01 pom(999999999);
    }
void HH(TabInt01 pom){}
///*****************************************
void Application::Run(){
    Main04();
    }
///*****************************************
void Application::Main01(){
    TabInt01 t1(5);
    t1.Fill();
    t1.Print();
    }
///*****************************************
void Application::Main02(){
    FF();

    for(int i=0 ; i< 99999; ++i)
        FF();
    }
///*****************************************
void Application::Main03(){
    TabInt01 t0(5);
    cout<<"t0: *********************\n";

    t0.Fill();
    t0.Print();
    HH(t0);

    TabInt01 TT1(5);
    TT1.Fill(10);

    cout<<"TT1: ######################\n";
    TT1.Print();
    cout<<"t0: *********************\n";
    t0.Print();

    }
///*****************************************
void Application::Main04(){
    TabInt01 t0(5);
    cout<<"t0: *********************\n";

    t0.Fill();
    t0.Print();
    {
    TabInt01 tmp(99999999);
    tmp = t0;
    }

    TabInt01 TT1(5);
    TT1.Fill(10);

    cout<<"TT1: ######################\n";
    TT1.Print();
    cout<<"t0: *********************\n";
    t0.Print();

    }
///*****************************************

