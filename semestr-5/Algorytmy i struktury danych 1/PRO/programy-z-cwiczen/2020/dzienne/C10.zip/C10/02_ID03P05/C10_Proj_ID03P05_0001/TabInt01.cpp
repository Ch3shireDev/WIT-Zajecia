///*****************************************
TabInt01::TabInt01(int sT){
    this->sT= 0;
    this->pT = NULL;
    if(sT>0){
        this->sT= sT;
        this->pT = new int[sT];
        }
    }
///*****************************************
TabInt01::TabInt01(TabInt01& s){
    sT = 0;
    pT = NULL;
    if(s.sT>0){
        sT = s.sT;
        pT = new int[sT];
        for(int i = 0; i< sT;++i)
            pT[i] = s.pT[i];
        }
    }
///*****************************************
TabInt01::~TabInt01(){
    delete[] pT;
    pT = NULL;
    sT = 0;
    }
///*****************************************
TabInt01 TabInt01::operator=
                    (const TabInt01& s){
    if(pT != NULL) delete[] pT;
    sT = s.sT;
    if(sT>0){
        pT = new int[sT];
        for(int i = 0; i<sT; ++i)
            pT[i] = s.pT[i];
        }
    return *this;
    }
///*****************************************
void TabInt01::Fill(int x){
    for(int i = 0; i< sT; ++i)
        pT[i] = i+x;
    }
///*****************************************
void TabInt01::Print(){
    for(int i = 0; i< sT; ++i)
        cout<<"T["<<i<<"]="<<pT[i]<<endl;
    }
///*****************************************
