void FF(TabInt01 pom){
    }

///*****************************************
void Application::Run(){
    Main03();
    }
///*****************************************
void Application::Main01(){
    TabInt01 test;

    }
///*****************************************
void Application::Main02(){
    TabInt01 t(5);
    t.FillIter(0);
    cout<<"t:  XXXXXXXXXXXXXXXXXX"<<endl;
    t.Print();
    FF(t);
    TabInt01 t1(5);
    t1.FillIter(10);
    cout<<"t1: ******************"<<endl;
    t1.Print();
    cout<<"t:  XXXXXXXXXXXXXXXXXX"<<endl;
    t.Print();
    }
///*****************************************
void Application::Main03(){
    TabInt01 t(5);
    t.FillIter(0);
    cout<<"t:  XXXXXXXXXXXXXXXXXX"<<endl;
    t.Print();
    {
    TabInt01 pom;
    pom = t;
    }

    TabInt01 t1(5);
    t1.FillIter(10);
    cout<<"t1: ******************"<<endl;
    t1.Print();
    cout<<"t:  XXXXXXXXXXXXXXXXXX"<<endl;
    t.Print();
    }
///*****************************************

