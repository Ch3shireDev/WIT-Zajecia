#ifndef TABINT01_H
#define TABINT01_H
#include "MyUtility.h"
class TabInt01{
    public:
        TabInt01(int=0);
        TabInt01(TabInt01&);
        ~TabInt01();
        TabInt01 operator=
                      (const TabInt01&);
        void Fill(int =0);
        void Print();
    private:
        int* pT;
        int  sT;
    };
#include "TabInt01.cpp"
#endif //TABINT01_H
