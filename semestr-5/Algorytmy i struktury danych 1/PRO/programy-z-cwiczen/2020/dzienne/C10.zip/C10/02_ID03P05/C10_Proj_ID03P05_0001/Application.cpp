void FF(){
    TabInt01 t(999999999);
    }
void HH(TabInt01 pom){}
///*****************************************
void Application::Run(){
    Main04();
    }
///*****************************************
void Application::Main01(){
    TabInt01 t(5);
    t.Fill();
    t.Print();
    }
///*****************************************
void Application::Main02(){
    for(int i = 0; i<99999;++i)
        FF();
    }
///*****************************************
void Application::Main03(){
    TabInt01 t(5);
    t.Fill();
    cout<<"t:  XXXXXXXXXXXXXXXXXXXXX\n";
    t.Print();
    HH(t);
    TabInt01 t1(5);
    t1.Fill(10);
    cout<<"t1: *********************\n";
    t1.Print();
    cout<<"t:  XXXXXXXXXXXXXXXXXXXXX\n";
    t.Print();
    }
///*****************************************
void Application::Main04(){
    TabInt01 t(5);
    t.Fill();
    cout<<"t:  XXXXXXXXXXXXXXXXXXXXX\n";
    t.Print();
    {
    TabInt01 pom;
    pom = t;
    }
    TabInt01 t1(5);
    t1.Fill(10);
    cout<<"t1: *********************\n";
    t1.Print();
    cout<<"t:  XXXXXXXXXXXXXXXXXXXXX\n";
    t.Print();
    }
///*****************************************


