///*****************************************
void Application::Run(){
    Main02();
    }
///*****************************************
void Application::Main01(){
    TabInt01 myT0(5);
    myT0.FillIter(3);
    cout<<myT0<<endl;
    }
///*****************************************
void Application::Main02(){
    TabInt02 myT0(5,3);
    myT0.FillIter(3);
    cout<<myT0<<endl;
    }
///*****************************************






