///*****************************************
void Application::Run(){
    Main02();
    }
///*****************************************
void Application::Main01(){
    TabInt01 myT0(7);
    myT0.FillIter(0);
    cout<<myT0<<endl;
    }
///*****************************************
void Application::Main02(){
    TabInt02 myT0(7,4);
    myT0.FillIter(0);
    cout<<myT0<<endl<<endl;
    myT0[0][0] = 12345;
    cout<<myT0<<endl;
    }
///*****************************************


