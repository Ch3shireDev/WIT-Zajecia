///*****************************************
TabInt01::TabInt01(int sT){
    ///cout<<"\n\n\tConstructor of TanInt01\n\n";
    if(sT>0){
        this->sT = sT;
        this->pT = new int[sT];
        }
    else{
        this->sT = 0;
        this->pT = NULL;
        }
    }
///*****************************************
TabInt01::TabInt01(const TabInt01& tabInt01){
    sT = tabInt01.sT;
    pT = NULL;
    if(sT > 0){
        pT = new int [sT];
        for(int i = 0; i<sT; ++i)
            pT[i] = tabInt01.pT[i];
        }
    }
///*****************************************
TabInt01::~TabInt01(){
    delete[] pT;
    pT = NULL;
    sT = 0;
    }
///*****************************************
TabInt01 TabInt01::operator=(const TabInt01 & s){
    if(pT != NULL) delete[] pT;
    pT = NULL;
    sT = s.sT;
    if(sT>0){
        pT = new int [sT];
        for(int i = 0; i<sT; ++i)
            pT[i] = s.pT[i];
        }
    return *this;
    }
///*****************************************
void TabInt01::FillIter(int x){
    for(int i = 0; i< sT;++i)
        pT[i] = i + x;
    }
///*****************************************
void TabInt01::Print(){
    for(int i = 0; i< sT;++i)
        cout<<"T["<<i<<"]="<<pT[i]<<endl;
    }
///*****************************************
int& TabInt01::operator[](int i){return pT[i];}
///*****************************************
int TabInt01::Length(){return sT;}
///*****************************************
TabInt01 TabInt01::operator+(int x)const{
    TabInt01 myT(*this);
    for(int i = 0; i<sT;++i)
        myT.pT[i] += x;
    return myT;
    }
///*****************************************
///*****************************************
TabInt01 operator-(int x, const TabInt01& myT){
    TabInt01 tmpT(myT);

    for(int i = 0; i< tmpT.sT;++i)
        tmpT.pT[i] -= x;
    return tmpT;
    }
///*****************************************
ostream& operator<<(ostream& s, const TabInt01& myT){
    for(int i = 0; i< myT.sT; ++i)
        s<<"["<<myT.pT[i]<<"]";
    return s;
    }
///*****************************************
///*****************************************
TabInt01 operator+(int x, const TabInt01& myT){
    return myT + x;
    }
///*****************************************
