///*****************************************
void Application::Run(){
    Main05();
    }
///*****************************************
void Application::Main01(){
    cout<<"\n\n\t\tMerry Christamas !\n\n";
    }
///*****************************************
void Application::Main02(){
    TabInt01 myT0(7);
    myT0.FillIter(0);

    myT0.operator[](0) = 999;

    for(int i = 0; i< myT0.Length();++i)
        cout<<"["<<myT0.operator[](i)<<"]";
    cout<<endl;

    }
///*****************************************
void Application::Main03(){
    TabInt01 myT0(7);
    myT0.FillIter(0);

    myT0[0] = 999;

    for(int i = 0; i< myT0.Length();++i)
        cout<<"["<<myT0[i]<<"]";
    cout<<endl;

    }
///*****************************************
void Application::Main04(){
    TabInt01 myT0(7), myT1, myT2, myT3;
    myT0.FillIter(0);

    myT0[0] = 999;

    for(int i = 0; i< myT0.Length();++i)
        cout<<"["<<myT0[i]<<"]";
    cout<<endl<<endl;

    myT1 = myT0 + 3;
    for(int i = 0; i< myT1.Length();++i)
        cout<<"["<<myT1[i]<<"]";
    cout<<endl<<endl;

    myT2 = 1 + myT1;
    for(int i = 0; i< myT2.Length();++i)
        cout<<"["<<myT2[i]<<"]";
    cout<<endl<<endl;

    myT3 = 17 - myT2;
    for(int i = 0; i< myT3.Length();++i)
        cout<<"["<<myT3[i]<<"]";
    cout<<endl<<endl;
    }
///*****************************************
void Application::Main05(){
    TabInt01 myT0(7);
    myT0.FillIter(0);
    cout<<myT0<<endl;
    }
///*****************************************


