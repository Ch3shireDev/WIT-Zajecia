///*****************************************
void Application::Run(){
    Main05();
    }
///*****************************************
void Application::Main01(){
    cout<<"\n\n\t\tMerry Christamas !\n\n";
    }
///*****************************************
void Application::Main02(){
    TabInt01 myT0(5);
    myT0.FillIter(3);

    for(int i =0; i< myT0.Length();++i)
        cout<<"["<< myT0.operator[](i)<<"]";
    cout<<endl;

    myT0.operator[](0) = 999;
    cout<<endl;

    for(int i =0; i< myT0.Length();++i)
        cout<<"["<< myT0.operator[](i)<<"]";
    cout<<endl;

    }
///*****************************************
void Application::Main03(){
    TabInt01 myT0(5);
    myT0.FillIter(3);

    for(int i =0; i< myT0.Length();++i)
        cout<<"["<< myT0[i]<<"]";
    cout<<endl;

    myT0[0] = 999;
    cout<<endl;

    for(int i =0; i< myT0.Length();++i)
        cout<<"["<< myT0[i]<<"]";
    cout<<endl;

    }
///*****************************************
void Application::Main04(){
    TabInt01 myT0(5);
    myT0.FillIter(3);
    TabInt01 myT1, myT2, myT3;

    for(int i =0; i< myT0.Length();++i)
        cout<<"["<< myT0[i]<<"]";
    cout<<endl;

    ///myT1 = myT0.operator+(5);
    myT1 = myT0 + 5;
    cout<<endl;

    for(int i =0; i< myT1.Length();++i)
        cout<<"["<< myT1[i]<<"]";
    cout<<endl;

    myT2 = 5 + myT1;
    ///myT2 = operator+(5, myT1);
    myT3 = 15 - myT2;
    for(int i =0; i< myT3.Length();++i)
        cout<<"["<< myT3[i]<<"]";
    cout<<endl;
    }
///*****************************************
void Application::Main05(){
    TabInt01 myT0(5);
    myT0.FillIter(3);
    cout<<myT0<<endl;
    }
///*****************************************






