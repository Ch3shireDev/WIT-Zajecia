#ifndef TABINT01_H
#define TABINT01_H
#include "MyUtility.h"
using std::ostream;

class TabInt01{
    public:
        TabInt01(int=0);
        TabInt01(const TabInt01&);
        ~TabInt01();
        TabInt01 operator=(const TabInt01&);
        void FillIter(int);
        int& operator[](int);
        int Length();

    private:
        int* pT;///pointer to Table
        int  sT;///size of Table

friend ostream& operator<<(ostream&, const TabInt01&);
    };
#include "TabInt01.cpp"
#endif // TABINT01_H
