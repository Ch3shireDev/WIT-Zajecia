#ifndef TABINT02_H
#define TABINT02_H
#include "TabInt01.h"

class TabInt02{
    public:
        TabInt02(int=0, int=0);
        TabInt02(const TabInt02&);
        ~TabInt02();
        TabInt02 operator=(const TabInt02&);
        void FillIter(int);
        TabInt01& operator[](int);
        int Length();

    private:
        TabInt01* pT;///pointer to Table
        int  sT;///size of Table

friend ostream& operator<<(ostream&, const TabInt02&);


    };
#include "TabInt02.cpp"
#endif // TABINT02_H
