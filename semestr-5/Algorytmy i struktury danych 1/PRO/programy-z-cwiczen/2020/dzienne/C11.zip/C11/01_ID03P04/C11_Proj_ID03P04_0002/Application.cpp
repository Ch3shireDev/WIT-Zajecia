///*****************************************
void Application::Run(){
    Main03();
    }
///*****************************************
void Application::Main01(){

    TabInt01 myT(8);
    myT.FillIter(10);

    for(int i = 0; i<myT.Length();++i)
        cout<<"["<<myT[i]<<"]";
    cout<<endl;

    }
///*****************************************
void Application::Main02(){

    TabInt01 myT(8);
    myT.FillIter(10);

    cout<<myT<<endl;
    }
///*****************************************
void Application::Main03(){
    TabInt02 myT(8, 5);
    myT.FillIter(10);

    cout<<myT<<endl;
    myT[0][0] = 9999;
    cout<<endl<<myT<<endl;
    }
///*****************************************


