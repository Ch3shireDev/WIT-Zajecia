///*****************************************
TabInt02::TabInt02(int sT0, int sT1){
    if(sT0>0){
        this->sT = sT0;
        this->pT = new TabInt01[sT];

        if(sT1>0)for(int i = 0; i < sT; ++i) pT[i] = TabInt01(sT1);
        }
    else{
        this->sT = 0;
        this->pT = NULL;
        }
    }
///*****************************************
TabInt02::TabInt02(const TabInt02& tabInt02){
    sT = tabInt02.sT;
    pT = NULL;
    if(sT > 0){
        pT = new TabInt01[sT];
        for(int i = 0; i<sT; ++i)
            pT[i] = tabInt02.pT[i];
        }
    }
///*****************************************
TabInt02::~TabInt02(){
    delete[] pT;
    pT = NULL;
    sT = 0;
    }
///*****************************************
TabInt02 TabInt02::operator=(const TabInt02 & s){
    if(pT != NULL) delete[] pT;
    pT = NULL;
    sT = s.sT;
    if(sT>0){
        pT = new TabInt01 [sT];
        for(int i = 0; i<sT; ++i)
            pT[i] = s.pT[i];
        }
    return *this;
    }
///*****************************************
void TabInt02::FillIter(int x){
    for(int i =0; i< sT; ++i)
        pT[i].FillIter(x+i);
    }
///*****************************************
TabInt01& TabInt02::operator[](int i){
    return pT[i];
    }
///*****************************************
///*****************************************
ostream& operator<<(ostream& s,const TabInt02& myT){
    for(int i =0; i<myT.sT; ++i)
        s<<myT.pT[i]<<endl;
    return s;
    }
///*****************************************
