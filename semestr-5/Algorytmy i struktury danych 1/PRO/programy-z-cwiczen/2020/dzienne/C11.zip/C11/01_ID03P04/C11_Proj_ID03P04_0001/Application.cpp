///*****************************************
void Application::Run(){
    Main05();
    }
///*****************************************
void Application::Main01(){
    cout<<"\n\n\t\tMerry Christamas !\n\n";
    }
///*****************************************
void Application::Main02(){
    TabInt01 myT(8);
    myT.FillIter(0);

    myT.operator[](0)=999;
    for(int i = 0; i<myT.Length();++i)
        cout<<"["<<myT.operator[](i)<<"]";
    cout<<endl;
    }
///*****************************************
void Application::Main03(){
    TabInt01 myT(8);
    myT.FillIter(0);

    myT[0]=999;
    for(int i = 0; i<myT.Length();++i)
        cout<<"["<<myT[i]<<"]";
    cout<<endl;
    }
///*****************************************
void Application::Main04(){
    TabInt01 myT(8);
    myT.FillIter(0);
    TabInt01 myT2, myT3;
    myT2 = myT + 5;

    ///myT = myT.operator+(5);

    for(int i = 0; i<myT2.Length();++i)
        cout<<"["<<myT2[i]<<"]";
    cout<<endl;

    myT3 = 5 + myT2;
    ///myT3 = operator+(5, myT2);
    for(int i = 0; i<myT3.Length();++i)
        cout<<"["<<myT3[i]<<"]";
    cout<<endl;
    }
///*****************************************
void Application::Main05(){
    TabInt01 myT(8);
    myT.FillIter(10);
    TabInt01 myT2, myT3;
    myT2 = 5 - myT;

    for(int i = 0; i<myT.Length();++i)
        cout<<"["<<myT[i]<<"]";
    cout<<endl;
    for(int i = 0; i<myT2.Length();++i)
        cout<<"["<<myT2[i]<<"]";
    cout<<endl;

    }
///*****************************************


