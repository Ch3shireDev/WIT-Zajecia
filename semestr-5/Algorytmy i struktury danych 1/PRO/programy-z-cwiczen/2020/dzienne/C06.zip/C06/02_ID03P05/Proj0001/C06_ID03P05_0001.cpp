#include"MyApplication.h"

///************************************************
int main(){
    MyApplication myApp;
    myApp.Run();
    return 0;
    }
