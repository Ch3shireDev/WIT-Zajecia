#ifndef MyApplication_H
#define MyApplication_H
#include "MyUtility.h"
#include "MyClass01.h"
class MyApplication{
    public:

        void Run();
        void Main01();
        void Main02();

    };
#include "MyApplication.cpp"
#endif // MyApplication_H



