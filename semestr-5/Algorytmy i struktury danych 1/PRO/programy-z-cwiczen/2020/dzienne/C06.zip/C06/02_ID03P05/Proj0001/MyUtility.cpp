int MyRead(string myStr){
    int x;
    cout<<myStr;
    cin>>x;
    return x;
    }
///************************************************

