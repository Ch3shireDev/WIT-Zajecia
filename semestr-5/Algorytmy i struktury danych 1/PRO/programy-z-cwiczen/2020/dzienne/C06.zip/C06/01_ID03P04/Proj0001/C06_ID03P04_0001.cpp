#include"MyMain.h"
int main(){
    MyMain myMain;
    myMain.Main02();

    return 0;
    }
