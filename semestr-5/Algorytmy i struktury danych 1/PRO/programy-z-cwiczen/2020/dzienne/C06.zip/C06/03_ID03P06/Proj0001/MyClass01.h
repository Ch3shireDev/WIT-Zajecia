#ifndef MyClass01_H
#define MyClass01_H
#include "MyUtility.h"

class MyClass01{
    public:

        void Ini(int, int, int);
        void Print();

    private:
        int x2;
        int x1;
        int x0;

    };


#include "MyClass01.cpp"
#endif // MyClass01_H
