#ifndef MyUtility_H
#define MyUtility_H

#include<iostream>
using std::cout;
using std::cin;
using std::endl;
using std::string;

int MyRead(string = "x? = ");

#include"MyUtility.cpp"

#endif // MyUtility_H
