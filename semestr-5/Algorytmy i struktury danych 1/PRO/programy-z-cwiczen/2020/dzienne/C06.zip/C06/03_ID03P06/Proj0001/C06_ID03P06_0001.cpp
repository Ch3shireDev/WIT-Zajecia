#include "MyUtility.h"
#include "MyApplication.h"


///************************************************
int main(){

    MyApplication myApp01;
    myApp01.Run();

    //(new MyApplication)->Run();
    return 0;
    }
