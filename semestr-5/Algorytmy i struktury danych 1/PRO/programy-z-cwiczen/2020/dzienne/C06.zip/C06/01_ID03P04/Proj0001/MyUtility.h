#ifndef MyUtility_H
#define MyUtility_H

///*******************************************************
#include<iostream>
using std::cout;
using std::cin;
using std::endl;
using std::string;
///*******************************************************
int MyRead(string = "");
///*******************************************************
#include "MyUtility.cpp"
///*******************************************************

#endif
