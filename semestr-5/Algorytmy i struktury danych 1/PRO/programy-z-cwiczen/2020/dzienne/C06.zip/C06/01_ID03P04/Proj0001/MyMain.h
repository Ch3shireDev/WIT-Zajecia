#ifndef MyMain_H
#define MyMain_H
#include"MyUtility.h"
#include "MyClass01.h"

class MyMain{
    public :
        void Main01();
        void Main02();

    };


#include "MyMain.cpp"
#endif // MyMain_H
