///*************************************************
//MyClasses::MyClasses(MyClass px2, MyClass px1, MyClass px0):x2(px2), x1(px1, x0(px0)){
//    this->x2 = x2;
//    this->x1 = x1;
//    this->x0 = x0;
//    }
MyClasses::MyClasses(MyClass x2, MyClass x1, MyClass x0):x2(x2), x1(x1), x0(x0){
    }
///*************************************************
int MyClasses::CrC(){
    return 64 * x2.CRC() + 8 * x1.CRC() + x0.CRC();
    }
///*************************************************
int MyClasses::CRC(){SetCrC(); return cRc;}
///*************************************************
void MyClasses::SetCrC(){
    cRc = CrC();
    }
///*************************************************
string MyClasses::ToString(){
    return "["   + x2.ToString() +
            ", " + x1.ToString() +
            ", " + x0.ToString() +
            "] -> " + MyUtility::ToString(CRC());
    }
///*************************************************
MyClasses MyClasses::operator+(const MyClasses& myC)const{
    return MyClasses(x2 + myC.x2, x1 + myC.x1, x0 + myC.x0);
    }
///*************************************************
