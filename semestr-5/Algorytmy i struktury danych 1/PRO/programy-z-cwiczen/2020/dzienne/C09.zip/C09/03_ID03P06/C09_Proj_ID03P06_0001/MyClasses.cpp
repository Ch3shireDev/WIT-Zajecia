///*************************************************
MyClasses::MyClasses(MyClass x2, MyClass x1, MyClass x0):
                    x2(x2), x1(x1), x0(x0){}
///*************************************************
int MyClasses::CRC(){SetCrC(); return cRc;}
///*************************************************
int MyClasses::CrC(){
    return 64*x2.CRC() + 8*x1.CRC() + x0.CRC();
    }
///*************************************************
void MyClasses::SetCrC(){
    cRc = CrC();
    }
///*************************************************
string MyClasses::ToString(){
    return "["   + x2.ToString() +
            ", " + x1.ToString() +
            ", " + x0.ToString() +
            "] -> " + MyUtility::ToString(CRC());
    }
///*************************************************
MyClasses MyClasses::operator+(const MyClasses& mC)const{
    return MyClasses(x2 + mC.x2, x1 + mC.x1, x0 + mC.x0);
    }
///*************************************************
