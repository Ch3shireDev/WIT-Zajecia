///*****************************************
void Application::Run(){
    Main08();
    }
///*****************************************
void Application::Main01(){
//    MyClass mC01;
//    cout<<"mC01: "<<mC01.ToString()<<endl;
    }
///*****************************************
void Application::Main02(){
    MyClass mC01(4, 3, 2);
    cout<<mC01.ToString()<<endl;
    }
///*****************************************
void Application::Main03(){
    MyClass mC00(103, 102, 101);
    MyClass mC01(203, 202, 201);
    MyClass mC02(303, 302, 301);

    MyClasses mCC(mC02, mC01, mC00);

    cout<<"x2: "<<mCC.x2.ToString()<<endl;
    cout<<"x1: "<<mCC.x1.ToString()<<endl;
    cout<<"x0: "<<mCC.x0.ToString()<<endl;

    }
///*****************************************
void Application::Main04(){
    MyClasses mCC(MyClass(103, 102, 101),
                  MyClass(203, 202, 201),
                  MyClass(303, 302, 301));

    cout<<"x2: "<<mCC.x2.ToString()<<endl;
    cout<<"x1: "<<mCC.x1.ToString()<<endl;
    cout<<"x0: "<<mCC.x0.ToString()<<endl;
    cout<<"mCC.cRc = "<<mCC.CRC()<<endl;
    }
///*****************************************
void Application::Main05(){
    MyClasses mCC(MyClass(103, 102, 101),
                  MyClass(203, 202, 201),
                  MyClass(303, 302, 301));
    cout<<"mCC:"<<mCC.ToString()<<endl;
    }
///*****************************************
void Application::Main06(){
    MyClass mC1(103, 102, 101);
    MyClass mC2(203, 202, 201);

    cout<<"mCC:"<<(mC1.operator+(mC2)).ToString()<<endl;
    }
///*****************************************
void Application::Main07(){
    MyClass mC1(103, 102, 101);
    MyClass mC2(203, 202, 201);

    cout<<"mCC:"<<(mC1 + mC2).ToString()<<endl;
    }
///*****************************************
void Application::Main08(){
    MyClasses mCC(MyClass(103, 102, 101),
                  MyClass(203, 202, 201),
                  MyClass(303, 302, 301));

    cout<<(mCC + mCC).ToString()<<endl;
    }
///*****************************************

