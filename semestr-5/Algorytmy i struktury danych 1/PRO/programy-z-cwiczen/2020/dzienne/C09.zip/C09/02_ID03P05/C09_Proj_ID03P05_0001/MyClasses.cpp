///*************************************************
//MyClasses::MyClasses(MyClass px2, MyClass px1, MyClass px0):
//    x2(px2), x1(px1), x0(px0){
////    x2 = px2;
////    x1 = px1;
////    x0 = px0;
//    }
///*************************************************
MyClasses::MyClasses(MyClass x2, MyClass x1, MyClass x0):
    x2(x2), x1(x1), x0(x0){}
///*************************************************
int MyClasses::CRC(){SetCrC(); return cRc;}
///*************************************************
int MyClasses::CrC(){
    return x2.CRC()*64 + x1.CRC()*8 +  x0.CRC();
    }
///*************************************************
void MyClasses::SetCrC(){
    cRc = CrC();
    }
///*************************************************
string MyClasses::ToString(){
    return "["   + x2.ToString() +
            ", " + x1.ToString() +
            ", " + x0.ToString() +
            "] -> " + MyUtility::ToString(CRC());
    }
///*************************************************
MyClasses MyClasses::operator+(const MyClasses& mC) const{
    return MyClasses(x2 + mC.x2, x1 + mC.x1, x0 + mC.x0);
    }
///*************************************************
