#ifndef MyClass_H
#define MyClass_H
#include <iostream>
#include "MyUtility.h"
using std::cout;
using std::cin;
using std::string;
using std::endl;
//int VV(){cout<<"\n\n\t\tVV()->12\n\n";return 12;}
class MyClass{
    public:
        //MyClass();
        MyClass(int, int, int);///Trzyargumentowy konstruktor
        MyClass(const MyClass&);///Konstruktor kopiujący

        int CRC();
        int CrC();
        void SetCrC();
        string ToString();
        MyClass operator+(const MyClass&) const;

        int x2;
        int x1;
        int x0;

    private:
        int cRc;
    };
#include "MyClass.cpp"
#endif // MyClass_H

