#ifndef MyClasses_H
#define MyClasses_H
#include <iostream>
#include "MyUtility.h"
#include "MyClass.h"
using std::cout;
using std::cin;
using std::string;
using std::endl;

class MyClasses{
    public:
        MyClasses(MyClass, MyClass, MyClass);


        int CRC();
        int CrC();
        void SetCrC();
        string ToString();
        MyClasses operator+(const MyClasses&)const;


        MyClass x2;
        MyClass x1;
        MyClass x0;

    private:
        int cRc;

    };
///15, 10, 10, 10, 10

#include "MyClasses.cpp"

#endif //MyClasses_H
