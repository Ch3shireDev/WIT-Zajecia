///*****************************************
void Application::Run(){
    Main07();
    }
///*****************************************
void Application::Main01(){
//    MyClass mC01;
//    cout<<"mC01:"<<mC01.ToString()<<endl;
    }
///*****************************************
void Application::Main02(){
    MyClass mC2(303, 302, 301);
    MyClass mC1(203, 202, 201);
    MyClass mC0(103, 102, 101);
    MyClasses myC01(mC2, mC1, mC0);
    }
///*****************************************
void Application::Main03(){
    MyClasses myC01(MyClass(303, 302, 301),
                    MyClass(203, 202, 201),
                    MyClass(103, 102, 101));

    cout<<"x2: "<<myC01.x2.ToString()<<endl;
    cout<<"x1: "<<myC01.x1.ToString()<<endl;
    cout<<"x0: "<<myC01.x0.ToString()<<endl;
    cout<<"myC01.cRc = "<<myC01.CRC()<<endl;
    }
///*****************************************
void Application::Main04(){
    MyClasses myC01(MyClass(303, 302, 301),
                    MyClass(203, 202, 201),
                    MyClass(103, 102, 101));

    cout<<myC01.ToString()<<endl;
    }
///*****************************************
void Application::Main05(){
    MyClass myC01(303, 302, 301);
    MyClass myC02(203, 202, 201);
    MyClass myC03(0, 0, 0);

    myC03 = myC01.operator+(myC02);

    cout<<myC03.ToString()<<endl;
    }
///*****************************************
void Application::Main06(){
    MyClass myC01(303, 302, 301);
    MyClass myC02(203, 202, 201);
    MyClass myC03(0, 0, 0);

    myC03 = myC01 + myC02;

    cout<<myC03.ToString()<<endl;
    }
///*****************************************
void Application::Main07(){
    MyClasses myC01(MyClass(303, 302, 301),
                    MyClass(203, 202, 201),
                    MyClass(103, 102, 101));
    MyClasses myC02(MyClass(603, 602, 601),
                    MyClass(253, 252, 251),
                    MyClass(103, 102, 101));

    cout<<(myC01+myC02).ToString()<<endl;
    }
///*****************************************

