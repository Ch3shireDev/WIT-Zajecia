///*****************************************
void Application::Run(){
    Main06();
    }
///*****************************************
void Application::Main01(){
    MyClass x2(22,21,20);
    MyClass x1(12,11,10);
    MyClass x0(2,1,0);
    MyClasses mC01(x2,x1,x0);
    cout<<"x2 : "<<mC01.x2.ToString()<<endl;
    cout<<"x1 : "<<mC01.x1.ToString()<<endl;
    cout<<"x0 : "<<mC01.x0.ToString()<<endl;

    }
///*****************************************
void Application::Main02(){
    MyClasses mC01(MyClass(22, 21, 20),
                   MyClass(12, 11, 10),
                   MyClass( 2,  1,  0));
    cout<<"x2 : "<<mC01.x2.ToString()<<endl;
    cout<<"x1 : "<<mC01.x1.ToString()<<endl;
    cout<<"x0 : "<<mC01.x0.ToString()<<endl;
    cout<<"mC01.cRc = "<<mC01.CRC()<<endl;
    }
///*****************************************
void Application::Main03(){
    MyClasses mC01(MyClass(22, 21, 20),
                   MyClass(12, 11, 10),
                   MyClass( 2,  1,  0));
    cout<<mC01.ToString()<<endl;
    }
///*****************************************
void Application::Main04(){
    MyClass mC01(22, 21, 20), mC02(12, 11, 10);
    MyClass mC03(0, 0, 0);

    mC03 = mC01.operator+(mC02);

    cout<<mC03.ToString()<<endl;
    }
///*****************************************
void Application::Main05(){
    MyClass mC01(22, 21, 20), mC02(12, 11, 10);
    MyClass mC03(0, 0, 0);

    mC03 = mC01 + mC02;

    cout<<mC03.ToString()<<endl;
    }
///*****************************************
void Application::Main06(){
    MyClasses mC01(MyClass(22, 21, 20),
                   MyClass(12, 11, 10),
                   MyClass( 2,  1,  0));
    MyClasses mC02(MyClass(300, 200, 100),
                   MyClass(312, 211, 110),
                   MyClass(302, 201, 100));

    cout<<(mC01+mC02).ToString()<<endl;
    }
///*****************************************
