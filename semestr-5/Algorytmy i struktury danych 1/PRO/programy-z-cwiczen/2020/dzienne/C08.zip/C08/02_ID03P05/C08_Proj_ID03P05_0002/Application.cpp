///*****************************************
void Application::Run(){
    Main02();
    }
///*****************************************
void Application::Main01(){
    MyClass m0(1, 2, 3);
    MyClass m1(m0);

//    m0.SetX2(4);
    cout<<"m0 : "<<m0.ToString()<<endl;

    cout<<"m1 : "<<m1.ToString()<<endl;
    }
///*****************************************
void Application::Main02(){
    MyClass m0(1, 2, 3);

    cout<<"m0 : "<<m0.ToString()<<endl;

    }
///*****************************************

