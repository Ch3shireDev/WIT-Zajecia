MyClasses::MyClasses(MyClass x2, MyClass x1, MyClass x0){
    cout<<"\n\t\tKonstruktor Trzyargumentowy MyClasses\n\n";
    this->x2 = x2;
    this->x1 = x1;
    this->x0 = x0;
    }
