///*****************************************
void Application::Run(){
    Main03();
    }
///*****************************************
void Application::Main01(){
    MyClass m0(4, 2, 3);

    cout<<m0.ToString()<<endl;

    }
///*****************************************
void Application::Main02(){
    MyClass m0(4, 2, 3);

    cout<<m0.ToString()<<endl;
    m0.SetX1(5);
    cout<<m0.ToString()<<endl;

    }
///*****************************************
void Application::Main03(){
    {
    MyClass m0(4, 2, 3);
    }
    cout<<"\n\nT H E    E N D\n";

    }
///*****************************************

