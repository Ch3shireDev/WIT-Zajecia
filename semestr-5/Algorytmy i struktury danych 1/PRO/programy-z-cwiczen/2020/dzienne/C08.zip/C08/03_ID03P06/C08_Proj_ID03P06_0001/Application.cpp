void Aqq(MyClass m){
    cout<<"Aqq "<<m.ToString()<<endl;
    }
///*****************************************
void Application::Run(){
    Main09();
    }
///*****************************************
void Application::Main01(){
    MyClass m0(1, 2, 3);

    cout<<m0.ToString()<<endl;

    }
///*****************************************
void Application::Main02(){
    MyClass m0(1, 2, 3);
    cout<<m0.ToString()<<endl;
    m0.Ini(m0.GetX2(),5,m0.GetX0());
    cout<<m0.ToString()<<endl;

    }
///*****************************************
void Application::Main03(){
    MyClass m0(1, 2, 3);
    cout<<m0.ToString()<<endl;
    m0.SetX1(15);
    cout<<m0.ToString()<<endl;
    }
///*****************************************
void Application::Main04(){
    MyClass m0(1, 2, 3);
    cout<<m0.ToString()<<endl;
    }
///*****************************************
void Application::Main05(){
    {
    MyClass m0(1, 2, 3);
    cout<<m0.ToString()<<endl;
    }
    cout<<"\n\n\t\tT H E    E N D\n\n";
    }
///*****************************************
void Application::Main06(){
        {
        MyClass m0(1, 2, 3);
        cout<<m0.ToString()<<endl;
        }
    cout<<"\n\n\t\tT H E    E N D\n\n";

    MyClass m0(1, 2, 3);
    cout<<m0.ToString()<<endl;
    }
///*****************************************
void Application::Main07(){
        {
        MyClass m0(1, 2, 3);
        cout<<m0.ToString()<<endl;
        m0.~MyClass();
        }
    cout<<"\n\n\t\tT H E    E N D\n\n";

    MyClass m0(1, 2, 3);
    cout<<m0.ToString()<<endl;
    }
///*****************************************
void Application::Main08(){
/**
        MyClass m0(1, 2, 3);
        cout<<m0.ToString()<<endl;
        m0.~MyClass();
*/
    cout<<"\n\n\t\tT H E    E N D\n\n";

    MyClass m0(1, 2, 3);
    cout<<m0.ToString()<<endl;
    }
///*****************************************
void Application::Main09(){
    MyClass m0(1, 2, 3);
    cout<<m0.ToString()<<endl;

    MyClass m1(m0);
    Aqq(m1);
    m0.SetX0(125);
    cout<<"m0 : "<<m0.ToString()<<endl;
    cout<<"m1 : "<<m1.ToString()<<endl;

    }
///*****************************************




