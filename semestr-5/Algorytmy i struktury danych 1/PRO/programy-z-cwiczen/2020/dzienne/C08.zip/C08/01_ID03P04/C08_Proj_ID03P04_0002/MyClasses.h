#ifndef MyClasses_H
#define MyClasses_H
#include <iostream>
#include "MyUtility.h"
#include "MyClass.h"
using std::cout;
using std::cin;
using std::string;
using std::endl;

class MyClasses{
    public:


        MyClass x2;
        MyClass x1;
        MyClass x0;

    private:
        int cRc;

    };


#include "MyClasses.cpp"

#endif //MyClasses_H
