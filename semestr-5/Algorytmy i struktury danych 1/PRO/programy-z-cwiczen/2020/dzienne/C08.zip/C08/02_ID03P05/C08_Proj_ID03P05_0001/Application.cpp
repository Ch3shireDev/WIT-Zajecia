///*****************************************
void Application::Run(){
    Main05();
    }
///*****************************************
void Application::Main01(){
    MyClass m0(1, 2, 3);

    cout<<m0.ToString()<<endl;
    m0.SetX2(12);
    cout<<m0.ToString()<<endl;

    }
///*****************************************
void Application::Main02(){
        {
        MyClass m0(1, 2, 3);
        cout<<m0.ToString()<<endl;
        }
        cout<<"\n\n\t\tT H E    E N D\n\n";
    }
///*****************************************
void Application::Main03(){
        {
        MyClass m0(1, 2, 3);
        cout<<m0.ToString()<<endl;
        }
        cout<<"\n\n\t\tT H E    E N D\n\n";
        MyClass m0(1, 2, 3);
        cout<<m0.ToString()<<endl;
    }
///*****************************************
void Application::Main04(){
        {
        MyClass m0(1, 2, 3);
        cout<<m0.ToString()<<endl;
        }
        cout<<"\n\n\t\tT H E    E N D\n\n";


        MyClass m0(1, 2, 3);
        cout<<m0.ToString()<<endl;
    }
///*****************************************
void Application::Main05(){
        MyClass m0(1, 2, 3);
        cout<<"m0: "<<m0.ToString()<<endl;
        MyClass m1(m0);
        cout<<"m1: "<<m1.ToString()<<endl;

    }
///*****************************************

