#ifndef MyClass_H
#define MyClass_H
#include <iostream>
#include "MyUtility.h"
using std::cout;
using std::cin;
using std::string;
using std::endl;

class MyClass{
    public:
        MyClass();///Bezargumentowy konstruktor
        MyClass(int, int, int);///Trzyargumentowy konstruktor
        MyClass(const MyClass&);///Konstruktor kopiujący
        ~MyClass();///Destruktor
        void Ini(int, int, int);
        void Print(const char* ="");
        void Adr();
        int GetX2();
        int GetX1();
        int GetX0();
        void SetX2(int);
        void SetX1(int);
        void SetX0(int);
        int CRC();
        int CrC();
        void SetCrC();
        string ToString();
    private:
        int x2;
        int x1;
        int x0;

        int cRc;
    };
#include "MyClass.cpp"
#endif // MyClass_H
