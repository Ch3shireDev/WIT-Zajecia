#include <cstdio>
#include <cstdlib>

typedef void(*FF01)(int);
///************************************************
void MyPrint0(int);
void MyPrint1(int);
void MyPrint2(int);
///************************************************
void MyPrint0(int x){printf("MyPrint0: x = %d\n", x);}
void MyPrint1(int x){printf("-------> MyPrint1: x = %d\n", x);}
void MyPrint2(int x){printf("----------------> MyPrint2: x = %d\n", x);}
///************************************************
int main(){
    FF01 p = MyPrint0;
    printf("Adres p = %p, adres MyPrint0 = %p\n", (void*)p, (void*)MyPrint0);

    p(24);

    return 0;
    }
