#include <cstdio>
#include <cstdlib>

typedef void(*FF0)(int);
///********************************************************
void MyPrint0(int);
void MyPrint1(int);
void MyPrint2(int);
void AllPrint(FF0, int);
void Square(int);
///********************************************************
void MyPrint0(int x){
    printf("MyPrint0: x = %d\n",x);
    }
///********************************************************
void MyPrint1(int x){
    printf("---------> MyPrint1: x = %d\n",x);
    }
///********************************************************
void MyPrint2(int x){
    printf("-------------------> MyPrint2: x = %d\n",x);
    }
///********************************************************
void AllPrint(FF0 f, int x){
    printf("AllPrint: ");
    f(x);
    }
///********************************************************
void Square(int x){
    printf("\n");
    for(int i = 0;i<x;printf("\n"),++i)
        for(int j = 0 ; j< x; printf(" *"), ++j);
    }
///********************************************************
int main(){
    AllPrint(MyPrint0,0);
    AllPrint(MyPrint1,1);
    AllPrint(MyPrint2,2);
    AllPrint(Square,10);

    return 0;
    }
