#include <cstdio>
#include <cstdlib>

typedef void(*FF01)(int);
///************************************************
void MyPrint0(int);
void MyPrint1(int);
void MyPrint2(int);
void AllPrint(FF01, int);
///************************************************
void MyPrint0(int x){printf("MyPrint0: x = %d\n", x);}
void MyPrint1(int x){printf("-------> MyPrint1: x = %d\n", x);}
void MyPrint2(int x){printf("----------------> MyPrint2: x = %d\n", x);}
void AllPrint(FF01 f, int x){
    printf("AllPrint: ");
    f(x);
    }
///************************************************
int main(){
    int s = 8;
    FF01* t;

    t = (FF01*)malloc(sizeof(FF01)*s);
    t[0] = MyPrint0;
    t[1] = MyPrint2;
    t[2] = MyPrint2;
    t[3] = MyPrint1;
    t[4] = MyPrint0;
    t[5] = MyPrint1;
    t[6] = MyPrint1;
    t[7] = MyPrint0;

    for(int i = 0; i< s; ++i)
        t[i](i);

    free(t);
    return 0;
    }
