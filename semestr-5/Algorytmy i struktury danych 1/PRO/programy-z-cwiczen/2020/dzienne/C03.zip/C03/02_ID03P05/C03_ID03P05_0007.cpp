#include <cstdio>
#include <cstdlib>

typedef int ala;
///************************************************
void MyPrint0(int);
///************************************************
void MyPrint0(int x){printf("MyPrint0: x = %d\n", x);}
///************************************************
int main(){

    ala x;
    int y;

    x = 9;
    y = x;
    MyPrint0(x);
    MyPrint0(y);

    return 0;
    }
