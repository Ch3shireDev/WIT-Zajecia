#include <cstdio>
#include <cstdlib>

typedef void(*FF0)(int);
///********************************************************
void MyPrint0(int);
void MyPrint1(int);
void MyPrint2(int);
void AllPrint(FF0, int);
void Square(int);
///********************************************************
void MyPrint0(int x){
    printf("MyPrint0: x = %d\n",x);
    }
///********************************************************
void MyPrint1(int x){
    printf("---------> MyPrint1: x = %d\n",x);
    }
///********************************************************
void MyPrint2(int x){
    printf("-------------------> MyPrint2: x = %d\n",x);
    }
///********************************************************
void AllPrint(FF0 f, int x){
    printf("AllPrint: ");
    f(x);
    }
///********************************************************
void Square(int x){
    printf("\n");
    for(int i = 0;i<x;printf("\n"),++i)
        for(int j = 0 ; j< x; printf(" *"), ++j);
    }
///********************************************************
int main(){
    int s = 8;
    FF0 * t;

    t = (FF0*)malloc(sizeof(FF0)*s);

    t[0] = MyPrint0;
    t[1] = MyPrint1;
    t[2] = MyPrint1;
    t[3] = MyPrint2;
    t[4] = MyPrint1;
    t[5] = MyPrint0;
    t[6] = MyPrint2;
    t[7] = MyPrint1;

    for(int i = 0; i<s;++i)
        t[i](i);

    free(t);
    return 0;
    }
