#include <cstdio>
#include <cstdlib>

///********************************************
typedef void (*FF01)(int a);
///********************************************
void MyPrint0(int);
void MyPrint1(int);
void MyPrint2(int);
void AllPrint(FF01, int);
///********************************************
void MyPrint0(int x){printf("MyPrint0 -> x = %d\n",x);}
///********************************************
void MyPrint1(int x){printf("----MyPrint1 -> x = %d\n",x);}
///********************************************
void MyPrint2(int x){printf("--------MyPrint2 -> x = %d\n",x);}
///********************************************
void AllPrint(FF01 ff, int x){
    printf("Funkcja FF01->");
    ff(x);
    }
///********************************************
int main(){
    FF01 * t;
    int s = 12;
    t = (FF01*)malloc(sizeof(FF01)*s);
    t[0] = MyPrint0;
    t[1] = MyPrint1;
    t[2] = MyPrint0;
    t[3] = MyPrint2;
    t[4] = MyPrint2;
    t[5] = MyPrint1;
    t[6] = MyPrint1;
    t[7] = MyPrint1;
    t[8] = MyPrint0;
    t[9] = MyPrint2;
    t[10] = MyPrint0;
    t[11] = MyPrint1;

    for(int i = 0; i<s;++i)
        t[i](i);

    free(t);
    return 0;
    }

