#include <cstdio>
#include <cstdlib>

///********************************************
void MyPrint0(int);
void MyPrint1(int);
void MyPrint2(int);

///********************************************
void MyPrint0(int x){printf("MyPrint0 -> x = %d\n",x);}
///********************************************
void MyPrint1(int x){printf("----MyPrint1 -> x = %d\n",x);}
///********************************************
void MyPrint2(int x){printf("--------MyPrint2 -> x = %d\n",x);}
///********************************************
int main(){
    MyPrint0(0);
    MyPrint1(1);
    MyPrint2(2);


    return 0;
    }

