#include <cstdio>
#include <cstdlib>

typedef void(*FF0)(int);
///********************************************************
void MyPrint0(int);
///********************************************************
void MyPrint0(int x){
    printf("MyPrint0: x = %d\n",x);
    }
///********************************************************
int main(){
    FF0 p;
    p = MyPrint0;

    printf("Adres p = %p, Adres MyPrint0 = %p\n", (void*)p, (void*)MyPrint0);

    p(15);

    return 0;
    }
