#include <cstdio>
#include <cstdlib>

///************************************************
int MySort(int*, int*, int*);
///************************************************
int MySort(int* x, int* y, int* z){
    int tmp;
    if(*x>*y){
        tmp = *x;
        *x = *y;
        *y = tmp;
        }
    if(*y>*z){
        tmp = *y;
        *y = *z;
        *z = tmp;
        }
    if(*x>*y){
        tmp = *x;
        *x = *y;
        *y = tmp;
        }
    return 1;
    }
///************************************************
int main(){
    int x0, y0, z0;
    int x1, y1, z1;

    printf("x? = ");
    scanf("%d", &x0);
    printf("y? = ");
    scanf("%d", &y0);
    printf("z? = ");
    scanf("%d", &z0);

    x1 = x0;
    y1 = y0;
    z1 = z0;

    MySort(&x1, &y1, &z1);

    printf("(%d, %d, %d) -> (%d, %d, %d)\n",x0,y0,z0,x1,y1,z1);


    return 0;
    }
/**
x? = 3
y? = 1
z? = 2
(3, 1, 2) -> (1, 2, 3)
12, 12, 10, 10, 10, 8, 8, 8, 8, 7, 7, 7, 7, 7
*/
