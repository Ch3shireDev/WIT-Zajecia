#include <cstdio>
#include <cstdlib>

typedef void(*FF01)(int);
///************************************************
void MyPrint0(int);
void MyPrint1(int);
void MyPrint2(int);
void AllPrint(FF01, int);
///************************************************
void MyPrint0(int x){printf("MyPrint0: x = %d\n", x);}
void MyPrint1(int x){printf("-------> MyPrint1: x = %d\n", x);}
void MyPrint2(int x){printf("----------------> MyPrint2: x = %d\n", x);}
void AllPrint(FF01 f, int x){
    printf("AllPrint: ");
    f(x);
    }
///************************************************
int main(){
    FF01 p = MyPrint0;
    printf("Adres p = %p, adres MyPrint0 = %p\n", (void*)p, (void*)MyPrint0);

    AllPrint(MyPrint0,0);
    AllPrint(MyPrint1,1);
    AllPrint(MyPrint2,2);

    return 0;
    }
