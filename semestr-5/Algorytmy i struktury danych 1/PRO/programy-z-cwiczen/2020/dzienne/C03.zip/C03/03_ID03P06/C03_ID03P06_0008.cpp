#include <cstdio>
#include <cstdlib>
///********************************************************
void MyPrint0(int);
///********************************************************
void MyPrint0(int x){
    printf("MyPrint: x = %d\n",x);
    }
///********************************************************
int main(){
    printf("Adres MyPrint0 = %p\n", (void*)MyPrint0);


    return 0;
    }
