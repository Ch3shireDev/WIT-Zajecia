#include <cstdio>
#include <cstdlib>

typedef int ala;
///********************************************************
void MyPrint0(int);
///********************************************************
void MyPrint0(int x){
    printf("MyPrint: x = %d\n",x);
    }
///********************************************************
int main(){
    ala x = 7;
    int y = x;
    MyPrint0(x);
    MyPrint0(y);


    return 0;
    }
